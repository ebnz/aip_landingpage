/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.mapred.JobConf
import grizzled.slf4j.Logging

/**
 * Methods to retrieve information from Hadoop JobConf.
 *
 * User: flangner
 * Date: 20.07.2010
 * Time: 19:32:19
 */

object HadoopConfGlue extends Logging {

  var conf: JobConf = null
  var fs: FileSystem = null

  def init(conf: JobConf) {
    if (this.conf == null) {
      this.conf = conf
      this.fs = FileSystem.get(conf)
    }
  }

  /**
   * @taken from org.apache.hadoop.JobTracker
   * @return the default system directory.
   */
  def getSystemDir: String = {
    if (conf == null) {
      error("HadoopConfGlue has not been initialized jet!")
      null
    } else {
      var sysDir: Path = new Path(conf.get("mapreduce.jobtracker.system.dir", "/tmp/hadoop/mapred/system"));
      fs.makeQualified(sysDir).toString;
    }
  }

  /**
   * @return the path where the filterData of DynamicPathFilter is located at.
   */
  def getFilterPath: Path = {
    if (conf == null) {
      error("HadoopConfGlue has not been initialized jet!")
      null
    } else {
      new Path (getSystemDir, "pathFilter.dat")
    }
  }
}