/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface;

import org.apache.hadoop.mapred.Counters;
import org.apache.hadoop.mapred.Reporter;

/**
 * Reporter object to provide the predefined features of Hadoop within MRStreamer.
 * 
 * User: flangner
 * Date: 22.07.2010
 * Time: 15:12:29
 */
public class MapReporter implements Reporter {

    private org.apache.hadoop.mapred.InputSplit split;

    public MapReporter (org.apache.hadoop.mapred.InputSplit split) {
        this.split = split;
    }

    public void setStatus(String status) { /* ignored */ }

    public Counters.Counter getCounter(Enum<?> name) {
        return null;  //TODO
    }

    public Counters.Counter getCounter(String group, String name) {
        return null;  //TODO
    }

    public void incrCounter(Enum<?> key, long amount) {
        //TODO
    }

    public void incrCounter(String group, String counter, long amount) {
        //TODO
    }

    public org.apache.hadoop.mapred.InputSplit getInputSplit() throws UnsupportedOperationException {
        return split;
    }

    public void progress() { /* ignored */ }
}
