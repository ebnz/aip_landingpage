/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface;

import org.apache.hadoop.mapred.Counters;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.Reporter;

/**
 * Reporter stub: throws UnsupportedOperationException.
 *
 * User: flangner
 * Date: 06.08.2010
 * Time: 17:10:34
 */
public class DummyReporter implements Reporter {

    public void setStatus(String status) {
        //System.out.println("Status set to: " + status);
        //throw new UnsupportedOperationException();
    }

    public Counters.Counter getCounter(Enum<?> name) {
        throw new UnsupportedOperationException();
    }

    public Counters.Counter getCounter(String group, String name) {
        throw new UnsupportedOperationException();
    }

    public void incrCounter(Enum<?> key, long amount) {
        throw new UnsupportedOperationException();
    }

    public void incrCounter(String group, String counter, long amount) {
        throw new UnsupportedOperationException();
    }

    public InputSplit getInputSplit() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }

    public void progress() {
        throw new UnsupportedOperationException();
    }
}
