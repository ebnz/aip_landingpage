/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface.algorithms.wc;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.UTF8;
import org.apache.hadoop.mapred.*;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

/**
 * Hadoop-compatible implementation of the RelWC algorithm as common example algorithm of the MRStreamer package.
 *
 * User: flangner
 * Date: 12.08.2010
 * Time: 10:28:50
 */
public class RelativeWordcount implements Reducer<UTF8, IntWritable, UTF8, IntWritable>, Mapper<Object, Text, UTF8, IntWritable> {

    public void map(Object key, Text value, OutputCollector<UTF8, IntWritable> resultCollector, Reporter reporter) throws IOException {
        String line = value.toString();

        // b counts the bytes processed so far
        long b = line.getBytes().length;

        SimpleAnalyzer analyzer = new SimpleAnalyzer();

        TokenStream tokenStream = analyzer.tokenStream("", new StringReader(line));
        Token tok = tokenStream.next();
        while (tok != null) {
          resultCollector.collect (new UTF8(tok.termText()), new IntWritable(1));
          tok = tokenStream.next();
        }
        tokenStream.end();
        tokenStream.close();
    }

    public void reduce(UTF8 key, Iterator<IntWritable> values, OutputCollector<UTF8, IntWritable> collector, Reporter reporter) throws IOException {

        int value = 0;
        while (values.hasNext()) {
            value += values.next().get();
        }

        collector.collect(key, new IntWritable(value));
    }

    public void close() throws IOException { }

    public void configure(JobConf jobConf) { }
}
