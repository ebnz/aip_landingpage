/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface.algorithms.wc

import org.apache.hadoop.io.{IntWritable, Text}
import org.apache.hadoop.mapred._
import org.apache.hadoop.fs.Path

/**
 * Wordcount algorithm capable for the hadoop interface.
 *
 * User: flangner
 * Date: 11.08.2010
 * Time: 19:52:29
 */

object HadoopRelWCTest {
  def main(args: Array[String]){
    val conf: JobConf = new JobConf(classOf[RelativeWordcount])

    conf.setJobName("wordcount")
    conf.setOutputKeyClass(classOf[Text])
    conf.setOutputValueClass(classOf[IntWritable])
    conf.setMapperClass(classOf[RelativeWordcount])
    conf.setCombinerClass(classOf[RelativeWordcount])
    conf.setReducerClass(classOf[RelativeWordcount])
    conf.setInputFormat(classOf[TextInputFormat])
    conf.setOutputFormat(classOf[TextOutputFormat[Any, Any]])
    FileInputFormat.setInputPaths(conf, new Path("testdata/wordcount/smalltest"))
    FileOutputFormat.setOutputPath(conf, new Path("testdata/wordcount/out"))
    
    conf.setNumMapTasks(4)
    conf.setNumReduceTasks(2)

    
    conf.setBoolean("mrstreamer.distributed",false)

    val time: Long = System.currentTimeMillis
    MRSJobClient.runJob(conf)
    print("Duration of the execution of Relative Wordcount: " + (System.currentTimeMillis - time) + " ms")
  }
}
