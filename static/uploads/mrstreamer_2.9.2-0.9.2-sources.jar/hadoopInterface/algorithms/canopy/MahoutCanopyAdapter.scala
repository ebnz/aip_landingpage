/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface.algorithms.canopy

import org.apache.hadoop.mapred._
import org.apache.hadoop.fs.Path
import org.apache.mahout.clustering.canopy.{CanopyDriver, Canopy, CanopyReducer, CanopyMapper, CanopyConfigKeys}
import org.apache.hadoop.io.Text
//import org.apache.mahout.matrix.DenseVector
import org.apache.mahout.math.DenseVectorWritable
//import org.apache.mahout.math.RandomAccessSparseVector

/**
 * Canopy Mahout algorithm adapter, capable for the hadoop interface.
 *
 * User: flangner
 * Date: 11.08.2010
 * Time: 19:52:29
 */

object MahoutCanopyAdapter {
  def main(args: Array[String]){
    val conf: JobConf = new JobConf(classOf[CanopyDriver])

    conf.setJobName("canopy")

    // TODO customize the paths
    FileInputFormat.setInputPaths(conf, new Path("../testdata/canopy/in/sim1.seq"))
    FileOutputFormat.setOutputPath(conf, new Path("../testdata/canopy/out"))
    //conf.setNumReduceTasks(1)                                    // TODO vary the number of reducers to use
    conf.set(CanopyConfigKeys.DISTANCE_MEASURE_KEY, "org.apache.mahout.common.distance.EuclideanDistanceMeasure")        // TODO set some valid measureClass!
    conf.set(CanopyConfigKeys.T1_KEY, String.valueOf(80))                 // TODO T1 distance threshold
    conf.set(CanopyConfigKeys.T2_KEY, String.valueOf(55))                 // TODO T2 distance threshold

    conf.setMapperClass(classOf[CanopyMapper])
    conf.setReducerClass(classOf[CanopyReducer])
    conf.setInputFormat(classOf[SequenceFileInputFormat[_,_]])
    conf.setOutputFormat(classOf[SequenceFileOutputFormat[_,_]])
    conf.setMapOutputKeyClass(classOf[Text])
    conf.setMapOutputValueClass(classOf[DenseVectorWritable])
    //conf.setMapOutputValueClass(classOf[RandomAccessSparseVector])
    conf.setOutputKeyClass(classOf[Text])
    conf.setOutputValueClass(classOf[Canopy])

    val time : Long = System.currentTimeMillis
    MRSJobClient.runJob(conf)
    print("Duration of the execution of Canopy Clustering: " + (System.currentTimeMillis - time) + " ms")

  }
}
