/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface.algorithms.kmeans

import org.apache.hadoop.io.Text
import org.apache.hadoop.mapred._
import org.apache.hadoop.fs.Path
import org.apache.mahout.clustering.kmeans._

/**
 * KMeans Mahout algorithm adapter, capable for the hadoop interface.
 *
 * User: flangner
 * Date: 11.08.2010
 * Time: 19:52:29
 */

object MahoutKMeansAdapter {
  def main(args: Array[String]){
    val conf: JobConf = new JobConf(classOf[KMeansDriver])

    conf.setJobName("kmeans")

    // TODO customize the paths
    FileInputFormat.setInputPaths(conf, new Path("../testdata/kmeans/in"))
    FileOutputFormat.setOutputPath(conf, new Path("../testdata/kmeans/out"))
    conf.setNumReduceTasks(1)                                     // TODO vary the number of reducers to use
    conf.set(KMeansConfigKeys.CLUSTER_PATH_KEY, "../testdata/kmeans/inputClusters") // TODO
    conf.set(KMeansConfigKeys.DISTANCE_MEASURE_KEY, "measureClass")        // TODO set some valid measureClass!
    conf.set(KMeansConfigKeys.CLUSTER_CONVERGENCE_KEY, "10000.0")          // TODO delta? -> its our epsilon
    conf.setInt(KMeansConfigKeys.ITERATION_NUMBER, 10)                     // TODO set a limit for the count of iterations

    conf.setMapOutputKeyClass(classOf[Text])
    conf.setMapOutputValueClass(classOf[KMeansInfo])
    conf.setOutputKeyClass(classOf[Text])
    conf.setOutputValueClass(classOf[Cluster])
    conf.setInputFormat(classOf[SequenceFileInputFormat[_,_]])
    conf.setOutputFormat(classOf[SequenceFileOutputFormat[_,_]])
    conf.setMapperClass(classOf[KMeansMapper])
    conf.setCombinerClass(classOf[KMeansCombiner])
    conf.setReducerClass(classOf[KMeansReducer])

    MRSJobClient.runJob(conf)
  }
}
