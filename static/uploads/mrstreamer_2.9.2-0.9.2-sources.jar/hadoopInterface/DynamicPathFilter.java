/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface;

import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.permission.FsPermission;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * PathFilter with a dynamically expandable string-set of accepted input-paths.
 *
 * User: flangner
 * Date: 21.07.2010
 * Time: 14:31:33
 */
public class DynamicPathFilter implements PathFilter {

    // job files are world-wide readable and owner writable
    final private static FsPermission JOB_FILE_PERMISSION = FsPermission.createImmutable((short) 0644); // rw-r--r--

    private Set<Path> history = new HashSet<Path>();

    /**
     * Retrieves the filter history from pathFilter.dat at the working directory.
     */
    public DynamicPathFilter () { this(false); }

    public DynamicPathFilter(boolean createNew) {
        if (!createNew) {
            FileSystem fs = HadoopConfGlue.fs();
            Path filterPath = HadoopConfGlue.getFilterPath();
            FSDataInputStream in;
            try {
                in = fs.open(filterPath);
            } catch (IOException e) {
                throw new RuntimeException("[MRStreamer] input filter could not be retrieved, because: " +
                        e.getMessage() + "\nPlease ensure that '" + filterPath.toString() +
                        "' is available and accessible.");
            }

            try {
                int length = in.readInt();
                for (int i = 0; i < length; i++) {
                    history.add(new Path(in.readUTF()));
                }
                if (in != null) in.close();
            } catch (IOException e) {
                System.err.println("An error occurred while retrieving the DynamicPathFilter. Some input files might " +
                        "be unattended. Reason: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public void add (Path path) {
        history.add(path);
    }

    public boolean accept(Path path) {
        return history.contains(HadoopConfGlue.fs().makeQualified(path));
    }

    /**
     * Writes the filter parameters to pathFilter.dat at the working directory.
     *
     * @throws IOException
     */
    public void serialize() throws IOException {
        FileSystem fs = HadoopConfGlue.fs();
        Path filterPath = HadoopConfGlue.getFilterPath();
        FSDataOutputStream out = FileSystem.create(fs, filterPath, new FsPermission(JOB_FILE_PERMISSION));

        try {
            out.writeInt(history.size());
            for (Path path : history) {
                out.writeUTF(path.toString());
            }
        } finally {
            out.flush();
            out.close();
        }
    }
}
