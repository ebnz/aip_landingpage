/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface

import org.apache.hadoop.io.Writable
import java.io._
import sjson.json.JsonSerialization
import dispatch.json.{JsValue, JsString}

/**
 * Object to convert between SBinary and Hadoop-Writable (Java) serialization.
 * 
 * @author flangner
 */

object HadoopSerializationGlue {

//  private class SBinaryInputStream (in: Input) extends InputStream {
//    def read(): Int = {
//      try {
//        in.readByte.asInstanceOf[Int]
//      } catch {
//        case e: EOF  => {
//          (-1).asInstanceOf[Int]
//        }
//      }
//    }
//  }
//
//  private class SBinaryOutputStream (out: Output) extends OutputStream {
//    def write(b: Int) {
//      out.writeByte(b.asInstanceOf[Byte])
//    }
//  }
//
//  /**
//   * Reads value from the given in.
//   *
//   * @param in - sbinary.Input
//   * @param value - Writable object
//   * @return the number of bytes read.
//   */
//  @Deprecated
//  def readInput (value: Writable, in: Input): Int = {
//    val sIn: InputStream = new SBinaryInputStream(in)
//    val numBytes: Int = sIn.available
//    if (numBytes < 0) throw new UnsupportedOperationException("Tried to read empty data!")
//
//    val dIn: DataInput = new DataInputStream(sIn)
//    value.readFields(dIn)
//    numBytes
//  }
//
//  /**
//   * Reads value from the given in.
//   * Uses an intermediate step to Array[Byte].
//   *
//   * @param in - sbinary.Input
//   * @param value - Writable object
//   * @return the number of bytes read.
//   */
//  def readInputAsByteArray (value: Writable, in: Input): Int = {
//    val bIn: Array[Byte] = read[Array[Byte]](in)
//    val numBytes: Int = bIn.length
//    if (numBytes < 0) throw new UnsupportedOperationException("Tried to read empty data!")
//
//    val dIn: DataInputStream = new DataInputStream(new ByteArrayInputStream(bIn))
//    value.readFields(dIn)
//    dIn.close()
//    numBytes
//  }

  def stringToWritable[T <: Writable : Manifest](in: String) : T = {
    val value : T = manifest[T].erasure.newInstance.asInstanceOf[T]
    stringToWritable(value, in).asInstanceOf[T]
  }

  def stringToWritable(value: Writable, in: String): Writable = {
    val dIn: DataInputStream = new DataInputStream(new ByteArrayInputStream(new org.apache.commons.codec.binary.Base64(0).decode(in)))
    value.readFields(dIn)
    dIn.close()
    value
  }

  def jsValueToWritable[T <: Writable : Manifest](in: JsValue) : T = {
    import sjson.json.DefaultProtocol._
    stringToWritable[T](JsonSerialization.fromjson[String](in))
  }
  def jsValueToWritable(value: Writable,  in: JsValue) : Writable = {
    import sjson.json.DefaultProtocol._
    stringToWritable(value, JsonSerialization.fromjson[String](in))
  }

//  /**
//   * Writes value to the given out.
//   *
//   * @param out - sbinary.Output
//   * @param value - Writable object
//   */
//  def writeOutput (value: Writable, out: Output) {
//    if (value == null) throw new UnsupportedOperationException("null-values are not supported!")
//
//    val sOut: SBinaryOutputStream = new SBinaryOutputStream(out)
//    val dOut: DataOutput = new DataOutputStream(sOut)
//    value.write(dOut)
//  }
//
//  /**
//   * Writes value to the given out.
//   * Uses an intermediate step to Array[Byte].
//   *
//   * @param out - sbinary.Output
//   * @param value - Writable object
//   */
//  def writeOutputAsByteArray (value: Writable, out: Output) {
//    write[Array[Byte]](out, writeableToByteArrayOutputStream(value).toByteArray)
//  }

  private def writeableToByteArrayOutputStream (value: Writable) : ByteArrayOutputStream = {
    if (value == null) throw new IllegalArgumentException("Cannot write null values!")
    val bOut: ByteArrayOutputStream = new ByteArrayOutputStream
    val dOut: DataOutputStream = new DataOutputStream(bOut)
    value.write(dOut)
    dOut.flush()
    dOut.close()
    bOut
  }

  def writableToString(value: Writable) = new org.apache.commons.codec.binary.Base64(0).encodeToString(writeableToByteArrayOutputStream(value).toByteArray)
  def writableToJsString(value: Writable) : JsString = JsString(writableToString(value))

  /**
   * @param value
   * 
   * @return the size of this value.
   */
  def sizeOf (value: Writable): Int = {
    val bOut: ByteArrayOutputStream = new ByteArrayOutputStream
    val dOut: DataOutputStream = new DataOutputStream(bOut)
    value.write(dOut)
    dOut.flush()
    dOut.close()
    bOut.size
  }
}