/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.DataOutputBuffer;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RawSplit;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Non public methods taken from Hadoop to be used within MRStreamer.
 *
 * User: flangner
 * Date: 21.07.2010
 * Time: 08:07:07
 */
public class HadoopMethods {

    /**
     * Creates splits from the resources given by job and writes them to
     * submitSplitFile.
     *
     * @taken from org.apache.hadoop.mapred.JobClient
     *
     * @param job
     * @param submitSplitFile
     * @return the amount of splits created.
     * @throws IOException
     */
    public static int writeOldSplits(JobConf job, Path submitSplitFile) throws IOException {

      InputSplit[] splits = job.getInputFormat().getSplits(job, job.getNumMapTasks());
      // sort the splits into order based on size, so that the biggest
      // go first
      Arrays.sort(splits, new Comparator<InputSplit>() {
        public int compare(InputSplit a, InputSplit b) {
          try {
            long left = a.getLength();
            long right = b.getLength();
            if (left == right) {
              return 0;
            } else if (left < right) {
              return 1;
            } else {
              return -1;
            }
          } catch (IOException ie) {
            throw new RuntimeException("Problem getting input split size", ie);
          }
        }
      });
      DataOutputStream out = writeSplitsFileHeader(job, submitSplitFile, splits.length);

      try {
        DataOutputBuffer buffer = new DataOutputBuffer();
        RawSplit rawSplit = new RawSplit();
        for(InputSplit split: splits) {
          rawSplit.setClassName(split.getClass().getName());
          buffer.reset();
          split.write(buffer);
          rawSplit.setDataLength(split.getLength());
          rawSplit.setBytes(buffer.getData(), 0, buffer.getLength());
          rawSplit.setLocations(split.getLocations());
          rawSplit.write(out);
        }
      } finally {
        out.close();
      }
      return splits.length;
    }

    // job files are world-wide readable and owner writable
    final private static FsPermission JOB_FILE_PERMISSION = FsPermission.createImmutable((short) 0644); // rw-r--r--

    private static final int CURRENT_SPLIT_FILE_VERSION = 0;
    private static final byte[] SPLIT_FILE_HEADER = "SPL".getBytes();

    /**
     * @taken from org.apache.hadoop.mapred.JobConf
     * 
     * @param conf
     * @param filename
     * @param length
     * @return the OutputStream where the header data has been written to.
     * @throws IOException
     */
    private static DataOutputStream writeSplitsFileHeader(Configuration conf, Path filename, int length )
            throws IOException {

        // write the splits to a file for the job tracker
        FileSystem fs = filename.getFileSystem(conf);
        FSDataOutputStream out = FileSystem.create(fs, filename, new FsPermission(JOB_FILE_PERMISSION));
        out.write(SPLIT_FILE_HEADER);
        WritableUtils.writeVInt(out, CURRENT_SPLIT_FILE_VERSION);
        WritableUtils.writeVInt(out, length);
        
        return out;
    }
}
