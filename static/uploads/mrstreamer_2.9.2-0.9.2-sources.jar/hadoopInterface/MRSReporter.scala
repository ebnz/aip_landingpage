/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hadoopInterface

import org.apache.hadoop.mapreduce.StatusReporter
import org.apache.hadoop.mapreduce.Counter
import scala.collection.mutable.HashMap

class MRSReporter extends StatusReporter {
  
  val counters = new HashMap[CounterName,Counter] 

  def getCounter(name: Enum[_]): Counter = { throw new UnsupportedOperationException }

  def getCounter(group: String, name: String): Counter = { counters.getOrElseUpdate(CounterName(group, name), new Counter(name, name, 0)) }

  def progress() { throw new UnsupportedOperationException }

  def setStatus(status: String) { throw new UnsupportedOperationException }

}

case class CounterName(group : String, name : String)