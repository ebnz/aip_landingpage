/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package akka.serialization

import akka.remote.protocol.RemoteProtocol.RemoteActorRefProtocol
import com.google.protobuf.TextFormat
import akka.actor.{ActorRef, RemoteActorRef}
import sun.misc.BASE64Decoder

object RemoteActorSerializationHelper {
  def fromBase64StringToRemoteActorRef(chars: CharSequence): ActorRef = {
    val builder = RemoteActorRefProtocol.newBuilder()
    builder.mergeFrom(new  org.apache.commons.codec.binary.Base64().decode(chars.toString))
    val protocol = builder.build()
    val remoteActorRef = RemoteActorRef(
      protocol.getClassOrServiceName,
      protocol.getActorClassname,
      protocol.getHomeAddress.getHostname,
      protocol.getHomeAddress.getPort,
      protocol.getTimeout,
      None)
    remoteActorRef
  }
  def fromRemoteActorRefToBase64String(actorRef: ActorRef): String = {
    new org.apache.commons.codec.binary.Base64(0).encodeToString(RemoteActorSerialization.toRemoteActorRefProtocol(actorRef).toByteArray)
  }
}