/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eval;

/**
 * @author Artur Andrzejak
 * @date: 25.10.2009 - 16:39:02
 * @description: An interface for
 * @description: a) the "characterisation metric" m(R_s) of an intermediate result R_s (this is the data of this object), and
 * @description: b) the metric dif(m(R_s), m(R_s)) - only
 * @description: See g-doc StreamingMapReduce, section "Estimating the error of intermediate result (ideas)" for a description.
 */
public interface ResultSummary {

    /** Sets the value of the "characterisation metric" m(R_s) - this data is the actual "result summary" */
    void set(Object obj);

    
    /** The dif metric to compare an "old" and new ResultSummary objects.
     * todo: maybe use "this" instead of one arguments? But then which one is "old"? (In some cases important.)
     *  To be implemented by the algorithm designer.
     * */
    double dif (ResultSummary oldResultSummary, ResultSummary newResultSummary);

	 String toString();

}
