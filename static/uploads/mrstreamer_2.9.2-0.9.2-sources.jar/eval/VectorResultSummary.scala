/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eval



/**
 * @author  Artur Andrzejak
 * @date: 25.10.2009 - 19:48:28
 * @description: A class implementing metric m (ResultSummary) and metric dif(.,.)
 * @description: for ResultSummary's whose data is a vector of doubles.
 * @description: As the dif() function an MSE is used.
 */

class VectorResultSummary extends ResultSummary {

  // We have to store the whole result as a vector of doubles
  protected var coeffVector:Array[Double] = null

  /** The dif metric to compare an "old" and new ResultSummary objects.
    We compute the MSE (Mean Squared Error) of both vectors
   * */
  def dif (oldResultSummary:ResultSummary, newResultSummary:ResultSummary):Double = {
    val oldVect = oldResultSummary.asInstanceOf[VectorResultSummary].coeffVector
    val newVect = newResultSummary.asInstanceOf[VectorResultSummary].coeffVector
    val oldSize = oldVect.size
    assert (oldSize == newVect.size)

    var sum:Double = 0.0
    for (i <- 0 until oldSize) {
      val valueDif = oldVect(i) - newVect(i)
      sum += valueDif * valueDif
    }
    sum
  }

  def set(resultSummaryValue:Any) {
    // we expect to get a double[] vector as an argument
    coeffVector = resultSummaryValue.asInstanceOf[Array[Double]]
  }

  override def toString:String = {
	 val str = new StringBuffer()
	 for(i <- 0 to coeffVector.size-1) {
		str.append(coeffVector(i).toString).append(" ")
	 }

	 str.toString
  }

}
