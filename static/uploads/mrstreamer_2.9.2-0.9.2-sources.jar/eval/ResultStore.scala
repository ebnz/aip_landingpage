/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package eval


import collection.mutable.ArrayBuffer
import compat.Platform._
import scala.util.Sorting.stableSort
import util.ResultEmitter

/**
 * @author Artur Andrzejak
 * @date: 25.10.2009 - 15:58:25
 * @description: For storing and evaluating "summaries" of intermediate algorithm results (computed by a reduce collector).
 * @description: These objects are represented as the ResultSummary objects.
 *
 */

trait ResultStore {
  protected val samples = new ArrayBuffer[Sample] 
  protected val startTime = currentTime

  /**Appends to store current intermediate result
   * @param outcomeInBytes
   * @param resSummary the user-computed ResultSummary object
   * @param rawResult ( optional ) complete data of a result
   */
  def append(outcomeInBytes: Long, resSummary: ResultSummary, rawResult: Any) = {
    val s = new Sample()
    s.outcomeInBytes = outcomeInBytes
    s.resSummary = resSummary
    s.rawResult = rawResult
    s.timeStored = currentTime - startTime // relative since start
	  s.memUsage = Runtime.getRuntime.totalMemory() - Runtime.getRuntime.freeMemory()
    samples += s
  }

  /**Convenience method: internally creates a ResultSummary and appends it to the ResultStore
   * @param ResultSummaryClass class of the ResultSummary, e.g. VectorResultSummary
   * @param outcomeInBytes
   * @param result the user-computed result to be which is hold in ResultSummary object
   * @param rawResult (optional) complete data of a result
   */
  def createAndAppend(ResultSummaryClass:String, outcomeInBytes: Long, result:Any, rawResult: Any) = {
    val resultSummary  = Class.forName(ResultSummaryClass).newInstance().asInstanceOf[ResultSummary]
    resultSummary.set(result)
    append(outcomeInBytes, resultSummary, rawResult)
  }
  

  /**Values of metric dif over ResultSummary's from result with index 0 to one with indexOfReferenceResult,
   * i.e. the y-axis values of the convergence graph
   * @param indexOfReferenceResult if < 0, the last avail data is used
   * @return Tuple2: (Double[] with values of dif's, last index of ResultSummaries used)
   */
  def getDifs(startIndex:Int, indexOfReferenceResult: Int): (Array[Double], Int) = {
    val referenceIndex = getIndexOfReferenceResult(indexOfReferenceResult)
    val referenceResultSummary = samples(referenceIndex).resSummary

    val difs = collectResultsOfSamplesSlice(startIndex, referenceIndex) {
      sample =>
            val olderResultSummary = sample.resSummary
            // compute the metric dif
            referenceResultSummary.dif(olderResultSummary, referenceResultSummary)
    }
    val difsArray = difs.toArray.asInstanceOf[Array[Double]]
    (difsArray, referenceIndex)
  }

  /**Values of the "progress value" s from result with index 0 to one with indexOfReferenceResult,
   * i.e. the x-axis values of the convergence graph
   * @param indexOfReferenceResult if < 0, the last avail data is used
   * @return Tuple2: (Long[] with values of dif's, last index of ResultSummaries used)
   */
  def getProgs(indexOfReferenceResult: Int): (Array[Long], Int) = {
    val referenceIndex = getIndexOfReferenceResult(indexOfReferenceResult)

    val progresses = collectResultsOfSamplesSlice(0, referenceIndex) {
      sample =>
              sample.outcomeInBytes
    }
    val progressArray = progresses.toArray.asInstanceOf[Array[Long]]
    (progressArray, referenceIndex)
  }

  /**
	* Returns the total number of results
	*/
  def totalResults(): Int = {
	 samples.length
  }

  /** Returns complete progresses and differences as a Tuple2 of two arrays */
  def getProgsAndDiffs: (Array[Long], Array[Double]) = {

    // Just get what ResultStore has ..
    val (differences, lastIndex) = getDifs(0, -1)  // get the y-axis - values of metric dif
    val (progresses, dummy) = getProgs(lastIndex) // get the x-axis - progresses for each dif computation

    (progresses, differences)
  }

  def getRawResults(indexOfReferenceResult: Int): (Array[Any], Int) = {
    val referenceIndex = getIndexOfReferenceResult(indexOfReferenceResult)

    val rawResults = collectResultsOfSamplesSlice(0, referenceIndex) {
      sample => sample.rawResult
    }
    val rawResultsArray = rawResults.toArray.asInstanceOf[Array[Any]]
    (rawResultsArray, referenceIndex)
  }

  def getResultSummaries(indexOfReferenceResult: Int): (Array[Any], Int) = {
    val referenceIndex = getIndexOfReferenceResult(indexOfReferenceResult)
    val summaries = collectResultsOfSamplesSlice(0, referenceIndex) {
      sample => sample.resSummary
    }
    (summaries.toArray.asInstanceOf[Array[Any]], referenceIndex)
  }

  /** Convenience method which appends XY result to a StringBuffer */
  def toStringBuffer(progresses: Array[Double], differences: Array[Double], output:StringBuffer) = {

    // Plain, still unstructured output appended to output
    // output.setLength(0)    // reset output buffer

    val size = totalResults()
    output.append("ResultStore.size = ").append(size)
    output.append("\n<progress>, <dif value>")
    for (row <- 0 until size) {
      output.append("\n")
      output.append(progresses(row))
      output.append(", ")
      output.append(differences(row))
    }
    output.append("\n")
  }


  /** Convenience method which emits result to a Environment emit* method */
  def emitResults(progresses: Array[Double], differences: Array[Double]) {
    val size = totalResults()

    for (row <- 0 until size) {
      val x = progresses(row).asInstanceOf[Float]
      val y = differences(row).asInstanceOf[Float]
      ResultEmitter.emitAnalyzerResult(x, y)
    }
  }

  def emitAllResults() {
	 // for the stats.dat
    // format: progress, dif_final, dif_previous, time, mem usage
	 val sortedSamples = stableSort(samples)
	 var prevSample = sortedSamples.head
	 val lastSample = sortedSamples.last

	 // outputs the header
	 ResultEmitter.emitAnalyzer("outcome_in_bytes dif_final dif_previous time mem")

	 for(sample <- sortedSamples) {
		ResultEmitter.emitAnalyzer(sample.outcomeInBytes + " " +
							  sample.resSummary.dif(sample.resSummary, lastSample.resSummary) + " " +
							  sample.resSummary.dif(sample.resSummary, prevSample.resSummary) + " " +
							  sample.timeStored + " " +
							  sample.memUsage)
		prevSample = sample
	 }

	 // for R.dat
	 ResultEmitter.emit(lastSample.resSummary.toString)
  }

  
  // emits all intermediate results
  def emitAllIntermediateResults() {
		for(sample <- stableSort(samples)){
			ResultEmitter.emit("outcome in bytes: " + sample.outcomeInBytes)
			ResultEmitter.emit(sample.resSummary.toString)
		}  
  }
  
  
  private def getIndexOfReferenceResult(indexOfReferenceResult: Int): Int = {
    assert(indexOfReferenceResult < samples.size || samples.size == 0,
      "Cannot use result with index " + indexOfReferenceResult + " as the latest one," +
              "as there are only " + samples.size + " stored results")

    val refIndex = if (indexOfReferenceResult < 0) samples.size - 1 else indexOfReferenceResult
    refIndex
  }


  /* Collects results yielded by operator applief to each element of "samples" array */
  private def collectResultsOfSamplesSlice(firstIndex: Int, lastIndex: Int)(operator: Sample => Any): Seq[Any] = {
    val res = for{i <- firstIndex to lastIndex}
    yield operator(samples(i))
    res
  }

}

/** For storing a provided sample
  * todo: can we use a more universal data structure instead, like a ColumnMatrix (see below)?
 */

class Sample extends Ordered[Sample] {
  var outcomeInBytes: Long = 0L
  var resSummary: ResultSummary = null
  var rawResult: Any = null
  var timeStored: Long = 0
  var memUsage:Long = 0

  override def compare(that:Sample):Int = 
	 this.timeStored compare that.timeStored
}

/**A prototype of a "matrix" whose (named) columns are extensible arrays */
class ColumnMatrix(namesOfColumns: Seq[String]) {

  // create internal data structure as a list of arrays
  val numCols = namesOfColumns.size
  val data = new Array[ArrayBuffer[Any]](numCols)

}
