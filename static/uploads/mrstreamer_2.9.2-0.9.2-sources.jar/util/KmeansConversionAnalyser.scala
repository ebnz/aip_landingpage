/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

//import org.apache.mahout.matrix.{DenseVector, Vector}
import org.apache.mahout.math.{DenseVector, DenseVectorWritable, Vector}
import java.io.{File,FileInputStream,DataInputStream,InputStreamReader,BufferedReader,FileWriter,BufferedWriter}
import algorithms.kmeans.Cluster

object KmeansConversionAnalyser extends ScalaIO {



def main(args:Array[String]){

	var cp:String = "./shadow/results/km-c-conv1/online_R_num_mappers_32_buffer_size_km_100_num_aux_cluster_0_rep_0.dat"
	if(args.length!=1){
	  println("usage: <path-to-logfile>")
	  System.exit(1)
	}else{
	  cp = args(0)
	}
// val cp:String = "./shadow/results/km-c-conv1/online_R_num_mappers_32_buffer_size_km_100_num_aux_cluster_0_rep_0.dat"

    val dp:String = "./testdata/kmeans/USCensus1990.data.txt"
    val res:Array[(String, Double)] = new Array[(String, Double)](101)

    println("starting ...")

    // first element
    res(0)= Tuple2("0",0.0)

    // read intermediate centroids
    val fstream:FileInputStream = new FileInputStream(cp)
    val in:DataInputStream = new DataInputStream(fstream);
    val br:BufferedReader = new BufferedReader(new InputStreamReader(in));
    var line:String = br.readLine()

    // read final result
	var fin:Array[Cluster] = new Array[Cluster](5)
	for(i<-0 to 4){
		   fin(i) = new Cluster(readVector(line),null,0,0.0)
		   line = br.readLine()
	}
    // calculate error in final results
    res(100)=Tuple2("1.0",calcError(fin,dp))
    println("calcuated final Error")

     // read remaining data
     var i:Int = 1
	 while(line != null) {
	   if(line.startsWith("progress")){
	     var prog:String = line.split(":")(1)
	     var cent:Array[Cluster] = new Array[Cluster](5)
	     for(j<-0 to 4){
	    	 line = br.readLine()
	    	 cent(j)=new Cluster(readVector(line),null,0,0.0)
	     }
	     var er:Double = calcError(cent,dp)
	     res(i)=Tuple2(prog,er)
	     println(prog+" "+er)
	     i=i+1
	   }
	   line = br.readLine
	 }
	 in.close()
	 println("1.0  "+res(100)._2)
	 saveConversionToFile(cp+".conversion", res)
     println("done")
 }



def saveConversionToFile(rf:String,dat:Array[(String, Double)]){
	println("saving results to file "+rf)
	var resultFile:File = new File(rf)
//    resultFile.createNewFile()
	var resultsOut:BufferedWriter = new BufferedWriter(new FileWriter(resultFile))

 	for(i<-1 to dat.length-1){
 	  println(i)
 	  resultsOut.write(dat(i)._1 + " "+dat(i)._2 + "\n")
 	}
 	resultsOut.flush()
 	resultsOut.close()
}



def readVector(str:String):DenseVectorWritable={
  var elements: List[String] = str.split(' ').toList
  var doubleElements:Array[Double] = new Array[Double](68)
  var i:Int = 0
  for(e <- elements){
		  try{
		    var delem:Double = e.toDouble
		    doubleElements(i) = delem
	    	i=i+1
		  }catch{
		    case nfe: NumberFormatException => println("found wrong format") // anything?
		  }
   }

   new DenseVectorWritable(new DenseVector(doubleElements))
}


def printErrors(dat:Array[(String, Double)]){
   for(i<-0 to dat.length-1){
     println(dat(i)._1 + " "+dat(i)._2)
   }
 }


// calculates the mean square error for the original data
def calcError(centroids:Array[Cluster], data_path:String):Double={

  // read in sample
  var error:Double = 0.0
  forFileLines(data_path){ line =>

	  var sampleList:List[String] = line.split(',').toList
	  sampleList = sampleList.tail
	  var sampleArray:Array[Double] = new Array[Double](68)
	  var j:Int = 0

	   for(e <- sampleList){
		    sampleArray(j) = e.toDouble
			j=j+1
	   }
	   var sample:Vector = new DenseVectorWritable(new DenseVector(sampleArray))


	   var dist:Double = Double.MaxValue
	   var tempdist:Double = 0.0
	   var cs:Int = 0

	   // find the closests centroid
	   for(i<-0 to centroids.length-1){
	      tempdist = centroids(i).distanceTo(sample)
	      if(tempdist<dist){
	        dist = tempdist
	        cs = i
	     }
	   }
	   error+=dist
  }
  error
 }

}
