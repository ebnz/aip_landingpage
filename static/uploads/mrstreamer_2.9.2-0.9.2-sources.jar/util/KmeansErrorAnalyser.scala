/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

//import org.apache.mahout.matrix.{DenseVector, Vector}
import org.apache.mahout.math.{DenseVector, DenseVectorWritable, Vector}
import java.io.{File, FilenameFilter}
import algorithms.kmeans.Cluster

object KmeansErrorAnalyser extends ScalaIO{

  var mlError:Double = 0.0


  def main(args:Array[String]){

    // compute MSE for matlab result
    val cp:String = "./testdata/kmeans/centroids.dat"
    val dp:String = "./testdata/kmeans/USCensus1990.data.txt"

    mlError = calcError(cp,dp)

    // calculate MSE for streaming results
    var filePath:File = new File("./shadow/results/tmp/")
    var files:Array[File] = filePath.listFiles(new FileFilter)

    // result structure
    var erMap:Array[(String, Double)]=new Array[(String, Double)](files.length)

    for(i<-0 to files.length-1){
        var params:Array[String] = files(i).getPath.split("_")
 //       println(files(i).getPath)
        var numMap:String = params(4)
    	erMap(i)=new Tuple2(numMap,calcError(files(i).getPath,dp))
 //   	println(i+" "+erMap(i)._2)
    }

    printErrors(erMap)

    println("ML: "+mlError)

  }



 def printErrors(dat:Array[(String, Double)]){
   for(i<-0 to dat.length-1){
     println(dat(i)._1 + " "+dat(i)._2)
   }
 }


  // calculates the mean square error for the original data
 def calcError(c_path:String, data_path:String):Double={

   // load centroids
   var centroids = new Array[Cluster](5)
   var is_list:List[DenseVectorWritable] = Nil
   forFileLines(c_path) { line =>
	  var elements:List[String] = line.split(' ').toList
	  var doubleElements:Array[Double] = new Array[Double](68)
	  var i:Int = 0
	  for(e <- elements){
		  try{
		    var delem:Double = e.toDouble
		    doubleElements(i) = delem
	    	i=i+1
		  }catch{
		    case nfe: NumberFormatException => // anything?
		  }
	  }
      var vector:DenseVectorWritable = new DenseVectorWritable(new DenseVector(doubleElements))
      is_list = vector :: is_list
	}
	centroids.asInstanceOf[Array[Cluster]](0) =  new Cluster(is_list.apply(0),null,0,0.0)
    centroids.asInstanceOf[Array[Cluster]](1) =  new Cluster(is_list.apply(1),null,0,0.0)
	centroids.asInstanceOf[Array[Cluster]](2) =  new Cluster(is_list.apply(2),null,0,0.0)
	centroids.asInstanceOf[Array[Cluster]](3) =  new Cluster(is_list.apply(3),null,0,0.0)
	centroids.asInstanceOf[Array[Cluster]](4) =  new Cluster(is_list.apply(4),null,0,0.0)

  // read in sample
  var error:Double = 0.0
  forFileLines(data_path){ line =>

	  var sampleList:List[String] = line.split(',').toList
	  sampleList = sampleList.tail
	  var sampleArray:Array[Double] = new Array[Double](68)
	  var j:Int = 0

	   for(e <- sampleList){
		    sampleArray(j) = e.toDouble
			j=j+1
	   }
	   var sample:Vector = new DenseVectorWritable(new DenseVector(sampleArray))


	   var dist:Double = Double.MaxValue
	   var tempdist:Double = 0.0
	   var cs:Int = 0

	   // find the closests centroid
	   for(i<-0 to centroids.length-1){
	      tempdist = centroids(i).distanceTo(sample)
	      if(tempdist<dist){
	        dist = tempdist
	        cs = i
	     }
	   }
	   error+=dist
  }
  error
 }

 }

 class FileFilter extends FilenameFilter{

   def accept(dir:File, name:String):Boolean={
     var result:Boolean = false
     if(name!=null){
       result = name.startsWith("online_R")
     }

     result
   }
 }

