/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

/**
 * Created by IntelliJ IDEA.
 * User: Artur Andrzejak
 * Date: 10.10.2009
 * Time: 19:29:32
 * @description: A convenience counter which counts from 0 to threshold at each call, and if threshold is reached, reverts to 0
 * @description:
 */

trait Counter {

  /**Upper bound for counting */
  private var threshold = -1
  private var counterValue: Int = 0

  /**At each call, counts +1, and if threshold is passed, returs true
   *
   */
  def isCounterThresholdReached: Boolean = {
    require(threshold > 0, "Counter used before threshold is set")
    var result = false
    counterValue += 1
    if (counterValue >= threshold) {
      counterValue = 0
      result = true
    }
    result
  }

  def setCounterThreshold(newTreshold: Int) {
    threshold = newTreshold
  }


}