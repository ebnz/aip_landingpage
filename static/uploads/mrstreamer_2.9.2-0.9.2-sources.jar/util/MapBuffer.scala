/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

import collection.mutable.ListBuffer

/**
 * Map for buffering key-value pairs. This buffer is thread-safe.
 *
 * User: flangner
 * Date: 12.08.2010
 * Time: 18:50:21
 *
 * @param bufferSize - if less than 0 the buffer will only be flushed manually <br>
 *                     if 0 input will not be buffered but returned immediately <br>
 *                     otherwise pairs will be buffered till bufferSize has exceeded and grouped by their keys
 * @param method - function to execute
 */

class MapBuffer (bufferSize: Int, method: (Any, ListBuffer[Any]) => Unit) {

  private var buffer: Map[Any, ListBuffer[Any]] = Map.empty

  private var size: Int = 0

  /**
   * Add a key value pair to the buffer.
   *
   * @param key
   * @param value
   */
  def add (key: Any, value: Any) {
    add(key, ListBuffer(value))
  }

  /**
   * Add a key values pair to the buffer. Values have already been grouped by their key.
   *
   * @param key
   * @param values
   */
  def add (key: Any, values: ListBuffer[Any]) {

    // append values to the buffer
    if (bufferSize != 0) {
      synchronized {
        size += values.length

        if (buffer.contains(key)) {

          buffer(key) ++= values
        } else {

          buffer += key -> values
        }

        // check if threshold has been exceeded and messages have to be send from the buffer
        if(bufferSize > 0 && this.size >= bufferSize) flush()
      }
    } else {

      method (key, values)
    }
  }

  /**
   * @return true, if there is no buffered data available anymore, false otherwise.
   */
  def isEmpty: Boolean = {
    synchronized {
      return size == 0
    }
  }

  /**
   *  Flushing the buffer.
   */
  def flush() {

    var buf: Map[Any, ListBuffer[Any]] = null
    synchronized {
      buf = buffer
      size = 0
      buffer = Map.empty
    }
    
    for (entry: (Any, ListBuffer[Any]) <- buf) {
      method (entry._1, entry._2)
    }
  }
}