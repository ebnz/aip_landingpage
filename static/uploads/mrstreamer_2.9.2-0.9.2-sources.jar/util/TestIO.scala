/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util
import java.io.{File, FileInputStream, DataInputStream, BufferedReader, InputStreamReader}

object TestIO extends ScalaIO {
  var inputPath = ""

  def main(args: Array[String]) {
    /*
    object Opts extends CommandLineParser {
      val inputPath = new StringOption('i', "input-path", "Path to the input data") with AllowAll

	 }
	 
    Opts.parseOrHelp(args) {
      cmd =>
        inputPath = cmd(Opts.inputPath).getOrElse("")
    }   */

	 if(inputPath == "") {
		println("Input path not defined")
		System.exit(-1)
	 }

	 println("reading with java")
	 readDataJava(inputPath)
//	 println("reading with scala")
//	 readData(inputPath)
  }

  def readDataJava(path:String) {
	 val fstream:FileInputStream = new FileInputStream(path)
	 val in:DataInputStream = new DataInputStream(fstream);
    val br:BufferedReader = new BufferedReader(new InputStreamReader(in));
    var strLine:String = ""
    //Read File Line By Line
    while (br.readLine() != null)   {
      // Print the content on the console
//      System.out.println (strLine);
    }
    //Close the input stream
    in.close();
  }

  def readData(path:String) {
    forFileLines(path) { line =>
		line
	 }
  }

}
