/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

import org.apache.hadoop.mapred.JobConf
import java.io.File

import algorithms.wc.RelativeWordCountCollector
import streaming.MRStreamer
import algorithms.kmeans.KmeansTest

object Experiments {
  def main(args: Array[String]) {

    var help: String = "-c -i -t -profile -m -r -combiner-buffer-size -collector-buffer-size"
    val pp = "bla"

    /*
    object Opts extends CommandLineParser {
      val mrClass = new StringOption('c', "mr-class", "Canonical name of the class implementing Mapper and Reducer (MRClass)") with AllowAll
      val inputPath = new StringOption('i', "input-path", "Path to the input data") with AllowAll
      val testPath = new StringOption('t', "test-path", "Path to correct test data, used by algorithms to measure error, e.g. Naive Bayes miss classification") with AllowAll
      val profile = new Flag("profile", "Indicates if to profile or not.") with AllowAll

      val numMappers = new IntOption('m', "mappers", "Number of map executors") with AllowAll
      val numReducers = new IntOption('r', "reducers", "Number of reduce executors") with AllowAll
      val combinerBufferSize = new IntOption("combiner-buffer-size", "Size of the Combiner(!) buffer") with AllowAll
      val collectorBufferSize = new IntOption("collector-buffer-size", "Size of the Map Workers collector buffer, regulates offline/online-mode. A value of 0 means offline.") with AllowAll
      val statsPath = new StringOption('s', "stats-path", "Path to the statistics data") with AllowAll
      val numkcluster = new IntOption("kmcluster", "Number of clusters used by kmeans") with AllowAll
      val numauxCluster = new IntOption("kmauxcluster", "Number of aux cluster used in kmeans") with AllowAll
      val kmbuffer = new IntOption("kmbuffer","Size of sample buffer at mapper in kmeans") with AllowAll
      val krefitint = new IntOption("kmrfitint", "Intervall in which global clusters are refitted") with AllowAll
    }
    */

    var mrClass:String = ""
    var inputPath:String = ""
    var testPath:String = ""
    var mappers:Int = 2
    var reducers:Int = 4
	 var statsPath:String = ""
	 var bufferSize:Int = 10
	 var collectorBufferSize:Int = 10
	 var profile:Boolean = false 
  
	 // kmeans specific
	 var kcluster:Int = 5
	 var kauxcluster:Int = 1000
	 var skmbuffer:Int = 100
      /*
    Opts.parseOrHelp(args) {
      cmd =>
		  mrClass = cmd(Opts.mrClass).getOrElse("")
        inputPath = cmd(Opts.inputPath).getOrElse("")
        testPath = cmd(Opts.testPath).getOrElse("")
        mappers = cmd(Opts.numMappers).getOrElse(mappers)
        reducers = cmd(Opts.numReducers).getOrElse(reducers)
		  statsPath = cmd(Opts.statsPath).getOrElse("./")
		  profile = if(cmd(Opts.profile)) true else false
        bufferSize = cmd(Opts.combinerBufferSize).getOrElse(bufferSize)
        collectorBufferSize = cmd(Opts.collectorBufferSize).getOrElse(collectorBufferSize)
        kcluster = cmd(Opts.numkcluster).getOrElse(kcluster)
        kauxcluster = cmd(Opts.numauxCluster).getOrElse(kauxcluster)
        skmbuffer = cmd(Opts.kmbuffer).getOrElse(skmbuffer)
    }
        */
       println("class: " + mrClass)
       println("input path: " + inputPath)
    
    var input: Array[(Any, Any)] = new Array[(Any, Any)](1)
	var path: File = new File(inputPath)

	 if(path.isFile) {
		input(0) = new Tuple2(inputPath, null)
	 } else {
	   
		input = for (file <- new File(inputPath).listFiles 
								if !file.isDirectory) yield new Tuple2(inputPath + file.getName, null)
	 }

	         val conf = new JobConf
    conf.set("mrstreamer.statsLogFile", statsPath)


	 val canonMrClass = mrClass match {
		case "algorithms.linreg.LinReg" =>
	     "algorithms.matrix.MatrixSumsMR"
		case "algorithms.pca.PCA" =>
	     "algorithms.matrix.MatrixSumsMR"
		case "algorithms.nb.NaiveBayesDummy" =>
	     "algorithms.nb.NaiveBayes"
		case a => a
	 }

	 val collector:String = mrClass match {
		case "algorithms.wc.RelWC" =>
		  "algorithms.wc.RelativeWordCountCollector"
		case "algorithms.wc.RelWordCount" =>
		  "algorithms.wc.RelativeWordCountCollector"
		case "algorithms.wc.TotalWordCount" =>
		  "streaming.DummyReduceCollector"
		case "algorithms.linreg.LinReg" =>
		  // could be either lin reg or PCA
		  // matrixSumsMR settings
		  conf.set("matrixSumsMR.lineLen", "5")
		  conf.set("matrixSumsMR.numComputationsToCollect", bufferSize.toString)
		  conf.set("matrixSumsMR.scale_Bsum_by_last_column", "true")
		  conf.set("resultRecomputationInterval", "5")
		  // always outputs to exactly 2 reducers
		  reducers = 2
		  "algorithms.linreg.LinRegCollectorScala"
		case "algorithms.pca.PCA" =>
		  // could be either lin reg or PCA
		  // matrixSumsMR settings
		  conf.set("matrixSumsMR.lineLen", "5")
		  conf.set("matrixSumsMR.numComputationsToCollect", bufferSize.toString)
		  conf.set("matrixSumsMR.scale_Bsum_by_last_column", "true")
		  conf.set("pca.resultRecomputationInterval", "5")
		  // always outputs to exactly 2 reducers
		  reducers = 2
		  "algorithms.pca.PcaCollector"
		case "algorithms.linreg.LinRegTest" =>
		  "algorithms.linreg.LinRegTest"
		case "algorithms.nb.NaiveBayes" =>
		  "algorithms.nb.NaiveBayesCollector"
		case "algorithms.nb.NaiveBayesDummy" =>
		  "algorithms.nb.NaiveBayesDummyCollector"
		case "algorithms.kmeans.KMeans" =>
		  // init the env specific to KMeans
		  conf.set("mrstreamer.mapCollectorBufferSize","10")
		  conf.set("mrstreamer.numCluster", kcluster+"")
		  conf.set("mrstreamer.numAuxCluster", kauxcluster+"")
		  conf.set("mrstreamer.kmBufferSize", skmbuffer+"")
		  reducers = 1
		  "algorithms.kmeans.KMeansCollector"
		case _ => 
		  println("mrClass or collector is not correct")
		  System.exit(-1)
		  "" // whatever, this will never be reached
	 }
 
	conf.set("mrstreamer.mapAlgorithm", canonMrClass)
	conf.set("mrstreamer.reduceAlgorithm", canonMrClass)
 	conf.set("mrstreamer.collectorAlgorithm", collector)
 	conf.set("mrstreamer.mapCollectorBufferSize", collectorBufferSize.toString)
	conf.set("mrstreamer.statsPath", statsPath)
	conf.set("mrstreamer.testPath", testPath)
	conf.set("mrstreamer.statThresholdStep", "0.01")
	conf.set("mrstreamer.printResultsOnScreen", "false") 
	conf.set("mrstreamer.profile", profile.toString) 

//    var maxThreads:Int = ((mappers + reducers + 1)*2)
//    System.setProperty("actors.maxPoolSize", "32")

    val sim: MRStreamer = new MRStreamer(conf, input)
    //sim.configure(mappers, reducers)
    sim.run
  }
}
