/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

import org.apache.hadoop.conf.Configuration
import java.io.{IOException, FileWriter, File, BufferedWriter}
import grizzled.slf4j.Logging

/**
 * This Object is used to write the Algorithm's results and it's stats to the disk.
 *
 * User: flangner
 * Date: 19.07.2010
 * Time: 19:04:31
 */

object ResultEmitter extends Logging {
  
  private var dataOut: BufferedWriter = null
  private var resultsOut: BufferedWriter = null

  def init (conf: Configuration) {
    if (dataOut == null && resultsOut == null) {

      var f: File = new File(conf.get("mrstreamer.statsLogFile"))
      f.createNewFile
      dataOut = new BufferedWriter(new FileWriter(f))

      var rFile: String = conf.get("mrstreamer.resultFile")
      if (rFile.equals("")) {
        rFile = "result-" + conf.get("mrstreamer.statsLogFile")
        conf.set("mrstreamer.resultFile", rFile)
      }

      var rf: File = new File(rFile)
      rf.createNewFile
      resultsOut = new BufferedWriter(new FileWriter(rf))
    }
  }

/*
 * emit analyzer
 */

  /*
   * write a result tuple for plotting
   */
  def emitAnalyzerResult(x: Float, y: Float) {
    emitAnalyzer(x + " " + y)
  }

  /*
   * write a result triple for plotting
   */
  def emitAnalyzerResult(x: Float, y: Float, z: Float) {
    emitAnalyzer(x + " " + y + " " + z)
  }

  /*
   * write four result values for plotting
   *
   */
  def emitAnalyzerResult(w: Double, x: Double, y: Double, z: Double) {
    emitAnalyzer(w + " " + x + " " + y + " " + z)
  }

  /* emits data to the main stat file for plotting */
  def emitAnalyzer(entry: String) {
    try {
      resultsOut.write(entry + "\n")
      resultsOut.flush()
    }
    catch {
      case e: IOException => {
        e.printStackTrace()
      }
    }
  }

  /* emits entries to the log file */
  def emit(entry: String) {
    try {
      dataOut.write(entry + "\n")
      dataOut.flush()
    }
    catch {
      case e: IOException => {
        e.printStackTrace()
      }
    }
  }
}