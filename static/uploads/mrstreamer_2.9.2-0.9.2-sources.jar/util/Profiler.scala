/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

import java.io.FileWriter
import compat.Platform.currentTime

/**
 * Each ProfileRecord is used to record when the worker (map/reducer) started and
 * how long it was allowed to run.
 */
case class ProfileRecord(name:String, start:Long, end:Long)

object Profiler {
  var profileRecords = List[ProfileRecord]()
  var profileFile:FileWriter = null 
  val profileBufferThreshold = 100000
  var profile:Boolean = false
  var start:Long = 0

  def init(basePath:String) {
	 start = currentTime
	 profileFile = new FileWriter(basePath + "profile.dat")
  }

  def recordProfile(rec:ProfileRecord) {
	 if(profile) {
		profileRecords = rec :: profileRecords

		if(profileRecords.length > profileBufferThreshold)
		  dumpProfileRecords()
	 }
  }

  def dumpProfileRecords() {
	 profileRecords.foreach { r => profileFile.write(r.name + "\t" + r.start + "\t" + r.end + "\n") }
	 profileFile.flush()
	 profileRecords = List[ProfileRecord]()
  }

  def finish() {
	 profileFile.close()
  }
}
