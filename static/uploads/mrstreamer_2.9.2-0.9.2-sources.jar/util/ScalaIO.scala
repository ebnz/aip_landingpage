/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util

/**
 * @author Artur Andrzejak
 * @date: 08.10.2009 - 19:34:21
 * @description: A couple of convenience methods to simplify IO, parsing etc.
 * @description: in Scala
 */

import scala.io.Source
import java.lang.Double.parseDouble
import java.io.File

trait ScalaIO {

  /**Opens and reads file line by line, allowing execution of the closure fun
   * per each line
   *
   * Usage:
   * withFile("jokes.txt")  { line =>
   *   <code working on line>
   * }
   *
   * Credits to Stefan Plantikow alias Bernhard Oggle
   */
  def forFileLines(fname: String)(fun: String => Unit) {    
    val source: Source = Source.fromFile(new File(fname))
    val lines: Iterator[String] = source.getLines()  
    while (lines.hasNext) {
      fun(lines.next())
    }
    source.close()
  }


  /**Splits a line into tokens and converts each one into a double
   *
   * @param line input text line
   * @param result array of doubles - must be pre-allocated
   * @param separator regext representing the separator
   * todo: could be made faster with java.util.Scanner
   */
  def parseDoubles(line: String, result: Array[Double], separator: String) {

    val tokens = line.trim().split(separator)

    for (pos <- 0 until result.length) {
      result(pos) = parseDouble(tokens(pos));
    }
  }
}
