/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer

import akka.actor.Actor
import akka.actor.Actor.remote
import grizzled.slf4j.Logging
import com.google.common.io.Files
import java.io.File
import org.apache.commons.io.FileUtils
import java.net.{URL, URLClassLoader}
import collection.mutable.HashMap
import collection.immutable.ListSet
import java.util.UUID

class WorkerActor extends Actor with Logging {

  val tempDir = Files.createTempDir()
  //val jarMap = new HashMap[String, URL]
  var jars: Set[URL] = new ListSet[URL]
  var cl: Option[ClassLoader] = None
  var actorCounter = 0

  protected def receive = {
    case UploadJar(fileName, content) => {
      val jar = new File(tempDir, fileName)
      FileUtils.writeByteArrayToFile(jar, content)
      jars += jar.toURL
      //jarMap += fileName -> jar.toURL
      //val cl = new URLClassLoader(Array(jar.toURL))
      self.reply("Done!")
      info("Got jar file " + fileName)
      cl = Some(new URLClassLoader(jars.toArray))
    }
    case StartJob(jarFile, mainClass, args) => {
      Actor.spawn {
        try {
          val clazz = cl.get.loadClass(mainClass)
          val main = clazz.getDeclaredMethod("main", classOf[Array[String]])
          main.invoke(null, args.toArray) // TODO: Redirect console output to invoker?
          //self.reply("Successfully ran " + mainClass)
        } catch {
          case ex: Exception => {
            val msg = "Error starting job with main method in " + mainClass + " in JAR " + jarFile + ex.getLocalizedMessage
            error(msg, ex)
            //self.reply(msg)
          }
        }
      }
    }

    case "getClassLoader" => {
      cl foreach self.reply
    }

    case StartActor(clazz) => {
      val actorName = clazz.toString + "-" + actorCounter + " running on " + remote.address.getHostName + ":" + remote.address.getPort
      actorCounter += 1
      try {
        val actorClass = cl.get.loadClass(clazz.getName)
        val actorRef = Actor.actorOf(actorClass.newInstance().asInstanceOf[Actor])
        remote.register(actorName, actorRef)
        debug("Started actor " + actorName)
        self.channel ! (ActorInfo(actorName, remote.address.getHostName, remote.address.getPort))
      } catch {
        case ex: ClassNotFoundException => {
          error("Error loading actor class " + clazz.getName, ex)

        }
      }
    }

  }

}
