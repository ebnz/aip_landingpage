/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer

import grizzled.slf4j.Logging
import akka.actor.Actor._
import java.net.InetAddress
import akka.actor.{Actor, ActorRef}
import java.{util => ju, lang => jl}
import java.io.File
import collection.JavaConversions._
import org.apache.felix.gogo.commands.{Action, Option => option, Argument => argument, Command => command}
import org.apache.felix.service.command.CommandSession
import org.apache.karaf.shell.console.Main
import java.util.Collection
import java.util.concurrent.{SynchronousQueue, TimeUnit, BlockingQueue}

object Worker {
  var workerActor:Option[ActorRef] = None
  var workerManager:Option[ActorRef] = None
}