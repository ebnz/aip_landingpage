package de.uni_heidelberg.ifi.pvs.mrstreamer.cli

/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.karaf.shell.console.Main
import grizzled.slf4j.Logging
import org.apache.felix.service.command.CommandSession
import java.{util => ju, lang => jl}
import collection.JavaConversions._
import org.apache.felix.gogo.commands.{Action, Option => option, Argument => argument, Command => command}
import org.slf4j.LoggerFactory
import ch.qos.logback.classic.joran.JoranConfigurator
import ch.qos.logback.classic.LoggerContext
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.core.joran.spi.JoranException

object MRStreamerMain {
  def main(args: Array[String]) {
    new MRStreamerMain().run(args)
  }
}

@command(scope = "mrstreamer", name = "mrstreamer", description = "Executes a mrstreamer command interpreter")
class MRStreamerMain extends Main with Action with Logging {
  val context = LoggerFactory.getILoggerFactory.asInstanceOf[LoggerContext]

  try {
    val configurator = new JoranConfigurator()
    configurator.setContext(context)
    // Call context.reset() to clear any previous configuration, e.g. default
    // configuration. For multi-step configuration, omit calling context.reset().
    context.reset()
    configurator.doConfigure("/home/silvestre/MapReduce/mrstreamer/src/main/resources/logback.xml") //FIXME
  } catch {
    case je: JoranException => {} // StatusPrinter will handle this
  }
  StatusPrinter.printInCaseOfErrorsOrWarnings(context);

  setUser("me")
  setApplication("mrstreamer")

  var debug = true

  override def getDiscoveryResource = "cli/commands.index"

  override def isMultiScopeMode() = false

  @argument(name = "args", description = "scalate sub command arguments", multiValued = true)
  var args = Array[String]()

  def execute(session: CommandSession): AnyRef = {
    info("Wohoo main")
    run(session, args)
    null
  }
}