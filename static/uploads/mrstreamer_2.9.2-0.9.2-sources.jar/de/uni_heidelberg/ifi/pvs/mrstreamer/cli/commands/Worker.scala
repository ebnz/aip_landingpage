/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer.cli.commands

import grizzled.slf4j.Logging
import akka.actor.Actor._
import java.net.InetAddress
import akka.actor.Actor
import org.apache.felix.gogo.commands.{Action, Option => option, Argument => argument, Command => command}
import org.apache.felix.service.command.CommandSession
import de.uni_heidelberg.ifi.pvs.mrstreamer.{Worker => WorkerRegistry, RegisterWorker, WorkerActor}

@command(scope = "mrstreamer", name = "worker", description = "Starts a worker and connects to the server in order to " +
  "run parts of submitted MapReduce programs")
class Worker extends Action with Logging {

  val workerId = "mrstreamer-worker-actor"

  @option(required = true, name = "--serverHost")
  var serverHost: String = _

  @option(required = true, name = "--serverPort")
  var serverPort: Int = _

  @option(name = "--workerHost")
  var workerHost: String = InetAddress.getLocalHost.getHostName

  @option(name = "--workerPort")
  var workerPort: Int = 2553


  def execute(session: CommandSession): AnyRef = {
    remote.start(workerHost, workerPort)
    val workerAddress = remote.address

    remote.register({
      val a = actorOf[WorkerActor]
      a.id = workerId
      a
    })



    import WorkerRegistry._

    workerManager = Some(remote.actorFor("job-tracker", serverHost, serverPort))
    workerManager.get ! RegisterWorker(workerId, workerAddress.getHostName, workerAddress.getPort)
    workerActor = Actor.registry.actorsFor(workerId).headOption
    null
  }
}