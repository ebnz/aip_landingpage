/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer.cli.commands

import akka.actor.Actor._
import grizzled.slf4j.Logging
import org.apache.felix.gogo.commands.{Action, Option => option, Argument => argument, Command => command}
import org.apache.felix.service.command.CommandSession
import de.uni_heidelberg.ifi.pvs.mrstreamer.JobTracker
import org.slf4j.LoggerFactory
import ch.qos.logback.classic.LoggerContext
import ch.qos.logback.classic.joran.JoranConfigurator
import ch.qos.logback.core.joran.spi.JoranException
import ch.qos.logback.core.util.StatusPrinter

@command(scope = "mrstreamer", name = "server", description = "Starts a server and waits for workers to connect in order" +
  " to run parts of submitted MapReduce programs on the workers")
class Server extends Action with Logging {

  @option(name = "--serverHost")
  var serverHost: String = "0.0.0.0"

  @option(name = "--serverPort")
  var serverPort: Int = 2553

  def execute(session: CommandSession): AnyRef = {
    remote.start(serverHost, serverPort)
    val address = remote.address


    info("MRStreamer server started at " + address.getHostName + ":" + address.getPort)

    remote.register("job-tracker", actorOf[JobTracker])

    info("Waiting for workers to connect")

    null
  }
}