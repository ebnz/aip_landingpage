/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer.cli.commands

import grizzled.slf4j.Logging
import java.io.File
import akka.actor.Actor
import org.apache.commons.io.FileUtils
import org.apache.felix.gogo.commands.{Action, Option => option, Argument => argument, Command => command}
import org.apache.felix.service.command.CommandSession
import de.uni_heidelberg.ifi.pvs.mrstreamer.{StartJob, UploadJar}

@command(scope = "mrstreamer", name = "jobSubmitter", description = "Connects to a server and submits a MapReduce program")
class JobSubmitter extends Action with Logging {

  @option(name = "--serverHost")
  var serverHost: String = "localhost"

  @option(name = "--serverPort")
  var serverPort: Int = 2553

  @option(required = true, name = "--jarFile")
  var jarFile: File = _

  @option(required = true, name = "--mainClass")
  var mainClass: String = _

  @argument(name = "args", description = "MapReduce program arguments", multiValued=true)
  var args = Array[String]()

  def execute(session: CommandSession): AnyRef = {

    val jobTracker = Actor.remote.actorFor("job-tracker", serverHost, serverPort)
    if (!jobTracker.isRunning) {
      error("No JobTracker running. Exiting.")
      System.exit(-1);
    }
    if (!jarFile.canRead || !jarFile.isFile) {
      error("Could not read " + jarFile)
      System.exit(-2)
    }
    jobTracker !! UploadJar(jarFile.getName, FileUtils.readFileToByteArray(jarFile))
        val r = jobTracker !! StartJob(jarFile.getName, mainClass, args.toList)
    //    r foreach println
    Actor.registry.shutdownAll()
    //System.exit(0)
    null
  }

}