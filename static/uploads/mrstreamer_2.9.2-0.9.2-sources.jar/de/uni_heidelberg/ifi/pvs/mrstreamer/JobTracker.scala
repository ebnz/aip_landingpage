/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_heidelberg.ifi.pvs.mrstreamer

import grizzled.slf4j.Logging
import akka.actor.Actor._
import akka.dispatch.Futures
import com.google.common.io.Files
import java.io.File
import org.apache.commons.io.FileUtils
import collection.immutable.ListSet
import akka.actor.{ActorRefShared, ActorRef, Actor}

class JobTracker extends Actor with Logging {
  val workers:collection.mutable.Set[ActorRef] = new collection.mutable.HashSet[ActorRef]
  var roundRobinIterator:Iterator[ActorRef] = workers.iterator
  val tempDir = Files.createTempDir()
  var jars: Set[File] = new ListSet[File]

  protected def receive = {
    case UploadJar(fileName, content) => {
      info("Received file " + fileName)
      val jar = new File(tempDir, fileName)
      FileUtils.writeByteArrayToFile(jar, content)
      jars += jar

      val w = workers map (_ !!! UploadJar(fileName, content))
      Futures.awaitAll(w.toList)
    }
    case RegisterWorker(workerId, workerHost, workerPort) => {
      val newWorker = remote.actorFor(workerId, workerHost, workerPort)
      workers += newWorker
      info("New Worker at " + newWorker.getHomeAddress().getHostName + ":" + newWorker.getHomeAddress().getPort + " registered")
      jars foreach (jar => newWorker !! UploadJar(jar.getName,  FileUtils.readFileToByteArray(jar)))
    }
    case msg: StartJob => {
      getNextWorker forward msg
    }
    case msg: StartActor => {
      getNextWorker forward msg
    }
  }
  private def getNextWorker  = if (roundRobinIterator.hasNext)
      roundRobinIterator.next()
    else {
      roundRobinIterator = workers.iterator
      roundRobinIterator.next() // TODO: fails if no workers present
    }

}

case class UploadJar(fileName: String, content: Array[Byte])
case class RegisterWorker(workerId: String, workerHost: String, workerPort: Int)
case class StartJob(jarFile: String, mainClass: String, args: List[String])
case class StartActor(clazz: Class[_ <: akka.actor.Actor])
case class ActorInfo(serviceId: String, hostname: String, port: Int)