/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapred

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is necessary to get access to classes with restricted visibility.
 *
 * User: flangner
 * Date: 22.07.2010
 * Time: 19:14:03
 */

object AccessRestrictionBypass {
	
	val logger = LoggerFactory.getLogger(getClass)

  /**
   * @param className - canonical path name.
   *
   * @return a newly created instance.
   */
  def getInstance(className: String): Any = {
	  val clazz = getClass.getClassLoader.loadClass(className)
	  val constructor = clazz.getDeclaredConstructor()
	  constructor.setAccessible(true)
	  constructor.newInstance()
  }
}