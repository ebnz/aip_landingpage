/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapreduce;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapred.*;

import java.io.IOException;

public class MRSJob extends Job {

    private static Configuration oldConf;

	public MRSJob(Configuration conf, String jobName) throws IOException {
		super(saveConf(conf), jobName);
        setDefaults(getConfiguration());
    }

    private static synchronized void setDefaults(Configuration conf) {
        if( conf.getBoolean("mrstreamer.hadoop.streaming", false) == true ) {
            // we need to fix conf as it is reset by Hadoop to 1
            // in case we are running locally
            // see conf.set("mapreduce.jobtracker.address", "local");
            conf.set(org.apache.hadoop.mapreduce.JobContext.NUM_MAPS, oldConf.get(org.apache.hadoop.mapreduce.JobContext.NUM_MAPS));

            conf.set("mrstreamer.oneForAll", "true");
            conf.set("mrstreamer.numIterations", "2");
            conf.set("mrstreamer.statThresholdStep", "0");
            conf.set("mrstreamer.mapCollectorBufferSize", "0");
            conf.set("mrstreamer.reduceCollectorBufferSize", conf.get(org.apache.hadoop.mapreduce.JobContext.NUM_MAPS, "-1"));
        }
    }

    private static synchronized Configuration saveConf(Configuration conf) {
        oldConf = new Configuration(conf);
        return conf;
    }

    public MRSJob(Configuration conf) throws IOException {
		super(conf);
		// TODO Auto-generated constructor stub
	}

	public MRSJob(Cluster cluster, Configuration conf) throws IOException {
		super(cluster, conf);
		// TODO Auto-generated constructor stub
	}

	public MRSJob(Cluster cluster, JobStatus status, Configuration conf)
			throws IOException {
		super(cluster, status, conf);
		// TODO Auto-generated constructor stub
	}

	public MRSJob(Cluster cluster) throws IOException {
		super(cluster);
		// TODO Auto-generated constructor stub
	}

	public MRSJob() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void submit() throws IOException, InterruptedException,
			ClassNotFoundException {
//		ensureState(JobState.DEFINE);
		setUseNewAPI();
//		status = new MRSJobSubmitter().submitJobInternal(this);
//		state = JobState.RUNNING;
		new MRSJobSubmitter().submitJobInternal(this);
	}

	@Override
	synchronized void updateStatus() throws IOException, InterruptedException {
		// Implement, if nonblocking operation needed
	}

	@Override
	public Counters getCounters() throws IOException, InterruptedException {
		// TODO Implement if counters are needed
		return null;
	}
	
	  /**
	   * Default to the new APIs unless they are explicitly set or the old mapper or
	   * reduce attributes are used.
	   * @throws IOException if the configuration is inconsistant
	   */
	  protected void setUseNewAPI() throws IOException {
	    int numReduces = conf.getNumReduceTasks();
	    String oldMapperClass = "mapred.mapper.class";
	    String oldReduceClass = "mapred.reducer.class";
	    conf.setBooleanIfUnset("mapred.mapper.new-api",
	                           conf.get(oldMapperClass) == null);
	    if (conf.getUseNewMapper()) {
	      String mode = "new map API";
	      ensureNotSet("mapred.input.format.class", mode);
	      ensureNotSet(oldMapperClass, mode);
	      if (numReduces != 0) {
	        ensureNotSet("mapred.partitioner.class", mode);
	       } else {
	        ensureNotSet("mapred.output.format.class", mode);
	      }      
	    } else {
	      String mode = "map compatability";
	      ensureNotSet(INPUT_FORMAT_CLASS_ATTR, mode);
	      ensureNotSet(MAP_CLASS_ATTR, mode);
	      if (numReduces != 0) {
	        ensureNotSet(PARTITIONER_CLASS_ATTR, mode);
	       } else {
	        ensureNotSet(OUTPUT_FORMAT_CLASS_ATTR, mode);
	      }
	    }
	    if (numReduces != 0) {
	      conf.setBooleanIfUnset("mapred.reducer.new-api",
	                             conf.get(oldReduceClass) == null);
	      if (conf.getUseNewReducer()) {
	        String mode = "new reduce API";
	        ensureNotSet("mapred.output.format.class", mode);
	        ensureNotSet(oldReduceClass, mode);   
	      } else {
	        String mode = "reduce compatability";
	        ensureNotSet(OUTPUT_FORMAT_CLASS_ATTR, mode);
	        ensureNotSet(REDUCE_CLASS_ATTR, mode);   
	      }
	    }   
	  }

	  private void ensureNotSet(String attr, String msg) throws IOException {
		    if (conf.get(attr) != null) {
		      throw new IOException(attr + " is incompatible with " + msg + " mode.");
		    }    
		  }
	  
	  /**
	   * Submit the job to the cluster and wait for it to finish.
	   * @param verbose print the progress to the user
	   * @return true if the job succeeded
	   * @throws IOException thrown if the communication with the 
	   *         <code>JobTracker</code> is lost
	   */
	  @Override
	  public boolean waitForCompletion(boolean verbose
	                                   ) throws IOException, InterruptedException,
	                                            ClassNotFoundException {
//	    if (state == JobState.DEFINE) {
	      submit();
//	    }
//	    if (verbose) {
//	      monitorAndPrintJob();
//	    } else {
//	      // get the completion poll interval from the client.
//	      int completionPollIntervalMillis = 
//	        Job.getCompletionPollInterval(cluster.getConf());
//	      while (!isComplete()) {
//	        try {
//	          Thread.sleep(completionPollIntervalMillis);
//	        } catch (InterruptedException ie) {
//	        }
//	      }
//	    }
//	    return isSuccessful();
	    return true;
	  }


}
