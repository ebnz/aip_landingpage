/*
 * Copyright 2012
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapreduce;


import org.apache.hadoop.mapreduce.lib.reduce.WrappedReducer;

import java.io.IOException;

public abstract class MRReducer<KEYIN, VALUEIN, KEYOUT, VALUEOUT, REMAPOUT> extends Reducer<KEYIN, VALUEIN, KEYOUT, VALUEOUT> {

//    protected void setup(MRReduceContext<KEYIN,VALUEIN,KEYOUT,VALUEOUT,REMAPOUT> context) throws IOException, InterruptedException {
//    }

    protected void reduce(KEYIN key, java.lang.Iterable<VALUEIN> values, MRReduceContext<KEYIN,VALUEIN,KEYOUT,VALUEOUT,REMAPOUT> context) throws java.io.IOException, java.lang.InterruptedException {
        for (VALUEIN value : values) {
            context.write((KEYOUT) key, (VALUEOUT) value);
        }
    }

    public void run(MRReduceContext<KEYIN,VALUEIN,KEYOUT,VALUEOUT,REMAPOUT> context) throws IOException, InterruptedException {
        setup(new WrappedReducer<KEYIN,VALUEIN,KEYOUT,VALUEOUT>().getReducerContext(context));
        while (context.nextKey()) {
            reduce(context.getCurrentKey(), context.getValues(), context);
            // If a back up store is used, reset it
            ((ReduceContext.ValueIterator)
                    (context.getValues().iterator())).resetBackupStore();
        }
        cleanup(new WrappedReducer<KEYIN,VALUEIN,KEYOUT,VALUEOUT>().getReducerContext(context));
    }

    protected void cleanup(MRReduceContext<KEYIN,VALUEIN,KEYOUT,VALUEOUT,REMAPOUT> context) throws IOException, InterruptedException {
        // NOTHING
    }

}
