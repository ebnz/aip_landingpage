/*
 * Copyright 2012
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapreduce;

import java.io.IOException;
import java.util.List;

public abstract class MRMapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT, REMAPIN> extends Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT> {

    private Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT>.Context context;

    public Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT>.Context getContext() {
        return context;
    }

    public void setContext(Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT>.Context context) {
        this.context = context;
    }

    public abstract void remap(List<REMAPIN> vallist, org.apache.hadoop.mapreduce.Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT>.Context context) throws IOException, InterruptedException;

//    public void runremap(List<REMAPIN> vallist) throws IOException, InterruptedException {
//        remap(vallist, getContext());
//    }
}
