/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapreduce;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.mapreduce.split.JobSplitWriter;
import org.apache.hadoop.util.ReflectionUtils;
import streaming.MRStreamer;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MRSJobSubmitter {

	// job files are world-wide readable and owner writable
	final private static FsPermission JOB_FILE_PERMISSION = FsPermission
			.createImmutable((short) 0644); // rw-r--r--

	// job submission directory is world readable/writable/executable
	final static FsPermission JOB_DIR_PERMISSION = FsPermission
			.createImmutable((short) 0777); // rwx-rwx-rwx

	public JobStatus submitJobInternal(Job job) throws IOException, InterruptedException, ClassNotFoundException {
		String jobID = "MRJob";
		Path submitJobDir = new Path(new Configuration().getLocalPath(
				"mapreduce.jobtracker.system.dir", "/tmp/mapred/"), jobID);
		//		job.setNumMapTasks(writeOldSplits((JobConf) job.getConfiguration(), submitSplitFile));
		writeNewSplits(job, submitJobDir);
		job.getConfiguration().set("mapreduce.job.dir", submitJobDir.toString());
//		job.getConfiguration().set("mapred.job.split.file",
//				submitSplitFile.toString());

		MRStreamer streamer = new MRStreamer(job);
		JobStatus status = streamer.run();

		System.out.println("\nall finished!");
		
		return status; 
	}

	private static final int CURRENT_SPLIT_FILE_VERSION = 0;
	private static final byte[] SPLIT_FILE_HEADER = "SPL".getBytes();

	@SuppressWarnings("unchecked")
	  private <T extends InputSplit>
	  int writeNewSplits(JobContext job, Path jobSubmitDir) throws IOException,
	      InterruptedException, ClassNotFoundException {
	    Configuration conf = job.getConfiguration();
	    InputFormat<?, ?> input =
	      ReflectionUtils.newInstance(job.getInputFormatClass(), conf);

	    List<InputSplit> splits = input.getSplits(job);
	    T[] array = (T[]) splits.toArray(new InputSplit[splits.size()]);

	    // sort the splits into order based on size, so that the biggest
	    // go first
	    Arrays.sort(array, new SplitComparator());
	    JobSplitWriter.createSplitFiles(jobSubmitDir, conf, 
	        jobSubmitDir.getFileSystem(conf), array);
	    return array.length;
	  }
	 
	 private static class SplitComparator implements Comparator<InputSplit> {
		    @Override
		    public int compare(InputSplit o1, InputSplit o2) {
		      try {
		        long len1 = o1.getLength();
		        long len2 = o2.getLength();
		        if (len1 < len2) {
		          return 1;
		        } else if (len1 == len2) {
		          return 0;
		        } else {
		          return -1;
		        }
		      } catch (IOException ie) {
		        throw new RuntimeException("exception in compare", ie);
		      } catch (InterruptedException ie) {
		        throw new RuntimeException("exception in compare", ie);
		      }
		    }
		  }
}
