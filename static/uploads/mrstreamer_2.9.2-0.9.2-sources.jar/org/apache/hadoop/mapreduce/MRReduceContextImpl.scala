/*
 * Copyright 2012
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.mapreduce

import streaming.reduce.TaggedKey
import task.TaskInputOutputContextImpl
import collection.mutable
import org.apache.hadoop.conf.Configuration
import grizzled.slf4j.Logging
import org.apache.hadoop.io.{Writable, IntWritable, WritableUtils}
import algorithms.kmeans.Clusters

class MRReduceContextImpl[KEYIN, VALUEIN, KEYOUT, VALUEOUT, REMAPOUT](conf: Configuration, taskid: TaskAttemptID,
                                                                      output: RecordWriter[KEYOUT, VALUEOUT],
                                                                      committer: OutputCommitter,
                                                                      reporter: StatusReporter,
                                                                      collector: streaming.Collector,
                                                                      var buffer: mutable.Map[KEYIN, mutable.ListBuffer[VALUEIN]])
  extends TaskInputOutputContextImpl[KEYIN, VALUEIN, KEYOUT, VALUEOUT](conf, taskid, output, committer, reporter)
  with MRReduceContext[KEYIN, VALUEIN, KEYOUT, VALUEOUT, REMAPOUT]
  with Logging {

  var currentKey: KEYIN = null.asInstanceOf[KEYIN]
  var currentValue: VALUEIN = null.asInstanceOf[VALUEIN]
  var keysIterator : Iterator[KEYIN] = buffer.keysIterator

  var valuesIterator: Iterator[VALUEIN] = null
  var exportedValuesIterator: Iterator[VALUEIN] = null

  /**
   * Iterate through the values for the current key, reusing the same value
   * object, which is stored in the context.
   * @return the series of values associated with the current key. All of the
   *         objects returned directly and indirectly from this method are reused.
   */
  override def getValues: java.lang.Iterable[VALUEIN] = new java.lang.Iterable[VALUEIN] {
    override def iterator = new ReduceContext.ValueIterator[VALUEIN] {
      override def resetBackupStore() {
        /* TODO: Implement */
      }

      override def clearMark() {
        /* TODO: Implement */
      }

      override def reset() {
        /* TODO: Implement */
      }

      override def mark() {
        /* TODO: Implement */
      }

      override def remove() {
        /* TODO: Implement */
      }

      override def next: VALUEIN = exportedValuesIterator.next()

      override def hasNext: Boolean = exportedValuesIterator.hasNext

    }
  }

  /**Start processing next unique key. */
  override def nextKey: Boolean =
    if (keysIterator.hasNext) {
      currentKey = keysIterator.next()
      valuesIterator = buffer(currentKey).iterator
      exportedValuesIterator = buffer(currentKey).iterator
      currentValue = if (valuesIterator.hasNext) valuesIterator.next() else null.asInstanceOf[VALUEIN]
      null != currentValue
    } else {
      currentKey = null.asInstanceOf[KEYIN]
      valuesIterator = null
      exportedValuesIterator = null
      currentValue = null.asInstanceOf[VALUEIN]
      false
    }

  /**
   * Get the current value.
   */
  override def getCurrentValue: VALUEIN = currentValue

  /**
   * Get the current key.
   */
  override def getCurrentKey: KEYIN = currentKey.asInstanceOf[TaggedKey].getKey.asInstanceOf[KEYIN]

  /**
   * Advance to the next key/value pair.
   */
  override def nextKeyValue: Boolean = {
    if (valuesIterator.hasNext) {
      currentValue = valuesIterator.next()
      true
    } else {
      do {
        nextKey
      } while (null != valuesIterator && null == currentValue)
      null != currentValue
    }
  }

  def restream(outvalue: REMAPOUT) {

    info("restream data")

//    debug(" BEFORE clone : clusters length : >>>>>> " + outvalue.asInstanceOf[Clusters].length)


    val outvCloned = WritableUtils.clone(outvalue.asInstanceOf[Writable], conf)

//    debug(" AFTER clone : clusters length : >>>>>> " + outvCloned.asInstanceOf[Clusters].length)


    collector.reStream(new IntWritable(1), outvCloned)

  }

  override def write(key: KEYOUT, value: VALUEOUT) {

    val kCloned : KEYOUT = WritableUtils.clone(key.asInstanceOf[Writable], conf).asInstanceOf[KEYOUT]
    val vCloned : VALUEOUT = WritableUtils.clone(value.asInstanceOf[Writable], conf).asInstanceOf[VALUEOUT]

    super.write(kCloned, vCloned)
  }
}
