/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.mapred.OutputCollector

/**
 * Trait to define user-implemented collector algorithms for mapper and reducer.
 * There is one map collector per map worker and only one reduce collector at all.
 *
 * User: flangner
 * Date: 02.08.2010
 * Time: 13:46:03
 */

trait Collector extends OutputCollector[Any, Any] {

  /**
   * Method to initialize the algorithm.
   * Has not to be executed within user-implemented algorithms.
   *
   * @param env - Environment (legacy)
   */
  def init(conf: Configuration)

  /**
   * Method to manually re-stream some intermediate results. Has not to be implemented by the user,
   * but by the framework.
   * Use instead of the collect method.
   *
   * @param key
   * @param value
   */
  def reStream(key: Any, value: Any) {
    throw new UnsupportedOperationException
  }

  /**
   * Called when the progress threshold has been exceeded.
   * Use this to add stats to the result store.
   * Has not to be executed within user-implemented algorithms.
   *
   * @param outcomeInBytes - the number of bytes produced by this collector since the last call of this method.
   */
  def thresholdExceeded(outcomeInBytes: Long)

  /**
   * Operation to execute, when the algorithm has passed through the framework.
   * This method is executed by the framework and therefore should not be executed
   * within the user-implementation of other methods, except if the execution has to be
   * aborted because of a user-defined error.
   *
   * @param success - determines whether the application's run was successful or not.
   */
  def finished(success: Boolean)
}