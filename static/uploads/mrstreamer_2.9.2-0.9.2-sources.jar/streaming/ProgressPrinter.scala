/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

/**
 * This Object has to be updated with progress information and prints them to screen on each update.
 *
 * User: flangner
 * Date: 04.08.2010
 * Time: 17:54:03
 */

object ProgressPrinter {

  private var mapperThroughput: Double = 0.0
  private var reducerThroughput: Double = 0.0

  def updateMapperThroughput (t: Double) {
    this.mapperThroughput = t
    printStats()
  }

  def updateReducerThroughput (t: Double) {
    this.reducerThroughput = t
    printStats()
  }

  private def printStats() {
    print("MapCollector: " + (mapperThroughput / 1024.0) + " kBytes/second | " +
          "ReduceCollector: " + (reducerThroughput / 1024.0) + " kBytes/second                                 \r")
  }
}