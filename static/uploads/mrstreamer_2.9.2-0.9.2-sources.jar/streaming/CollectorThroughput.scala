/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

import java.util.{Timer, TimerTask}
import akka.actor.ActorRef
//import akka.serialization.Serializable.SBinary
//import sbinary._
//import sbinary.Operations._
//import sbinary.DefaultProtocol._ // necessary for serialization issues

/**
 * Objects of this class are used to calculate the throughput of a specific Collector.
 * Throughput will be send to an observing actor or printed to the system-out.
 *
 * User: flangner
 * Date: 03.08.2010
 * Time: 21:13:24
 */

class CollectorThroughput(identifier: String, period: Long, observer: ActorRef) extends TimerTask {

  def this(id: String, period: Long) = this(id, period, null)

  @volatile
  private var bytesCollected: Long = 0L

  // setup the timer task
  private val timer: Timer = new Timer(identifier + "Timer", true)
  this.timer.schedule(this, period, period)

  /**
   * This method is used to increment the currently measured number of collected bytes by numOfBytes.
   *
   * @param numOfBytes
   */
  def incrementCollectedBytes(numOfBytes: Long) {
    this.bytesCollected += numOfBytes
  }

  /**
   * Method to be executed at the end of each period.
   */
  override def run() {
    if (observer != null) {
      if (observer.isRunning) observer ! Throughput(identifier, throughput)
      if (observer.isShutdown) timer.cancel()
    } else {
      ProgressPrinter.updateReducerThroughput(throughput)
    }
    reset()
  }

  /**
   * To ensure that no statistical data gets lost we write down out the progress before canceling the throughput
   * measurement.
   */
  override def cancel: Boolean = {
    //run
    super.cancel
  }

  /**
   *  Calculates the throughput of this period.
   */
  private def throughput: Double = (this.bytesCollected.toDouble / (period.toDouble / 1000.0))

  /**
   * Used to reset the relative amount of bytes collected so far.
   */
  private def reset() {
    this.bytesCollected = 0L
  }
}

/**
 * Class for throughput messages to be collected by an observer.
 */
case class Throughput(identifier: String, throughput: Double)
//    def this() = this ("unknown", -1.0)
//
//  implicit object ThroughputFormat extends Format[Throughput] {
//    def reads(in: Input): Throughput = Throughput (read[String] (in), read[Double] (in))
//
//    def writes(out: Output, value: Throughput) {
//      write[String] (out, value.identifier)
//      write[Double] (out, value.throughput)
//    }
//  }
//
//  def fromBytes (bytes: Array[Byte]): Throughput = fromByteArray[Throughput] (bytes)
//  def toBytes: Array[Byte] = toByteArray[Throughput] (this)
//}
