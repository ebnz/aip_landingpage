/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import _root_.util.MapBuffer
import org.apache.hadoop.mapreduce.task.TaskInputOutputContextImpl
import streaming._
import map.HasFinished
import org.apache.hadoop.mapreduce.lib.reduce.WrappedReducer
import org.apache.hadoop.util.ReflectionUtils
import akka.actor.{ActorRef, Actor}
import org.apache.hadoop.{mapreduce, mapred}
import collection.mutable
import compat.Platform.currentTime
import grizzled.slf4j.Logging
import mapreduce._
import collection.mutable.ListBuffer
import collection.mutable.HashMap

class HadoopReduceWorker extends Actor with Logging {

  private var identifier: Int = -1

  private var collector: ReduceCollectorClient = null

  private var profileName: String = "unknown"

  private var startP: Long = -1

  private var startTime: Long = 0

  private var conf: mapred.JobConf = null

  private var tokenCounter: Int = 0

  private var tokenValue: Boolean = true


  private var runningMapWorker: Int = -1

  private var buffer: mutable.Map[Any, mutable.ListBuffer[Any]] = new mutable.HashMap
  //  private var reducer: Option[Reducer[Any,Any,Any,Any]] = None
  //  private var reduceContext: Option[ReduceContext[Any,Any,Any,Any]] = None

  private var mrbuffer: MapBuffer = null
  private var mrreducer: Option[MRReducer[Any, Any, Any, Any, Any]] = None
  //private var mrreduceContext: Option[MRReduceContext[Any, Any, Any, Any, Any]] = None


  var jobID : JobID = null
  var taskAttemptID : TaskAttemptID = null
  var writer: mapreduce.RecordWriter[Any, Any] = null
  var committer: mapreduce.OutputCommitter = null
  var reporter: mapreduce.StatusReporter = null
  var markedCollector: Collector = null

  /**
   * method to get messages from the actor's mailbox (as long as it is running)
   */
  def receive = {

    case ReducerInit(id: Int, conf: mapred.JobConf, startTime: Long, reduceCollector: ActorRef) => {

      this.identifier = id

      //this.env = env

      if (conf.getBoolean("mrstreamer.distributed", false)) {
        Actor.remote.register("R" + id, self)
      }

      this.conf = conf

      this.runningMapWorker = conf.getNumMapTasks

      this.startTime = startTime

      this.profileName = "r" + identifier

      this.collector = new ReduceCollectorClient(reduceCollector, conf)

      this.mrbuffer = new MapBuffer(conf.getInt("mrstreamer.reduceCollectorBufferSize", -1), handleBufferOutput)

      become(initialized)
      info(getClass.getSimpleName + "-" + identifier + " initialized!")
      self.reply("done")
    }

  }

  def initialized: Receive = {

    case ReduceInput(conf: mapred.JobConf, key: Any, values: mutable.ListBuffer[Any]) => {

      if (startP == -1) startP = currentTime - startTime

      API.getAPI(conf) match {
        case HadoopMapReduceStreamingAPI => {
          this.mrbuffer.add(key, values)
        }
        case HadoopMapReduceAPI => {
          if (buffer.contains(key)) {

            buffer(key) ++= values
          } else {

            buffer += key -> values
          }
        }
        case _ => {
          throw new IllegalStateException("illegal API")
        }
      }


    }

    // request of a mapper whether this reducer has any unprocessed data or not
    // buffer will be flushed after answering the request
    case HasFinished(value: Boolean) => {

      // collect the token values of all mappers

      tokenValue &= (buffer.isEmpty && value)
      tokenCounter += 1
      val result = (tokenCounter == conf.getNumMapTasks)

      //if (!buffer.isEmpty) this.buffer.flush
      // TODO for kMeans it is necessary to wait for all map-results to be buffered, before the buffer is flushed if
      // TODO there are any other use-cases flushing by the finishing-mechanism has to be optionally

      // send the result to the master and reset the state
      if (result) {
        collector.redirectHasFinishedToken(tokenValue)
        tokenValue = true
        tokenCounter = 0
      }

    }

    case "finish" => {


      API.getAPI(conf) match {
        case HadoopMapReduceStreamingAPI => {
          runningMapWorker -= 1
          if (runningMapWorker == 0) {
            this.mrbuffer.flush()
            this.collector.finished(true, profileName, startP)

            info(getClass.getSimpleName + "-" + identifier + " finished!")
          }
        }
        case HadoopMapReduceAPI => {

          val markedCollector: Collector = new RestoreTagCollector(0, collector, conf,
            MRJobConfig.OUTPUT_KEY_CLASS, MRJobConfig.OUTPUT_VALUE_CLASS)

          val jobID = JobID.forName(conf.get(MRJobConfig.ID))
          val taskAttemptID = new TaskAttemptID(jobID.getJtIdentifier, jobID.getId, TaskType.REDUCE, identifier, 0)

          val writer: mapreduce.RecordWriter[Any, Any] = new MRSRecordWriter[Any, Any](markedCollector)
          val committer: mapreduce.OutputCommitter = null // TODO Investigate, probably low-prio
          val reporter: mapreduce.StatusReporter = new hadoopInterface.MRSReporter

          val reducer = conf.getClass(MRJobConfig.REDUCE_CLASS_ATTR, classOf[mapreduce.Reducer[Any, Any, Any, Any]]).newInstance.asInstanceOf[mapreduce.Reducer[Any, Any, Any, Any]]
          val reduceContext = new MRReduceContextImpl[Any, Any, Any, Any, Any](conf, taskAttemptID, writer, committer, reporter, markedCollector, buffer)
          val reducerContext: org.apache.hadoop.mapreduce.Reducer[Any, Any, Any, Any]#Context = new WrappedReducer[Any, Any, Any, Any].getReducerContext(reduceContext).asInstanceOf[org.apache.hadoop.mapreduce.Reducer[Any, Any, Any, Any]#Context]
          reducer.run(reducerContext)

          this.collector.finished(true, profileName, startP)
          info(getClass.getSimpleName + "-" + identifier + " finish called!")
        }


        case _ => {
          throw new IllegalStateException("illegal API")
        }
      }

    }

    case "shutdown" => {

      //        if (!buffer.isEmpty) {
      //          throw new RuntimeException("Reducer-" + identifier + " was killed before its buffer was flushed!")
      //        }

      collector.stop()
      self.stop()

      // exit TODO Whoa

    }

    case ev => error(getClass.toString + "-" + identifier + ": received unknown command: " + ev)
  }

  override def preStart {
    info(getClass.toString + " on " + java.net.InetAddress.getLocalHost.getHostName + ": preStart")
  }

  private def handleBufferOutput(key: Any, values: ListBuffer[Any]) {


    val bufferMap: mutable.Map[Any, ListBuffer[Any]] = new HashMap[Any, ListBuffer[Any]]
    bufferMap(key) = values

    if (mrreducer.isEmpty ) {
      mrreducer = Some(conf.getClass(MRJobConfig.REDUCE_CLASS_ATTR, classOf[mapreduce.MRReducer[Any, Any, Any, Any, Any]]).newInstance.asInstanceOf[mapreduce.MRReducer[Any, Any, Any, Any, Any]])

      jobID = JobID.forName(conf.get(MRJobConfig.ID))
      taskAttemptID = new TaskAttemptID(jobID.getJtIdentifier, jobID.getId, TaskType.REDUCE, identifier, 0)
      committer = null // TODO Investigate, probably low-prio
      reporter = new hadoopInterface.MRSReporter
    }

//    debug("HADOOP TAGGED KEY: " + key)

    markedCollector = new RestoreTagCollector(key.asInstanceOf[TaggedKey].getTag, collector, conf,
      MRJobConfig.OUTPUT_KEY_CLASS, MRJobConfig.OUTPUT_VALUE_CLASS)
    writer = new MRSRecordWriter[Any, Any](markedCollector)

    val mrreduceContext : MRReduceContext[Any, Any, Any, Any, Any] = new MRReduceContextImpl[Any, Any, Any, Any, Any](conf, taskAttemptID, writer, committer, reporter, markedCollector, bufferMap)

    mrreducer.get.run(mrreduceContext)

//    info(getClass.getSimpleName + "-" + identifier + " : handleBufferOutput ends!")

  }


}