/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.conf.Configuration
import streaming.Collector
import org.apache.hadoop.{ mapred, mapreduce }
import hadoopInterface.{ DummyReporter, HadoopConfGlue }
import org.apache.hadoop.util.ReflectionUtils
import grizzled.slf4j.Logging

/**
 * This is the streaming interpretation of the Hadoop collector of the final
 * output. It's based on the OutputFormat defined within the JobConf.
 *
 * User: flangner
 * Date: 14.08.2010
 * Time: 20:08:28
 */

class HadoopRedCollector(conf: mapred.JobConf) extends Collector with Logging {

  conf.set("mapred.task.id", "attempt_200707121733_0000_r_000000_0") // task attempt ID dummy

  private val out: mapred.RecordWriter[Any, Any] = conf.getOutputFormat.getRecordWriter(HadoopConfGlue.fs, conf,
    conf.get("mrstreamer.resultFile"), new DummyReporter).asInstanceOf[mapred.RecordWriter[Any, Any]]

  override def init(conf: Configuration) { /* nothing to do */ }

  def collect(key: Any, value: Any) {
    this.out.write(key, value)
  }

  def finished(success: Boolean) {
    this.out.close(new DummyReporter)
  }

  def thresholdExceeded(progress: Long) { /* I don't care */ }
}

class HadoopReduceCollector(conf: mapred.JobConf) extends Collector with Logging {

  val jobID = mapreduce.JobID.forName(conf.get(mapreduce.MRJobConfig.ID))
  val taskAttemptID = new mapreduce.TaskAttemptID(jobID.getJtIdentifier, jobID.getId, mapreduce.TaskType.REDUCE, 0, 0)

  val taskContext = new mapreduce.task.TaskAttemptContextImpl(conf, taskAttemptID);
  val outputFormat = ReflectionUtils.newInstance(taskContext.getOutputFormatClass, conf);

  private val out: mapreduce.RecordWriter[Any, Any] = outputFormat.getRecordWriter(taskContext).asInstanceOf[mapreduce.RecordWriter[Any, Any]];

  override def init(conf: Configuration) { /* nothing to do */ }

  def collect(key: Any, value: Any) {
    this.out.write(key, value)
  }

  def finished(success: Boolean) {
    this.out.close(taskContext)
  }

  def thresholdExceeded(progress: Long) { /* I don't care */ }
}