/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.mapreduce.MRJobConfig
import algorithms.MRClass
import akka.actor.{ActorRef, Actor, Uuid}

//import sbinary._
//import sbinary.Operations._
//import sbinary.DefaultProtocol._
import org.apache.hadoop.mapred
import hadoopInterface.{DummyReporter, HadoopSerializationGlue}
import util.MapBuffer
import collection.mutable.ListBuffer
import org.apache.hadoop.io.Writable
import compat.Platform.currentTime
import akka.serialization.RemoteActorSerialization
import streaming.map.HasFinished
import streaming.Collector
import de.uni_heidelberg.ifi.pvs.mrstreamer.Worker
import grizzled.slf4j.Logging
import akka.serialization.Serializable.{ScalaJSON}
import streaming.map.MapperInit._
import sjson.json.JsonSerialization._
import akka.serialization.RemoteActorSerializationHelper._
import dispatch.json.{Js, JsValue}
import dispatch.json.JsNumber._

/**
 * A ReduceWorkerBucket runs in its own thread and controls a set of reducers.
 * At the moment a reducer is created and maintained for every key assigned to the
 * ReduceWorkerBucket.
 *
 * User: flangner
 * Date: 20.05.2010
 * Time: 10:34:18
 */
class ReduceWorker extends Actor with Logging {

  private var identifier: Int = -1

  // a reducer map for this worker-thread (key -> ReduceAlgorithm-Instance)
  private var reducerMap: Map[Any, Any] = Map.empty

  private var collector: ReduceCollectorClient = null

  private var profileName: String = "unknown"

  private var startP: Long = -1

  private var startTime: Long = 0

  private var conf: mapred.JobConf = null
  
  private var useHadoopAPI: Boolean = false
  //private lazy val api = API.getAPI(conf)


  private var buffer: MapBuffer = null

  private var tokenCounter: Int = 0

  private var tokenValue: Boolean = true

  private var numMappers: Int = -1

  private var runningMapWorker: Int = -1

  /**
   * method to get messages from the actor's mailbox (as long as it is running)
   */
  def receive = {
	  

    case ReducerInit(id: Int, conf: mapred.JobConf, startTime: Long, reduceCollector: ActorRef) => {
    	
      debug("Received ReducerInit")

      this.identifier = id

      //this.env = env

      if (conf.getBoolean("mrstreamer.distributed", false)) {
        Actor.remote.register("R" + id, self)  
      }

      this.numMappers = conf.getNumMapTasks

      this.runningMapWorker = numMappers

      this.useHadoopAPI = conf.get("mrstreamer.reduceAlgorithm") == null

      this.conf = conf
      conf.setClassLoader(this.getClass.getClassLoader) // TODO Probably needs to changed when used as library
      if (Worker.workerActor.isDefined) {
        val r = Worker.workerActor map (_ !! "getClassLoader")
        val cl = r.get.asInstanceOf[Option[ClassLoader]]
        conf.setClassLoader(cl.get)
      }


      this.startTime = startTime

      this.profileName = "r" + identifier

      this.collector = new ReduceCollectorClient(reduceCollector, conf)

      this.buffer = new MapBuffer(conf.getInt("mrstreamer.reduceCollectorBufferSize", -1), handleBufferOutput)

      become(initialized)
      debug("ReduceWorker-" + identifier + " initialized!")
      self.reply("done")
    }
    
  }
  
  def initialized : Receive = {

    case ReduceInput(conf: mapred.JobConf, key: Any, values: ListBuffer[Any]) => {


        if(startP == -1) startP = currentTime - startTime

        this.buffer.add(key, values)
      
    }

    // request of a mapper whether this reducer has any unprocessed data or not
    // buffer will be flushed after answering the request
    case HasFinished(value: Boolean) => {


        // collect the token values of all mappers
        var result: Boolean = false
        synchronized {
          tokenValue &= (buffer.isEmpty && value)
          tokenCounter += 1
          result = (tokenCounter == numMappers)
        }

        //if (!buffer.isEmpty) this.buffer.flush
        // TODO for kMeans it is necessary to wait for all map-results to be buffered, before the buffer is flushed if
        // TODO there are any other use-cases flushing by the finishing-mechanism has to be optionally

        // send the result to the master and reset the state
        if (result) {
          collector.redirectHasFinishedToken(tokenValue)
          tokenValue = true
          tokenCounter = 0
        }
      
    }

    case "finish" => {
        runningMapWorker -= 1

        debug("Received finish, " + runningMapWorker + " map workers still running")

        val result = (runningMapWorker == 0)
        if (result) {

          debug("All map-jobs have been completed.")

          // flushing the buffer before ...
          this.buffer.flush()

          // close the reducers if we are using Hadoop
          if (useHadoopAPI) {
            for (entry <- reducerMap) {
              entry._2.asInstanceOf[mapred.Reducer[Any, Any, Any, Any]].close()
            }
          }

          // ... and after closing the reducer
          this.buffer.flush()

          // call finish on the reduce Collector
          this.collector.finished(true, profileName, startP)

          // all reduce jobs are finished, no more data is expected
          debug("ReduceWorker-"+identifier+" finished!")
        }
      
    }

    case "shutdown" => {

        if (!buffer.isEmpty) {
          throw new RuntimeException("Reducer-" + identifier + " was killed before its buffer was flushed!")
        }

        collector.stop()
        self.stop()

        // exit TODO Whoa
      
    }

    case ev => error("ReduceWorker-%d: received unknown command: %s", identifier, ev)
  }

  override def preStart {
	  debug("ReduceWorker on "+java.net.InetAddress.getLocalHost.getHostName+": postStart")
  }
  /**
   * Executes the reduce-method and collects the results.
   */
  private def handleBufferOutput(taggedKey: Any, values: ListBuffer[Any]) {

  // retrieve the iteration-id from the markedKey and set up a collector that will wrap this information after
  // combining the results
  val markedCollector: Collector = new RestoreTagCollector(taggedKey.asInstanceOf[TaggedKey].getTag, collector, conf,
                                                           MRJobConfig.OUTPUT_KEY_CLASS, MRJobConfig.OUTPUT_VALUE_CLASS)
  val key: Any = taggedKey.asInstanceOf[TaggedKey].getKey

//    debug("MRS TAGGED KEY: " + taggedKey)

    // lookup reducer object to execute reduce function
    val result = reducerMap.get(key)
    var reducer: Any = null
    result match {

      // reducer does not exist
      case None => {

        // load reducer implementation
        if (useHadoopAPI) {
          val red: mapred.Reducer[Any, Any, Any, Any] = conf.getReducerClass.newInstance.asInstanceOf[mapred.Reducer[Any, Any, Any, Any]]
          reducerMap += key -> red
          reducer = red
        } else {
          val red: MRClass = Class.forName(conf.get("mrstreamer.reduceAlgorithm")).newInstance.asInstanceOf[MRClass]
          red.init(conf)
          reducerMap += key -> red
          reducer = red
        }
      }

      // there is a already a reducer available
      case Some(red) => {

        reducer = red
      }
    }

    // execute the reduce-step
    if (useHadoopAPI) {

      val iter = values.iterator
      val iterator = new java.util.Iterator[Any] {
                            def hasNext: Boolean = iter.hasNext
                            def next(): Any = iter.next()
                            def remove() {throw new UnsupportedOperationException}
                         }
      reducer.asInstanceOf[mapred.Reducer[Any, Any, Any, Any]].configure(conf)
      reducer.asInstanceOf[mapred.Reducer[Any, Any, Any, Any]].reduce(key, iterator, markedCollector, new DummyReporter)
    } else {

      reducer.asInstanceOf[MRClass].reduce(key, values, markedCollector)
    }
  }
}

/**
 * message-class for mapper initialization messages
 *
 * @param id - reducers identifier
 * @param env - Environment (legacy)
 * @param jobConf - JobConf Hadoop
 * @param startTime
 * @param redCollector
 */
case class ReducerInit(id: Int, jobConf: mapred.JobConf, startTime: Long, reduceCollector: ActorRef)
  extends ScalaJSON[ReducerInit] {
//        extends SBinary[ReducerInit] {
//
  def this() = this (-1, new mapred.JobConf, -1L, null.asInstanceOf[ActorRef])
//
//  implicit object ReducerInitFormat extends Format[ReducerInit] with Logging {
//
//    def reads(in: Input): ReducerInit = {
//      val idIn: Int = read[Int](in)
//      HadoopSerializationGlue.readInputAsByteArray(jobConf.asInstanceOf[Writable], in)
//      jobConf.setClassLoader(classOf[mapred.JobConf].getClassLoader)
//      val startTimeIn: Long = read[Long](in)
//      val collector: ActorRef =
//      if (jobConf.getBoolean("mrstreamer.distributed", false)) {
//        RemoteActorSerialization.fromBinaryToRemoteActorRef(read[Array[Byte]](in))
//      } else {
//        Actor.registry.actorFor(new Uuid(read[String](in))).get
//      }
//      ReducerInit(idIn, jobConf, startTimeIn, collector)
//    }
//
//
//    def writes(out: Output, value: ReducerInit) {
//      write[Int](out, value.id)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.jobConf, out)
//      write[Long](out, value.startTime)
//      if (!jobConf.getBoolean("mrstreamer.distributed", false)) {
//    	  write[String](out, value.reduceCollector.getUuid().toString)
//      } else {
//        write[Array[Byte]](out,RemoteActorSerialization.toRemoteActorRefProtocol(value.reduceCollector).toByteArray)
//      }
//    }
//  }
//
//  def fromBytes (bytes: Array[Byte]): ReducerInit = fromByteArray[ReducerInit] (bytes)
//  def toBytes: Array[Byte] = toByteArray[ReducerInit] (this)
  implicit object ReducerInitFormat extends sjson.json.Format[ReducerInit] with Logging {
    import dispatch.json._
    import HadoopSerializationGlue._
    import sjson.json.DefaultProtocol._

    val ID = JsString("id")
    val CONFIGURATION = JsString("configuration")
    val STARTTIME = JsString("startTime")
    val REDUCECOLLECTOR = JsString("mapCollector")

    def reads(json: JsValue): ReducerInit = json match {
      case JsObject(m) => {
        ReducerInit(
        fromjson[Int](m(ID)),
        stringToWritable[mapred.JobConf](fromjson[String](m(CONFIGURATION))),
        fromjson[Long](m(STARTTIME)),
        fromBase64StringToRemoteActorRef(fromjson[String](m(REDUCECOLLECTOR)))
      )
      }
      case _ => throw new RuntimeException("JsString expected")
    }
    def writes(mi: ReducerInit) : JsValue =  {
      val out = JsObject(
      Map(
        ID -> JsNumber(id),
        CONFIGURATION -> writableToJsString(mi.jobConf),
        STARTTIME -> JsNumber(mi.startTime),
        REDUCECOLLECTOR -> JsString(fromRemoteActorRefToBase64String(reduceCollector)))
    )
      debug("ReducerInit = " + out)
      out
    }

  }
  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[ReducerInit](bytes)
  def fromJSON(js: String) = fromjson[ReducerInit](Js(js))

}

/**
 * message-class for the reducer input
 *
 * @param env - Environment (legacy)
 * @param key - a marked key.
 * @param value
 */
case class ReduceInput(conf: mapred.JobConf, key: Any, values: ListBuffer[Any]) extends ScalaJSON[ReduceInput] { //SBinary[ReduceInput] with Logging {

  def this() = this (new mapred.JobConf, null.asInstanceOf[Any], ListBuffer.empty)

//  implicit object ReduceInputFormat extends Format[ReduceInput] {
//    def reads(in: Input): ReduceInput = {
//      HadoopSerializationGlue.readInputAsByteArray(conf.asInstanceOf[Writable], in)
//      conf.setClassLoader(classOf[mapred.JobConf].getClassLoader)
//      val keyIn: Writable = new TaggedKey(Class.forName(conf.get(MRJobConfig.MAP_OUTPUT_KEY_CLASS)).newInstance.asInstanceOf[Writable])
//      HadoopSerializationGlue.readInputAsByteArray(keyIn, in)
//      val numValues: Int = read[Int](in)
//      var valuesIn: ListBuffer[Any] = ListBuffer.empty
//      for (i <- 0 until numValues) {
//        val value: Writable = Class.forName(conf.get(MRJobConfig.MAP_OUTPUT_VALUE_CLASS)).newInstance.asInstanceOf[Writable]
//        HadoopSerializationGlue.readInputAsByteArray(value, in)
//        valuesIn += value
//      }
//      ReduceInput(conf, keyIn, valuesIn)
//    }
//
//    def writes(out: Output, value: ReduceInput) {
//      HadoopSerializationGlue.writeOutputAsByteArray(value.conf, out)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.key.asInstanceOf[Writable], out)
//      write[Int](out, value.values.size)
//      //if (value.values.size > 1000) debug("Key '" + value.key.toString + "' has " + value.values.size + " values")
//      value.values.foreach((va: Any) => {
//        HadoopSerializationGlue.writeOutputAsByteArray(va.asInstanceOf[Writable], out)
//      })
//    }
//  }
//
//  def fromBytes (bytes: Array[Byte]) = fromByteArray[ReduceInput] (bytes)
//  def toBytes: Array[Byte] = toByteArray[ReduceInput] (this)

      implicit object ReduceInputFormat extends sjson.json.Format[ReduceInput] with Logging {
      import dispatch.json._
      import HadoopSerializationGlue._
      import sjson.json.DefaultProtocol._

      val CONFIGURATION = JsString("configuration")
      val KEY = JsString("key")
      val VALUES = JsString("values")

      def reads(json: JsValue): ReduceInput = json match {
        case JsObject(m) => {
          val conf = stringToWritable[mapred.JobConf](fromjson[String](m(CONFIGURATION)))
          conf.setClassLoader(classOf[mapred.JobConf].getClassLoader) // FIXME: Assumption that MAP_OUTPUT_*_CLASS are always in here is wrong.
          val outputKeyClass = conf.getMapOutputKeyClass
          val outputValueClass = conf.getMapOutputValueClass
          logger.debug("Getting map output key class "+ outputKeyClass + " from " + classOf[mapred.JobConf].getClassLoader)
          ReduceInput(
            conf,
            new TaggedKey(stringToWritable(outputKeyClass.newInstance.asInstanceOf[Writable], fromjson[String](m(KEY).asInstanceOf[JsString]))),
            ListBuffer(fromjson[List[String]](m(VALUES)).map(s => stringToWritable(outputValueClass.newInstance.asInstanceOf[Writable], s)))
          )
        }
        case _ => throw new RuntimeException("JsString expected")
      }
      def writes(mi: ReduceInput) : JsValue =  {
      val out = JsObject(
      Map(
        CONFIGURATION -> writableToJsString(mi.conf),
        KEY -> writableToJsString(mi.key.asInstanceOf[Writable]),
        VALUES -> tojson(mi.values.map(v => writableToString(v.asInstanceOf[Writable])).toList)
    ))
      debug("ReduceInput = " + out)
      out
    }

  }
  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[ReduceInput](bytes)
  def fromJSON(js: String) = fromjson[ReduceInput](Js(js))
}
