/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.conf.Configuration
import streaming.Collector

class SimpleReduceCollector extends Collector {

  override def init (conf: Configuration) {}

  def collect (key: Any, value: Any){
    println(key + " : " + value)
  }

  def thresholdExceeded (progress: Long) {
    println("progress in reduced bytes: " + progress)
  }

  def finished (succ: Boolean){
    println("successful: " + succ)
  }
}
