/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.conf.Configuration
import akka.actor.ActorRef
import org.apache.hadoop.io.{WritableUtils, Writable}
import hadoopInterface.HadoopSerializationGlue
import streaming.Collector
import streaming.map.HasFinished
import com.sun.xml.internal.stream.writers.WriterUtility

/***
 * Each reduce-worker uses one ReduceCollectorClient to collect results.
 * The Reduce Collector Client forwards reducer results to the central
 * collector actor at the MR master-server that holds the user's collector
 * implementation.
 *
 * @author flangner
 */
class ReduceCollectorClient (redCollectorServer: ActorRef, conf: Configuration) extends Collector {

  private val distributed: Boolean = conf.getBoolean("mrstreamer.distributed", false)

	/**
   * Forwards the message to the server.
   *
	 * @param key of the reducer k,v result
	 * @param value of the reducer k,v result
	 */
	def collect (key: Any, value: Any) {

    // TODO what if we are not using instances of Writable ...
    var size: Long = 0L
    if (!distributed) {
      size = HadoopSerializationGlue.sizeOf(key.asInstanceOf[Writable]) +
             HadoopSerializationGlue.sizeOf(value.asInstanceOf[Writable])
    } // otherwise data size is measured while sBinary serialization

    redCollectorServer ! ReduceCollectorInput (conf, key, value, size, false)
  }

  /**
   * Forwards the message to the server. Sets the re-Stream flag to tell the master that it should re-stream
   * the intermediate result.
   *
	 * @param key of the reducer k,v result
	 * @param value of the reducer k,v result
   */
  override def reStream (key: Any, value: Any) {
    
    // TODO what if we are not using instances of Writable ...
    var size: Long = 0L
    if (!distributed) {
      size = HadoopSerializationGlue.sizeOf(key.asInstanceOf[Writable]) +
             HadoopSerializationGlue.sizeOf(value.asInstanceOf[Writable])
    } // otherwise data size is measured while sBinary serialization

    redCollectorServer ! ReduceCollectorInput (conf, key, value, size, true)
  }

  /**
   * Forwards the message to the server.
   *
   * @param startTime - time-delta between algorithm initiation and the first reduce on this reducer.
   * @param actorName - Reducer's name for profiling.
   * @param success - whether the reducer was successful or not.
   */
  def finished (success: Boolean, actorName: String, startTime: Long) {
    redCollectorServer ! (("reducer_finished", actorName, startTime))
  }

  /**
   * Sends a HasFinished token back to the reduce collector at the master.
   *
   * @param value
   */
  def redirectHasFinishedToken (value: Boolean) {
    redCollectorServer ! HasFinished(value)
  }

  def stop() {
    //redCollectorServer.stop
  }

/*
 * unsupported operations 
 */

  override def init (conf: Configuration) {
		throw new UnsupportedOperationException
	}

  def finished (success: Boolean) {
    throw new UnsupportedOperationException
  }

  def thresholdExceeded(progress: Long) {
    throw new UnsupportedOperationException
  }
}
