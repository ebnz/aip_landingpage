/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.mapreduce.MRJobConfig
import org.apache.hadoop.conf.Configuration
import streaming.Collector
import org.apache.hadoop.io.Writable
import collection.mutable.ListBuffer
import org.apache.hadoop.mapred.JobConf
import grizzled.slf4j.Logging

/**
 * This reduce collector is used to push the results collected from a complete MR iteration into a new iteration.
 * Keys are therefore modified with a iteration-Id to enable the streamer to count the iterations and collect the
 * results of the last one with the customized collector.
 *
 * With this mechanism we are able to get a better performance for the calculation of the KMeans-algorithm, which
 * becomes more precise on each MR-iteration.
 *
 * Be careful there might be key-value pairs of different map-reduce iterations at the same mapper or reducer at a time.
 * To handle this we wrap a iteration-Id onto every key.
 *
 * User: flangner
 * Date: 15.08.2010
 * Time: 18:49:33
 *
 */

class ReStreamCollector (inOutputBuffer: BlockingMapBuffer, redirection: Collector) extends Collector with Logging {

  private var numIterations: Int = 1

  private var numReducers: Int = 0

  private var tokenCounter: Int = 0

  private var tokenValue: Boolean = true

  override def init (conf: Configuration) {
    this.numIterations = conf.getInt("mrstreamer.numIterations", 1)
    this.numReducers = conf.getInt(MRJobConfig.NUM_REDUCES, 1)
    redirection.init(conf)
  }

  def collect(taggedKey: Any, value: Any) {

    // get and increment the marker
    val iterationId: Int = taggedKey.asInstanceOf[TaggedKey].getTag + 1
    val key: Writable = taggedKey.asInstanceOf[TaggedKey].getKey

//    debug("iteration ID  : " + iterationId)
//    debug("numIterations : " + numIterations)

    //    // re-stream
    if (iterationId < numIterations) {
      inOutputBuffer.add(new TaggedKey(iterationId, key), value)
    }

    // collect results and intermediate-results
    redirection.collect(key, value)
  }

  override def reStream(taggedKey: Any, value: Any) {

//    debug("tagged Key TAG (id) : " + taggedKey.asInstanceOf[TaggedKey].getTag)

    // get and increment the marker
    val iterationId: Int = taggedKey.asInstanceOf[TaggedKey].getTag + 1
    val key: Writable = taggedKey.asInstanceOf[TaggedKey].getKey

//    debug("iteration ID  : " + iterationId )

    inOutputBuffer.add(new TaggedKey(iterationId, key), value)

    redirection.collect(key, value)
  }

  def thresholdExceeded(progress: Long) {
    redirection.thresholdExceeded(progress)
  }

  def finished(success: Boolean) {
    redirection.finished(success)
  }

  /**
   * Collects numReducers tokens before redirecting their overall result to the buffer.
   *
   * @param value
   */
  def receivedHasFinishedToken(value: Boolean) {
    this.tokenValue &= value
    this.tokenCounter += 1

    // send the result to the buffer and reset the state
    if (this.tokenCounter == this.numReducers) {
      inOutputBuffer.onHasFinishedTokenReturned(tokenValue)
      this.tokenValue = true
      this.tokenCounter = 0
    }
  }
}

/**
 * Objects of this class buffer intermediate results between the iterations of complete map-reduce algorithm executions.
 *
 * User: flangner
 * Date: 15.08.2010
 * Time: 18:49:33
 */
class BlockingMapBuffer (hasFinished: (() => Unit)) extends Logging {

  private var buffer: Map[Any, ListBuffer[Any]] = Map.empty

  private var finished: Boolean = false

  private var tokenOnTheWay: Boolean = false

  private var isEmpty: Boolean = true

  /**
   * Add a key value pair to the buffer.
   *
   * @param key
   * @param value
   */
  def add (key: Any, value: Any) {
    add(key, ListBuffer(value))
  }

  /**
   * Add a key values pair to the buffer. Values have already been grouped by their key.
   *
   * @param key
   * @param values
   */
  def add (key: Any, values: ListBuffer[Any]) {
    synchronized {
      this.isEmpty = false

      if (finished) {
        error("An error occurred while buffering intermediate results for the next iterations.\n" +
                  "The buffer has already been finished!")
      }

      // append values to the buffer
      if (buffer.contains(key)) {

        buffer(key) ++= values
      } else {

        buffer += key -> values
      }
      notify()
    }
  }

  /**
   * Method to get the head element of the map.
   *
   * @return a marked key and a list of values identified by it.
   */
  def retrieve: (Any, ListBuffer[Any]) = {
    synchronized {

      // wait until we received something, if the buffer is empty and the algorithm has not been finished yet
      while (buffer.isEmpty && !finished) {

        // check whether the framework should be asked if their is further input data, or not
        if (!tokenOnTheWay) {
          this.isEmpty = true
          this.tokenOnTheWay = true

          hasFinished()
        }

        wait()
      }

      // return anything
      if (finished) {

        return null
      } else {

        // retrieve the key and its values from the buffer
        val result: (Any, ListBuffer[Any]) = buffer.head
        buffer -= result._1

        return result
      }
    }
  }

  /**
   * Method to be executed, when the token has returned to this buffer.
   *
   * @param value - of the token on return.
   */
  def onHasFinishedTokenReturned (value: Boolean) {
    synchronized {

      this.tokenOnTheWay = false
      this.finished = value && isEmpty

      notify()
    }
  }
}

/**
 * This is a pre-collector instance that retrieves the iteration-Id and marks the collected keys.
 *
 * User: flangner
 * Date: 15.08.2010
 * Time: 18:49:33
 */
class RestoreTagCollector (id: Int, redirection: Collector, conf: JobConf, keyRestoreProperty: String,
                           valueRestoreProperty: String) extends Collector {

  override def init(conf: Configuration) {
    redirection.init(conf)
  }

  def collect(key: Any, value: Any) {
    updateEnvDef(key.asInstanceOf[AnyRef], value.asInstanceOf[AnyRef])
    redirection.collect(new TaggedKey(id, key.asInstanceOf[Writable]), value)
  }

  override def reStream(key: Any, value: Any) {
    updateEnvDef(key.asInstanceOf[AnyRef], value.asInstanceOf[AnyRef])
    redirection.reStream(new TaggedKey(id, key.asInstanceOf[Writable]), value)
  }

  def thresholdExceeded(progress: Long) {
    redirection.thresholdExceeded(progress)
  }

  def finished(success: Boolean) {
    redirection.finished(success)
  }

  private def updateEnvDef(key: AnyRef, value: AnyRef) {
      conf.setIfUnset(keyRestoreProperty, key.getClass.getName)
      conf.setIfUnset(valueRestoreProperty, value.getClass.getName)
  }

}

/**
 * Class for keys marked with an iteration-Id.
 *
 * User: flangner
 * Date: 15.08.2010
 * Time: 18:49:33
 */
class TaggedKey(iId: Int, var key: Writable) extends Writable {

  def this(key: Writable) = this(0, key)
  
  def this() = this(null)
  
  private var tag: Int = iId

  def getKey: Writable = key

  def getTag: Int = this.tag

  override def hashCode: Int = {

    var hash: Int = tag.hashCode
    if (key != null) {
      hash += key.hashCode
    }
    hash
  }

  override def equals(obj: Any): Boolean = {
    if (!obj.isInstanceOf[TaggedKey]) return false
    val that: TaggedKey = obj.asInstanceOf[TaggedKey]
    (this.hashCode == that.hashCode) && (this.tag == that.tag) && (this.key == that.getKey)
  }

  override def toString: String = "Tag: " + tag + "| " + key.toString

  def write(out: java.io.DataOutput) {
    out.writeInt(tag)
    val isNull: Boolean = (key == null)
    out.writeBoolean(isNull)
    if (!isNull) {
      out.writeUTF(key.getClass.getName)
      key.write(out)
      }
  }

  def readFields(in: java.io.DataInput) {
    this.tag = in.readInt
    if (!in.readBoolean) {
      val keyClass = in.readUTF
      key = getClass.getClassLoader.loadClass(keyClass).newInstance.asInstanceOf[Writable] // TODO: Possible classloader issues lurk here
      key.readFields(in)
    }
  }
}
