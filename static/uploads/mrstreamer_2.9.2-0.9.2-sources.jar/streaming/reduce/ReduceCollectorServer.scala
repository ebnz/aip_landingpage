/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.reduce

import org.apache.hadoop.conf.Configuration
import java.util.Random
import akka.actor.Actor
import akka.serialization.Serializable.ScalaJSON
import sjson.json.JsonSerialization._
import dispatch.json.JsNumber._
import collection.mutable.ListBuffer
import dispatch.json.{Js, JsValue}

//import akka.serialization.Serializable.SBinary
//import sbinary._
//import sbinary.Operations._
//import sbinary.DefaultProtocol._
import org.apache.hadoop.mapred.JobConf
import util.{ProfileRecord, Profiler}
import hadoopInterface.HadoopSerializationGlue
import org.apache.hadoop.io.Writable
import compat.Platform.currentTime
import org.apache.hadoop.mapreduce.MRJobConfig
import streaming._
import map.HasFinished
import grizzled.slf4j.Logging

/**
 * The ReduceCollectorServer receives results from the ReduceCollectorClient and
 * executes the collect method of the user implementation of the collector.
 *
 * User: flangner
 * Date: 14.06.2010
 * Time: 16:24:53
 */
class ReduceCollectorServer(conf: JobConf, reStreamBuffer: BlockingMapBuffer) extends Actor with Logging {

  /** number of reduce actors. a reduce worker controls a set of reducers that do not run in an own thread */
  private val numReduceWorker: Int = conf.getNumReduceTasks


  // load the collector implementation
  private val redirection: Collector =
    API.getAPI(conf) match {
    case HadoopMapReduceAPI | HadoopMapReduceStreamingAPI => new HadoopReduceCollector(conf)
    case HadoopMapRedAPI => new HadoopRedCollector(conf)
    case MRStreamingAPI =>     try {
      Class.forName(conf.get("mrstreamer.collectorAlgorithm")).newInstance.asInstanceOf[Collector]
    } catch {
      case e: Exception => {
        new SimpleReduceCollector
      }
    }
  }

  private val collector: ReStreamCollector = new ReStreamCollector(reStreamBuffer, redirection)
  this.collector.init(conf)

  private var runningReduceWorker: Int = numReduceWorker

  // used to keep track of the progress
  private val reducerProgress: Array[Long] = new Array[Long] (numReduceWorker)
  for (i <- 0 until numReduceWorker) reducerProgress(i) = 0L

  private val throughput: CollectorThroughput = new CollectorThroughput("ReduceCollector",
                                                                        conf.getLong("mrstreamer.throughputMeasurementPeriod", 1000))

  private var statThreshold: Long = conf.getLong("mrstreamer.statThresholdStep", 1048576)

  private var startP: Long = -1L

  override def preStart {
    info("starting")
  }

  override def postStop {
    info("stopped")
  }

  /**
   * method to get messages from the actor's mailbox (as long as it is running)
   */
  def receive = {

    // perform a collect
    case ReduceCollectorInput(conf: Configuration, key: Any, value: Any, progress: Long, reStream: Boolean) => {

      if(startP == -1) startP = currentTime - Profiler.start

      this.throughput.incrementCollectedBytes(progress)

      // update reducer's local progress information
      val random: Random = new Random(key.hashCode)
      reducerProgress(random.nextInt(numReduceWorker)) += progress

      if (reStream) {
        this.collector.reStream(key, value)
      } else {
        this.collector.collect(key, value)
      }

      // Is the min value over all reducers increased? I.e. are we sure that
      // all reducers have finished processing the line
      // min func. from: http://garyboone.com/2009/08/min-and-sum-one-liners/
      val atLeastProduced: Long = reducerProgress.reduceLeft { _ min _ }
      if(atLeastProduced > statThreshold) {
        statThreshold = (atLeastProduced + conf.getLong("mrstreamer.statThresholdStep", 1048576))
        this.collector.thresholdExceeded(atLeastProduced)
      }
    }

    // redirects a HasFinished token to the reStream-collector (reStream-buffer)
    case HasFinished(value: Boolean) => {
      this.collector.receivedHasFinishedToken(value)
    }

    // finish the execution
    case ("reducer_finished", reducerName: String, reducerStart: Long) => {

      // profiling for this reduceWorker
      Profiler.recordProfile(ProfileRecord(reducerName, reducerStart, currentTime - Profiler.start))

      runningReduceWorker -= 1
      val result = (runningReduceWorker == 0)

      if (result) {

        info("All ReduceWorkers have finished.")

        // profiling for this collector
        Profiler.recordProfile(ProfileRecord("ReduceCollector", startP, currentTime - Profiler.start))
        
        this.collector.finished(true)
        this.throughput.cancel
        info("Reduce Collector finished!")

        // exit main simulator thread
        info("simulator exits")

        // dump the profiling data
        Profiler.dumpProfileRecords
        Profiler.finish

        self.stop
      }
    }

    case x => error("Unknown message received: "+ x)
  }
}

/**
 * message-class for the collector input
 *
 * @param env - Environment (legacy)
 * @param key
 * @param value
 */
case class ReduceCollectorInput(conf: Configuration, key: Any, value: Any, dataLength: Long, reStream: Boolean)
  extends ScalaJSON[ReduceCollectorInput] {
//        extends SBinary[ReduceCollectorInput] {

  def this() = this (new Configuration, null, null, -1L, false)

//  implicit object CollectInputFormat extends Format[ReduceCollectorInput] {
//    def reads(in: Input): ReduceCollectorInput = {
//      HadoopSerializationGlue.readInputAsByteArray(conf.asInstanceOf[Writable], in)
//      conf.setClassLoader(classOf[JobConf].getClassLoader)
//      val key: Writable = new TaggedKey(Class.forName(conf.get(MRJobConfig.OUTPUT_KEY_CLASS)).newInstance.asInstanceOf[Writable])
//      var size: Long = HadoopSerializationGlue.readInputAsByteArray(key, in)
//      val value: Writable = Class.forName(conf.get(MRJobConfig.OUTPUT_VALUE_CLASS)).newInstance.asInstanceOf[Writable]
//      size += HadoopSerializationGlue.readInputAsByteArray(value, in)
//      return ReduceCollectorInput(conf, key, value, size, read[Boolean](in))
//    }
//
//    def writes(out: Output, value: ReduceCollectorInput) = {
//      HadoopSerializationGlue.writeOutputAsByteArray(value.conf, out)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.key.asInstanceOf[Writable], out)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.value.asInstanceOf[Writable], out)
//      write[Boolean](out, value.reStream)
//    }
//  }
//
//  def fromBytes (bytes: Array[Byte]): ReduceCollectorInput = fromByteArray[ReduceCollectorInput] (bytes)
//  def toBytes: Array[Byte] = toByteArray[ReduceCollectorInput] (this)

implicit object ReduceCollectorInputFormat extends  sjson.json.Format[ReduceCollectorInput] {
  import dispatch.json._
  import HadoopSerializationGlue._
  import sjson.json.DefaultProtocol._

  val CONFIGURATION = JsString("configuration")
  val KEY = JsString("key")
  val VALUE = JsString("values")
  val RESTREAM = JsString("restream")

  def reads(json: JsValue): ReduceCollectorInput = json match {
    case JsObject(m) => { ReduceCollectorInput(
      stringToWritable[Configuration](fromjson[String](m(CONFIGURATION))),
      stringToWritable(Class.forName(conf.get("mrstreamer.map.input.key.class")).newInstance.asInstanceOf[Writable], fromjson[String](m(KEY))),
      stringToWritable(Class.forName(conf.get("mrstreamer.map.input.key.class")).newInstance.asInstanceOf[Writable], fromjson[String](m(VALUE))),
      0,
      fromjson[Boolean](m(RESTREAM))
    )
    }
    case _ => throw new RuntimeException("JsString expected")
  }
  def writes(msi: ReduceCollectorInput) : JsValue = JsObject(
    Map(
      CONFIGURATION -> writableToJsString(msi.conf),
      KEY -> writableToJsString(msi.key.asInstanceOf[Writable]),
      VALUE -> writableToJsString(msi.value.asInstanceOf[Writable]),
      RESTREAM -> tojson(msi.reStream)
    )
  )
}
  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[ReduceCollectorInput](bytes)
  def fromJSON(js: String) = fromjson[ReduceCollectorInput](Js(js))

}
