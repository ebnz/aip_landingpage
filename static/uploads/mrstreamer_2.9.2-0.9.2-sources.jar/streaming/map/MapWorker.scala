/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.map

import org.apache.hadoop.mapreduce.{Mapper, MRMapper, MRJobConfig}
import hadoopInterface.MRSReporter
import org.apache.hadoop.util.ReflectionUtils
import org.apache.hadoop.conf.Configuration
import _root_.streaming.reduce.RestoreTagCollector
import algorithms.MRClass
import scala.Some

//import sbinary._
//import sbinary.Operations._
//import sbinary.DefaultProtocol._
import hadoopInterface.{ DummyReporter, MapReporter, HadoopSerializationGlue }
import collection.mutable.ListBuffer
import org.apache.hadoop.mapred.RawSplit
import org.apache.hadoop.io.{ DataInputBuffer, Writable }
import org.apache.hadoop.{ mapred, mapreduce }
import compat.Platform.currentTime
import akka.serialization.RemoteActorSerialization
import streaming._
import de.uni_heidelberg.ifi.pvs.mrstreamer.Worker
import grizzled.slf4j.Logging
import akka.serialization._
import akka.serialization.Serializable.{ScalaJSON}
import akka.serialization.JsonSerialization._
import org.codehaus.jackson.JsonLocation
import com.google.protobuf.TextFormat
import akka.remote.protocol.RemoteProtocol.RemoteActorRefProtocol
import akka.actor.{Uuid, ActorRef, Actor}
import RemoteActorSerializationHelper._
import hadoopInterface.HadoopSerializationGlue._
import scala.collection.JavaConverters._

/**
 * Represents a mapper. Each mapper runs in its own thread.
 *
 * User: flangner
 * Date: 12.05.2010
 * Time: 16:55:08
 */
class MapWorker extends Actor with Logging {

  // a mapper map for this worker-thread (key -> MapAlgorithm-Instance)
  private var mapperMap: Map[Any, Any] = Map.empty

  private var identifier: Int = -1

  private var collector: MapCollectorClient = null

  private var startTime: Long = 0

  private var profileName: String = "unknown"

  private var startP: Long = -1

  private var conf: mapred.JobConf = null

  private var useHadoopAPI: Boolean = false

  private var reducer: Array[ActorRef] = null

  private var mapCollectorServer: ActorRef = null

  private var api : streaming.API = null

  private var hadoopMapperList : List[ Mapper[Any, Any, Any, Any] ] = Nil


  /**
   * method to get messages from the actor's mailbox (as long as it is running)
   */
  def receive = {

    // initialization
    case MapperInit(id: Int, conf: mapred.JobConf, startTime: Long, mapCollector: ActorRef,
      reduceWorkers: Array[ActorRef]) => {

      this.identifier = id

      this.reducer = reduceWorkers

      this.conf = conf
      conf.setClassLoader(this.getClass.getClassLoader) // TODO Probably needs to changed when used as library
      if (Worker.workerActor.isDefined) {
        val r = Worker.workerActor map (_ !! "getClassLoader")
        val cl = r.get.asInstanceOf[Option[ClassLoader]]
        conf.setClassLoader(cl.get)
      }

      this.useHadoopAPI = conf.get("mrstreamer.mapAlgorithm") == null

      // this is redundant with previous line 'useHadoopAPI' but for later it should be nicer
      this.api = streaming.API.getAPI(conf)

      this.collector = new MapCollectorClient(id, mapCollector, reduceWorkers, conf)

      this.mapCollectorServer = mapCollector

      this.profileName = "m" + identifier

      this.startTime = startTime

      become(initialized)

      debug("MapWorker-"+identifier+" initialized!")
      self.reply("done")

    }
  }

  def initialized: Receive = {

    case MapStreamInput(id: Int, config: Configuration, key: Any, values: ListBuffer[Any]) => {

      if (startP == -1) startP = currentTime - startTime

      api match {
        case HadoopMapReduceStreamingAPI =>
        {

          val jlist : java.util.List[Any] = values.toList.asJava
          hadoopMapperList foreach( x => {
            val mapper : MRMapper[Any, Any, Any, Any, Any] = x.asInstanceOf[MRMapper[Any, Any, Any, Any, Any]]

            val jobID = mapreduce.JobID.forName(conf.get(MRJobConfig.ID))
            val taskAttemptID = new mapreduce.TaskAttemptID(jobID.getJtIdentifier, jobID.getId, mapreduce.TaskType.MAP, identifier, 0)
            val taskContext = new org.apache.hadoop.mapreduce.task.TaskAttemptContextImpl(conf, taskAttemptID);
            val inputFormat = ReflectionUtils.newInstance(taskContext.getInputFormatClass, conf).asInstanceOf[org.apache.hadoop.mapreduce.InputFormat[Any, Any]]
            val writer: mapreduce.RecordWriter[Any, Any] = new MRSRecordWriter[Any, Any](new RestoreTagCollector(id, collector, conf, MRJobConfig.MAP_OUTPUT_KEY_CLASS, MRJobConfig.MAP_OUTPUT_VALUE_CLASS))
            val reader: mapreduce.RecordReader[Any, Any] = inputFormat.createRecordReader(null, taskContext)
            val committer: mapreduce.OutputCommitter = null // TODO Investigate, probably low-prio
            val reporter: mapreduce.StatusReporter = new MRSReporter
            val mapContext: mapreduce.MapContext[Any, Any, Any, Any] = new mapreduce.task.MapContextImpl[Any, Any, Any, Any](conf, taskAttemptID, reader, writer, committer, reporter, null)
            val mapperContext: org.apache.hadoop.mapreduce.Mapper[Any, Any, Any, Any]#Context = new mapreduce.lib.map.WrappedMapper[Any, Any, Any, Any].getMapContext(mapContext).asInstanceOf[org.apache.hadoop.mapreduce.Mapper[Any, Any, Any, Any]#Context]

            mapper.remap(jlist, mapperContext)
          })

        }
        case _ =>
          values.foreach { value =>
            processInput(id, key, value)
          }
      }

    }

    case MapFileSplit(split: mapreduce.lib.input.FileSplit) => {
      val mapper: mapreduce.Mapper[Any, Any, Any, Any] = conf.getClass(MRJobConfig.MAP_CLASS_ATTR, classOf[mapreduce.Mapper[Any, Any, Any, Any]]).newInstance.asInstanceOf[mapreduce.Mapper[Any, Any, Any, Any]]
      
      val jobID = mapreduce.JobID.forName(conf.get(MRJobConfig.ID))
      val taskAttemptID = new mapreduce.TaskAttemptID(jobID.getJtIdentifier, jobID.getId, mapreduce.TaskType.MAP, identifier, 0)
      val taskContext = new org.apache.hadoop.mapreduce.task.TaskAttemptContextImpl(conf, taskAttemptID);
      val inputFormat = ReflectionUtils.newInstance(taskContext.getInputFormatClass, conf).asInstanceOf[org.apache.hadoop.mapreduce.InputFormat[Any, Any]]
      val writer: mapreduce.RecordWriter[Any, Any] = new MRSRecordWriter[Any, Any](new RestoreTagCollector(0, collector, conf, MRJobConfig.MAP_OUTPUT_KEY_CLASS, MRJobConfig.MAP_OUTPUT_VALUE_CLASS))
      val reader: mapreduce.RecordReader[Any, Any] = inputFormat.createRecordReader(split, taskContext)
      val committer: mapreduce.OutputCommitter = null // TODO Investigate, probably low-prio
      val reporter: mapreduce.StatusReporter = new MRSReporter
      val mapContext: mapreduce.MapContext[Any, Any, Any, Any] = new mapreduce.task.MapContextImpl[Any, Any, Any, Any](conf, taskAttemptID, reader, writer, committer, reporter, split)
      val mapperContext: org.apache.hadoop.mapreduce.Mapper[Any, Any, Any, Any]#Context = new mapreduce.lib.map.WrappedMapper[Any, Any, Any, Any].getMapContext(mapContext).asInstanceOf[org.apache.hadoop.mapreduce.Mapper[Any, Any, Any, Any]#Context]


      // save mapper for later restreaming
      hadoopMapperList = mapper :: hadoopMapperList

      reader.initialize(split, mapContext)
      mapper.run(mapperContext)

    }

    case MapInput(split: RawSplit) => {
      var recordCount = 0

      if (startP == -1) startP = currentTime - startTime

      // @taken from org.apache.hadoop.mapred.MapTask#runOldMapper
      // reinstantiate the split
      val inputSplit: mapred.InputSplit = mapred.AccessRestrictionBypass.getInstance(split.getClassName).asInstanceOf[mapred.InputSplit]
      val splitBuffer: DataInputBuffer = new DataInputBuffer
      val bArray: Array[Byte] = split.getBytes.getBytes
      splitBuffer.reset(bArray, 0, bArray.length)
      inputSplit.readFields(splitBuffer)

      // open input
      val reporter: mapred.Reporter = new MapReporter(inputSplit)
      val rawIn: mapred.RecordReader[Any, Any] = conf.getInputFormat.getRecordReader(inputSplit, conf, reporter).asInstanceOf[mapred.RecordReader[Any, Any]]

      val key = rawIn.createKey
      val value = rawIn.createValue

      while (rawIn.next(key, value)) {
        processInput(0, key, value)
        recordCount += 1
      }

      trace("Mapped " + recordCount + " records.")

    }

    // request of the MRStreamer whether this mapper has any unprocessed data or not
    // buffer will be flushed after answering this request
    case HasFinished(value: Boolean) => {

      val finished: Boolean = this.collector.isFinishedAndFlush

      for (red: ActorRef <- this.reducer) {
        red ! HasFinished(finished && value)
      }

    }

    // received a finish command from the simulation framework
    case "finish" => {

      // flush the buffer before ...
      this.collector.isFinishedAndFlush

      // close the mappers if we are using the Hadoop interface
      if (useHadoopAPI) {
        for (entry <- mapperMap) {
          entry._2.asInstanceOf[mapred.Mapper[Any, Any, Any, Any]].close()
        }
      }

      // ... and after closing the mapper
      this.collector.isFinishedAndFlush

      // tell the collector that we finished if it still has non-forwarded messages
      this.collector.finished(true, profileName, startP)

      debug("MapWorker-"+identifier+" finished!")
    }

    case "shutdown" => {

      if (!collector.isFinishedAndFlush) {
        throw new RuntimeException("Mapper-" + identifier + " was killed before its buffer was flushed!")
      }

      collector.stop()
      //mapCollectorServer.stop

      //        for (red: ActorRef <- reducer) {
      //          red.stop
      //        }

      //exit // TODO: Whoa!
      self.reply(true)
      self.stop()

    }

    case ev => error("MapWorker-"+identifier+": received unknown command: " + ev)
  }

  override def postStop {
    debug("MapWorker-"+identifier+": stopped")
//    if (!conf.getBoolean("mrstreamer.distributed", false)) {
//      collector.stop
//    }
    super.postStop
  }

  /**
   *  Method to execute the map-algorithm for a given key-value pair.
   *
   * @param id - for this iteration.
   * @param key
   * @param value
   */
  private def processInput(id: Int, key: Any, value: Any) {

    // lookup mapper object to execute map function
    val result = mapperMap.get(key)
    var mapper: Any = null
    result match {

      // reducer does not exist
      case None => {

        // load mapper implementation
        if (useHadoopAPI) {
          val map: mapred.Mapper[Any, Any, Any, Any] = conf.getMapperClass.newInstance.asInstanceOf[mapred.Mapper[Any, Any, Any, Any]]
          mapperMap += key -> map
          mapper = map
        } else {

          val map: MRClass = Class.forName(conf.get("mrstreamer.mapAlgorithm")).newInstance.asInstanceOf[MRClass]
          map.init(conf)
          mapperMap += key -> map
          mapper = map
        }
      }

      // there is a already a mapper available
      case Some(map) => {

        mapper = map
      }
    }

    val markedCollector: Collector = new RestoreTagCollector(id, collector, conf, MRJobConfig.MAP_OUTPUT_KEY_CLASS,
      MRJobConfig.MAP_OUTPUT_VALUE_CLASS)

    // execute the map-step
    if (useHadoopAPI) {
      val oldContextClassLoader = Thread.currentThread.getContextClassLoader
      Thread.currentThread.setContextClassLoader(this.getClass.getClassLoader) // Workaround for evil classloader selection in Apache Mahout
      mapper.asInstanceOf[mapred.Mapper[Any, Any, Any, Any]].configure(conf)
      mapper.asInstanceOf[mapred.Mapper[Any, Any, Any, Any]].map(key, value, markedCollector, new DummyReporter)
      Thread.currentThread.setContextClassLoader(oldContextClassLoader)
    } else {
      mapper.asInstanceOf[MRClass].map(key, value, markedCollector)
    }

  }
}

/**
 *  message-class for mapper initialization messages
 *
 * @param id - mappers identifier
 * @param env - Environment (legacy)
 * @param jobConf - JobConf (Hadoop)
 * @param startTime
 * @param mapCollector
 * @param reducers
 */
case class MapperInit(id: Int, jobConf: mapred.JobConf, startTime: Long, mapCollector: ActorRef,
  reducers: Array[ActorRef]) extends ScalaJSON[MapperInit] {

  def this() = this(-1, new mapred.JobConf, -1, null.asInstanceOf[ActorRef],
    null.asInstanceOf[Array[ActorRef]])

  implicit object MapperInitFormat extends sjson.json.Format[MapperInit] with Logging {
//    def reads(in: Input): MapperInit = {
//      val idIn = read[Int](in)
//      HadoopSerializationGlue.readInputAsByteArray(jobConf.asInstanceOf[Writable], in)
//      jobConf.setClassLoader(classOf[mapred.JobConf].getClassLoader)
//      val startTimeIn = read[Long](in)
//
//      val distributed: Boolean = jobConf.getBoolean("mrstreamer.distributed", false)
//
//      val collector: ActorRef =
//        if (distributed) {
//          RemoteActorSerialization.fromBinaryToRemoteActorRef(read[Array[Byte]](in))
//        } else {
//          val collectorUUID = new Uuid(read[String](in))
//          Actor.registry.actorFor(collectorUUID).get
//        }
//
//      val reds: Array[ActorRef] = new Array[ActorRef](jobConf.getNumReduceTasks)
//      if (distributed) {
//        for (i <- 0 until reds.length) {
//          reds(i) = RemoteActorSerialization.fromBinaryToRemoteActorRef(read[Array[Byte]](in))
//        }
//      } else {
//        val rawReducers = read[Array[String]](in)
//        for (i <- 0 until rawReducers.length) {
//          reds(i) = Actor.registry.actorFor(new Uuid(rawReducers(i))).get
//        }
//      }
//
//      MapperInit(idIn, jobConf, startTimeIn, collector, reds)
//    }
//
//    def writes(out: Output, value: MapperInit) {
//      write[Int](out, value.id)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.jobConf, out)
//      write[Long](out, value.startTime)
//
//      if (!jobConf.getBoolean("mrstreamer.distributed", false)) {
//        write[String](out, value.mapCollector.getUuid().toString)
//        val reds: Array[String] = new Array[String](value.reducers.length)
//        for (i <- 0 until value.reducers.length) {
//          reds(i) = value.reducers(i).getUuid().toString
//        }
//        write[Array[String]](out, reds)
//      } else {
//        write[Array[Byte]](out, RemoteActorSerialization.toRemoteActorRefProtocol(value.mapCollector).toByteArray)
//        for (i <- 0 until value.reducers.length) {
//          write[Array[Byte]](out, RemoteActorSerialization.toRemoteActorRefProtocol(value.reducers(i)).toByteArray)
//        }
//
//      }
//    }
    import dispatch.json._
    import HadoopSerializationGlue._
    import sjson.json.DefaultProtocol._

    val ID = JsString("id")
    val CONFIGURATION = JsString("configuration")
    val STARTTIME = JsString("startTime")
    val MAPCOLLECTOR = JsString("mapCollector")
    val REDUCERS = JsString("reducers")

    def reads(json: JsValue): MapperInit = json match {
      case JsObject(m) => {
        MapperInit(
        fromjson[Int](m(ID)),
        jsValueToWritable[mapred.JobConf](m(CONFIGURATION).asInstanceOf[JsString]),
        fromjson[Long](m(STARTTIME)),
        fromBase64StringToRemoteActorRef(m(MAPCOLLECTOR).asInstanceOf[JsString].toString()),
        (fromjson[List[String]](m(REDUCERS)) map (s => fromBase64StringToRemoteActorRef(s))).toArray
      )   // FIXME
      }
      case _ => throw new RuntimeException("JsString expected")
    }
    def writes(mi: MapperInit) : JsValue =  {
      val out = JsObject(
      Map(
        ID -> JsNumber(id),
        CONFIGURATION -> writableToJsString(mi.jobConf),
        STARTTIME -> JsNumber(mi.startTime),
        MAPCOLLECTOR -> JsString(fromRemoteActorRefToBase64String(mapCollector)),
        REDUCERS -> JsArray((reducers.map(r => JsString(fromRemoteActorRefToBase64String(r))).toList))
      )
    )
      debug("MapperInit = " + out)
      out
    }

  }
  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[MapperInit](bytes)
  def fromJSON(js: String) = fromjson[MapperInit](Js(js))
}

/**
 * message-class for the mapper input
 *
 * @param split - the data split to retrieve key-value pairs from
 */
case class MapInput(split: RawSplit) extends ScalaJSON[MapInput] {
//  extends SBinary[MapInput] {
//
  def this() = this(new RawSplit)
//
//  implicit object MapInputFormat extends Format[MapInput] {
//    def reads(in: Input): MapInput = {
//      HadoopSerializationGlue.readInputAsByteArray(split.asInstanceOf[Writable], in)
//      MapInput(split.asInstanceOf[RawSplit])
//    }
//
//    def writes(out: Output, value: MapInput) {
//      HadoopSerializationGlue.writeOutputAsByteArray(value.split.asInstanceOf[Writable], out)
//    }
//  }
//
//  def fromBytes(bytes: Array[Byte]): MapInput = fromByteArray[MapInput](bytes)
//  def toBytes: Array[Byte] = toByteArray[MapInput](this)
//}

  implicit object MapInputFormat extends  sjson.json.Format[MapInput] {
    import dispatch.json._
    import HadoopSerializationGlue._
    def reads(json: JsValue): MapInput = json match {
      case JsString(rs) => {
        val split = stringToWritable[RawSplit](rs)
        MapInput(split)
      }
      case _ => throw new RuntimeException("JsString expected")
    }
    def writes(mi: MapInput) : JsValue = writableToJsString(mi.split)
  }

  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[MapInput](bytes)
  def fromJSON(js: String) = fromjson[MapInput](Js(js))
}

case class MapFileSplit(split: mapreduce.lib.input.FileSplit)
  extends ScalaJSON[MapFileSplit] {
  def this() = this(new mapreduce.lib.input.FileSplit)
//
//  implicit object MapFileSplitFormat extends sbinary.Format[MapFileSplit] {
//    def reads(in: Input): MapFileSplit = {
//      HadoopSerializationGlue.readInputAsByteArray(split.asInstanceOf[Writable], in)
//      MapFileSplit(split.asInstanceOf[mapreduce.lib.input.FileSplit])
//    }
//
//    def writes(out: Output, value: MapFileSplit) {
//      HadoopSerializationGlue.writeOutputAsByteArray(value.split.asInstanceOf[Writable], out)
//    }
//  }
//
//  def fromBytes(bytes: Array[Byte]): MapFileSplit = fromByteArray[MapFileSplit](bytes)
//  def toBytes: Array[Byte] = toByteArray[MapFileSplit](this)
  implicit object MapFileSplitFormat extends  sjson.json.Format[MapFileSplit] {
    import dispatch.json._
    import HadoopSerializationGlue._
    def reads(json: JsValue): MapFileSplit = json match {
      case JsString(rs) => {
        val split = stringToWritable[mapreduce.lib.input.FileSplit](rs)
        MapFileSplit(split)
      }
      case _ => throw new RuntimeException("JsString expected")
    }
    def writes(mfs: MapFileSplit) : JsValue = writableToJsString(mfs.split)
  }

  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[MapFileSplit](bytes)
  def fromJSON(js: String) = fromjson[MapFileSplit](Js(js))

}

/**
 * message class for streaming mapper input
 *
 * @param id - iteration marker
 * @param env - legacy Environment
 * @param key
 * @param values
 */
case class MapStreamInput(id: Int, conf: Configuration, key: Any, values: ListBuffer[Any]) extends ScalaJSON[MapStreamInput] { //
//  extends SBinary[MapStreamInput] {
//
  def this() = this(0, new Configuration, null.asInstanceOf[Any], ListBuffer.empty)
//
//  implicit object MapStreamInputFormat extends sbinary.Format[MapStreamInput] {
//
//    def reads(in: Input): MapStreamInput = {
//      val id: Int = read[Int](in)
//      HadoopSerializationGlue.readInputAsByteArray(conf.asInstanceOf[Writable], in)
//      val key: Writable = Class.forName(conf.get("mrstreamer.map.input.key.class")).newInstance.asInstanceOf[Writable]
//      HadoopSerializationGlue.readInputAsByteArray(key, in)
//      val numValues: Int = read[Int](in)
//      var values: ListBuffer[Any] = ListBuffer.empty
//      for (i <- 0 until numValues) {
//        val value: Writable = Class.forName(conf.get("mrstreamer.map.input.value.class")).newInstance.asInstanceOf[Writable]
//        HadoopSerializationGlue.readInputAsByteArray(value, in)
//        values += value
//      }
//
//      new MapStreamInput(id, conf, key, values)
//    }
//
//    def writes(out: Output, value: MapStreamInput) {
//      write[Int](out, value.id)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.conf, out)
//      HadoopSerializationGlue.writeOutputAsByteArray(value.key.asInstanceOf[Writable], out)
//      write[Int](out, value.values.size)
//      value.values.foreach((va: Any) => {
//        HadoopSerializationGlue.writeOutputAsByteArray(va.asInstanceOf[Writable], out)
//      })
//    }
//  }
//
//  def fromBytes(bytes: Array[Byte]): MapStreamInput = fromByteArray[MapStreamInput](bytes)
//  def toBytes: Array[Byte] = toByteArray[MapStreamInput](this)
implicit object MapStreamInputFormat extends  sjson.json.Format[MapStreamInput] {
  import dispatch.json._
  import HadoopSerializationGlue._
  import sjson.json.DefaultProtocol._

  val ID = JsString("id")
  val CONFIGURATION = JsString("configuration")
  val KEY = JsString("key")
  val VALUES = JsString("values")

  def reads(json: JsValue): MapStreamInput = json match {
    case JsObject(m) => { MapStreamInput(
      fromjson[Int](m(ID)),
      stringToWritable[Configuration](fromjson[String](m(CONFIGURATION))),
      stringToWritable(Class.forName(conf.get("mrstreamer.map.input.key.class")).newInstance.asInstanceOf[Writable], fromjson[String](m(KEY).asInstanceOf[JsString])),
      ListBuffer(fromjson[List[String]](VALUES).map(s => stringToWritable(Class.forName(conf.get("mrstreamer.map.input.key.class")).newInstance.asInstanceOf[Writable], s)))
    )
    }
    case _ => throw new RuntimeException("JsString expected")
  }
  def writes(msi: MapStreamInput) : JsValue = JsObject(
    Map(
      ID -> JsNumber(id),
      CONFIGURATION -> writableToJsString(msi.conf),
      KEY -> writableToJsString(key.asInstanceOf[Writable]),
      VALUES -> JsArray(values.map(v => writableToJsString(v.asInstanceOf[Writable])).toList)
    )
  )
}


  def toJSON: String = JsValue.toJson(tojson(this))
  def toBytes: Array[Byte] = tobinary(this)
  def fromBytes(bytes: Array[Byte]) = frombinary[MapStreamInput](bytes)
  def fromJSON(js: String) = fromjson[MapStreamInput](Js(js))
}

/**
 * Message token to check if a mapper and the reducer behind have no more data to process.
 */
case class HasFinished(value: Boolean)
