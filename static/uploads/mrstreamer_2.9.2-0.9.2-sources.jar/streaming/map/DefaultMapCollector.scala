/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.map

import org.apache.hadoop.conf.Configuration
import java.util.Random
import akka.actor.ActorRef
import collection.mutable.ListBuffer
import org.apache.hadoop.mapred.JobConf
import streaming.Collector
import streaming.reduce.ReduceInput

/**
 * Default implementation for mapper of the Collector-trait.
 * Key/val pairs are directly forwarded to the reducer.
 * No buffering etc. is done yet..
 *
 * User: flangner
 * Date: 10.05.2010
 * Time: 12:24:33
 */
class DefaultMapCollector (conf: JobConf, reduceWorkers :Array[ActorRef]) extends Collector {

  def collect(key: Any, values: ListBuffer[Any]) {

    // lookup the reducer | implicit mapping (key -> ReduceWorker)
    // @see java.util.Random
    val keyHash: Int = key.hashCode
    val random: Random = new Random(keyHash)
    val reducerId: Int = random.nextInt(reduceWorkers.length)
    val reducer: ActorRef = reduceWorkers(reducerId)

    // sending the reduce input to the reducer
    reducer ! ReduceInput(conf, key, values)
  }

  override def collect(key: Any, value: Any) {
    var list: ListBuffer[Any] = ListBuffer.empty
    list += value
    collect(key, list)
  }

/*
 * unsupported Operations
 */

  override def init(conf: Configuration) {
    throw new UnsupportedOperationException
  }

  override def thresholdExceeded(process: Long) {
    throw new UnsupportedOperationException
  }

  override def finished(success: Boolean) {
    throw new UnsupportedOperationException
  }
}