/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming.map

import org.apache.hadoop.conf.Configuration
import akka.actor.ActorRef
import streaming._
import org.apache.hadoop.io.Writable
import hadoopInterface.{DummyReporter, HadoopSerializationGlue}
import org.apache.hadoop.mapred.{JobConf, Reducer}
import reduce.{TaggedKey, RestoreTagCollector}
import util.MapBuffer
import collection.mutable.ListBuffer
import org.apache.hadoop.io.WritableUtils
import org.apache.hadoop.mapreduce.MRJobConfig
import grizzled.slf4j.Logging

/**
 * Each map-worker uses one MapCollectorClient to collect the results.
 * The Map Collector Client executes the user's collector implementation and
 * forwards its results to the reducer. Some meta-data computed meanwhile is
 * send to the central collector actor at the MR master server.
 *
 * User: flangner
 * Date: 27.07.2010
 * Time: 19:40:45
 */

class MapCollectorClient(id: Int, mapCollectorServer: ActorRef, reduceWorkers: Array[ActorRef], conf: JobConf) extends Collector with Logging {

  // collector for sending buffered (and properly combined) results to the reducer
  private val collector: DefaultMapCollector = new DefaultMapCollector(conf, reduceWorkers)

  // load combiner implementation
  val api = streaming.API.getAPI(conf)

  //TODO how many combiner instances do we need? maybe one for every key... we should have a look at the algorithms
  private var combiner: Any = null
  try {
    api match {
      case HadoopMapRedAPI => {
        this.combiner = conf.getCombinerClass.newInstance
      }

      case MRStreamingAPI => {
        this.combiner = Class.forName(conf.get("mrstreamer.combineAlgorithm")).newInstance.asInstanceOf[Combiner]
        this.combiner.asInstanceOf[Combiner].init(conf)
      }

      // TODO this has to be checked later in case combiners are used with the Hadoop API
      case HadoopMapReduceStreamingAPI => {
        this.combiner = conf.getCombinerClass.newInstance
      }

      case HadoopMapReduceAPI => {
        // TODO: case HadoopMapReduceAPI See MapWorker case MapFileSplit
      }

    }
  } catch {
    case e: Exception => {
      /* I don't care */
      //TODO Really?
    }
  }

  // buffer for intermediate results
  private val buffer: MapBuffer = new MapBuffer(conf.getInt("mrstreamer.mapCollectorBufferSize", -1), handleBufferOutput)

  // instance for measuring the throughput of this mapper in bytes per second
  private val throughput: CollectorThroughput = new CollectorThroughput("MapCollector-" + id,
    conf.getLong("throughputMeasurementPeriod", 1000),
    mapCollectorServer)

  /**
   * Executes the collect operation and forwards some maintenance message to the server.
   * Buffers collect-message before if needed.
   *
   * @param key - of the mapper k,v result
   * @param value - of the mapper k,v result
   */
  override def collect(inKey: Any, value: Any) {
    // When using the new Hadoop API key objects get reused
    // clone them for use in the map
    val key = WritableUtils.clone(inKey.asInstanceOf[Writable], conf)


    // sending some maintenance information about the map progress to the master
    // TODO what if we are not using instances of Writable ...
    this.throughput.incrementCollectedBytes(HadoopSerializationGlue.sizeOf(key.asInstanceOf[Writable]) +
      HadoopSerializationGlue.sizeOf(value.asInstanceOf[Writable]))

    this.buffer.add(key, value)
  }

  /**
   * Executes finish-method on the collector implementation and forwards the message to the server.
   *
   * @param startTime - time-delta between algorithm initiation and the first reduce on this reducer.
   * @param actorName - Reducer's name for profiling.
   * @param success - whether the reducer was successful or not.
   */
  def finished(success: Boolean, actorName: String, startTime: Long) {
    mapCollectorServer ! (("mapper_finished", actorName, startTime))

    // to avoid concurrency issues on different actors sending messages at the same time to one reducer
    // every mapper has to notify all reducer after flushing its buffer
    reduceWorkers.foreach { reducer: ActorRef =>
      reducer ! "finish"
      trace("Sending finish message from " + id + " to " + reducer)
    }
  }

  /**
   * @return true, if this mapper has no more data to process. false otherwise.
   */
  def isFinishedAndFlush: Boolean = {
    val isFinished: Boolean = this.buffer.isEmpty
    if (!isFinished) this.buffer.flush()
    isFinished
  }

  def stop() {
    throughput.cancel
  }

  /**
   *  Executes the combine-method if available and collects the results.
   */
  private def handleBufferOutput(taggedKey: Any, values: ListBuffer[Any]) {

    // combine and collect
    if (this.combiner != null) {

      // retrieve the iteration-id from the markedKey and set up a collector that will wrap this information after
      // combining the results
      val markedCollector: Collector = new RestoreTagCollector(taggedKey.asInstanceOf[TaggedKey].getTag, collector,
        conf, MRJobConfig.MAP_OUTPUT_KEY_CLASS, MRJobConfig.MAP_OUTPUT_VALUE_CLASS)
      val key: Any = taggedKey.asInstanceOf[TaggedKey].getKey

      api match {
        case HadoopMapRedAPI | HadoopMapReduceStreamingAPI => {
          val iter = values.iterator
          val iterator = new java.util.Iterator[Any] {
            def hasNext: Boolean = iter.hasNext

            def next(): Any = iter.next()

            def remove() {
              throw new UnsupportedOperationException
            }
          }

          this.combiner.asInstanceOf[Reducer[Any, Any, Any, Any]].reduce(key, iterator, markedCollector, new DummyReporter)
        }
        case MRStreamingAPI => {
          this.combiner.asInstanceOf[Combiner].reduce(key, values, markedCollector)
        }

        case HadoopMapReduceAPI => {
          //TODO: case HadoopMapReduceAPI
        }

      }

      // collect only
    } else {

      this.collector.collect(taggedKey, values)
    }
  }

  /*
  * unsupported operations
  */

  override def init(conf: Configuration) {
    throw new UnsupportedOperationException
  }

  override def thresholdExceeded(progress: Long) {
    throw new UnsupportedOperationException
  }

  override def finished(success: Boolean) {
    throw new UnsupportedOperationException
  }
}
