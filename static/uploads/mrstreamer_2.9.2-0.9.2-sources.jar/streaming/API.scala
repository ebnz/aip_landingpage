/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

import org.apache.hadoop.conf.Configuration

sealed trait API {}

case object MRStreamingAPI extends API {}
case object HadoopMapRedAPI extends API {}
case object HadoopMapReduceAPI extends API {}

// this is the new streaming enabled Hadoop compatible API
// this is needed to know internally whether we need to call another remap or not
case object HadoopMapReduceStreamingAPI extends API {}

object API {
  def getAPI(conf: Configuration): API =
    if (conf.get("mrstreamer.mapAlgorithm") != null)
      MRStreamingAPI
    else
      if ( conf.getBoolean("mrstreamer.hadoop.streaming", false ) == true )
        HadoopMapReduceStreamingAPI
      else
        if (conf.getBoolean("mapred.mapper.new-api", false))
          HadoopMapReduceAPI
        else
          HadoopMapRedAPI
}