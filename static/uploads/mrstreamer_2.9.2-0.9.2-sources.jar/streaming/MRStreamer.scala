/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package streaming

import map._
import reduce._
import util.ResultEmitter
import akka.actor.Actor._
import org.apache.hadoop.util.StringUtils
import hadoopInterface.{DynamicPathFilter, HadoopMethods, HadoopConfGlue}
import java.io.DataInputStream
import util.{Profiler, Util}
import org.apache.hadoop.fs.{FileSystem, PathFilter, Path}
import compat.Platform.currentTime
import collection.mutable.ListBuffer
import grizzled.slf4j.Logging
import scala.collection.JavaConversions._
import org.apache.hadoop.mapreduce.Job
import org.apache.hadoop.mapreduce
import mapreduce.lib.input.FileSplit
import org.apache.hadoop.util.ReflectionUtils
import org.apache.hadoop.mapreduce.JobID
import java.text.SimpleDateFormat
import java.util.Date
import org.apache.hadoop.mapreduce.MRJobConfig
import java.io.File
import akka.actor.{Actor, ActorRef, Actors}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.mapred.{JobTracker, RawSplit, MRSJobClient, JobConf}
import de.uni_heidelberg.ifi.pvs.mrstreamer.{ActorInfo, StartActor, Worker}
import java.net.{URI, URL, InetSocketAddress}

/**
 * Map-Reduce Streamer as initiator of the Map-Reduce framework. This actor coordinates the messages between
 * mappers and reducers and the collectors of their results.
 *
 * User: flangner
 * Date: 10.05.2010
 * Time: 07:15:25
 *
 * @param conf - Hadoop JobConf
 */

class MRStreamer(conf: JobConf) extends Logging {

  var job: Option[Job] = None

  /**
   * Constructor for the legacy interface.
   */
  def this(conf: JobConf, input: Array[(Any, Any)]) = this (MRStreamer.addEnvToJobConf(conf, input))

  def this(input: Array[(Any, Any)]) = this (MRStreamer.envToJobConf(input))

  def this(job: Job) = {
    this (new JobConf(job.getConfiguration))
    this.job = Some(job)
  }

  //conf.setQuietMode(false)

  conf.addResource("mrstreamer-default.xml")
  conf.addResource("mrstreamer-site.xml")

  debug("Configuration is read from " + conf.toString + " " + conf.getClassLoader.getResource("mrstreamer-default.xml"))

  val api = streaming.API.getAPI(conf)
  /**init the glue. Method can be called twice without any failures */
  HadoopConfGlue.init(conf)
  //conf.setProperty("mapred.input.format.class", conf.getInputFormat.getClass.toString)

  ResultEmitter.init(conf)

  // check for re-streaming criterion
  if ((conf.get("mrstreamer.numIterations") == null) && (conf.get("mrstreamer.epsilon") == null)) {
    conf.setInt("mrstreamer.numIterations", 1)
  } else {
    conf.setIfUnset("mrstreamer.numIterations", "2")  // TODO Why 2?
  }

  /**structure to maintain map collector */
  private var mapCollectWorker: ActorRef = null

  /**structure to maintain reduce collector */
  private var reduceCollectWorker: ActorRef = null

  /**number of map actors. threads are generated with scala's actor model by AKKA */
  private val numMapWorker: Int = conf.getNumMapTasks
  debug(numMapWorker + " mappers")

  /**number of reduce actors. a reduce worker controls a set of reducers that do not run in an own thread */
  private val numReduceWorker: Int = conf.getNumReduceTasks
  debug(numReduceWorker + " reducers")

  /**structure for map workers */
  private val mapWorkers: Array[ActorRef] = new Array[ActorRef](numMapWorker)

  /**structure for reduce workers */
  private val reduceWorkers: Array[ActorRef] = new Array[ActorRef](numReduceWorker)

  /**retrieve the addresses of participating hosts */
  private val hosts: List[InetSocketAddress] = conf.getTrimmedStringCollection("mrstreamer.hosts").map(Util.parseInetSockAddress).toList


  private val distributionMode = DistributionMode.getDistributionMode(conf)
  info("Running in distribution mode " + distributionMode)
  // We need configured hosts if we are using raw Akka
  if (distributionMode == RawAkka) assert(hosts.size > 0)

  /**structure to maintain the map-input separated by workers */
  private val mapJobs = new Array[ListBuffer[RawSplit]](numMapWorker)
  /**for mapreduce api */
  private val mapreduceJobs = new Array[ListBuffer[mapreduce.lib.input.FileSplit]](numMapWorker)

  /**timestamp for the start of this simulation */
  private var startTime: Long = -1L

  /**instance to buffer results between map-reduce iterations */
  private val reStreamBuffer: BlockingMapBuffer = new BlockingMapBuffer(sendCheckIfFinishedTokens)

  private val jobId = new JobID(new SimpleDateFormat("yyyy-MM-dd'T'HHmmss").format(new Date), 1)
  conf.set(MRJobConfig.ID, jobId.appendTo(new java.lang.StringBuilder("job")).toString)

  /**
   * Initializes the Framework and starts the MapReduce algorithm.
   */
  def run: mapreduce.JobStatus = {

    // indicates whether profile records should be kept
    Profiler.profile = conf.getBoolean("mrstreamer.profile", false)
    info("profiling: " + Profiler.profile.toString)
    Profiler.init(conf.get("mrstreamer.statsPath"))

    // start the local AKKA-server if needed
    if (distributionMode == RawAkka) {
      val addr = Util.parseInetSockAddress(conf.get("mrstreamer.bindAddress"))
      remote.start(addr.getHostName, addr.getPort)
    }

    // create output path if needed  // TODO is this needed? FIXME This does not work most of the time URL not absolute
//    val outDir = conf.get(org.apache.hadoop.mapreduce.lib.output.FileOutputFormat.OUTDIR)
//    if (outDir != null) {
//      val tempDir = new URI(outDir + "/_temporary")
//      info("Creating " + tempDir)
//      try {
//        new File(tempDir).mkdirs
//      } catch {
//        case ex => {
//          info("Could not create " + tempDir, ex)
//        }
//      }
//    }

    // attention: Please respect the order of the following initializations, because errors might occur if you don't!

    initReduceCollector()

    // start measuring time
    this.startTime = currentTime

    initReducers()

    initMapCollector()

    initMappers()

    initMapJobs()

    startSimulation()

    endSimulation()

    while (reduceCollectWorker.isRunning) {
      Thread.sleep(500)
    }

    // shutdown the actors
    for (w: ActorRef <- mapWorkers) {
      w !! "shutdown"
      if (distributionMode.distributed) {
        remote.unregister(w)
      }
      // this may cause an exception if the worker has been shut down already. it's some sort of chicken-egg-problem.
      //w.stop

    }
    for (w: ActorRef <- reduceWorkers) {
      w ! "shutdown"
      if (distributionMode == RawAkka) {
        remote.unregister(w)
      }
      // this may cause an exception if the worker has been shut down already. it's some sort of chicken-egg-problem.
      //w.stop
    }

    mapCollectWorker.stop()

    // stop the local running AKKA-server if needed
    if (distributionMode == RawAkka) {
      remote.unregister(reduceCollectWorker)
      remote.unregister(mapCollectWorker)

      if (distributionMode == RawAkka)
        remote.shutdown
    }

    if (distributionMode.forceCleanUp) {
      info("Shutting down all actors")
      Actors.registry.shutdownAll()
    }

    new mapreduce.JobStatus(jobId, 1, 1, 1, 1, mapreduce.JobStatus.State.SUCCEEDED, mapreduce.JobPriority.NORMAL, System.getProperty("user.name"), "MRSJob", "", "")
  }

  /**
   * Prepares the MapJobs before they are send to the mappers.
   */
  private def initMapJobs() {

    var totalBytesToProcess: Long = 0L

    api match {
      case HadoopMapReduceAPI | HadoopMapReduceStreamingAPI => {
        val job = this.job.get
        val input =
          ReflectionUtils.newInstance(job.getInputFormatClass, conf);

        val splits = input.getSplits(job)

        for (i <- 0 until splits.length) {
          val split = splits(i).asInstanceOf[mapreduce.lib.input.FileSplit]
          totalBytesToProcess += split.getLength
          this.mapreduceJobs(i % numMapWorker) += split
        }
      }

      case _ => {
        // read input splits and create a mapJob per a split
        // @taken from org.apache.hadoop.JobInProgress#initTasks()
        //
        val fs: FileSystem = HadoopConfGlue.fs
        val splitFile: DataInputStream = fs.open(new Path(conf.get("mapred.job.split.file")))
        var splits: Array[RawSplit] = null
        try {
          splits = MRSJobClient.readSplitFile(splitFile);
        } finally {
          splitFile.close();
        }
        val numMapJobs: Int = splits.length;

        // compute the number of input bytes in total and for each map job and organize them into the mapJobs data-structure
        var totalBytesToProcess: Long = 0L
        for (i <- 0 until numMapJobs) {
          val split: RawSplit = splits(i)
          totalBytesToProcess += split.getDataLength

          this.mapJobs(i % numMapWorker) += split
        }

      }
    }

    info("calculated bytes: " + totalBytesToProcess / (1024 * 1024) + " MiB")
  }

  /**
   * Definition on how to initialize the map-worker.
   */
  private def initMappers() {

    // create numMapWorker
    for (i <- 0 until numMapWorker) {

      val worker: ActorRef = distributionMode match {

        case RawAkka => {
          val hostID: Int = i % hosts.size
          val address: InetSocketAddress = hosts(hostID)
          info("MapWorker-" + i + " will be started remotely at " + address.toString)
          remote.actorOf[MapWorker](address.getHostName, address.getPort)
        }
        case SharedMemory | SharedMemoryOnClientServer =>
          actorOf[MapWorker]
        case ClientServer => {
          val actor = Worker.workerManager.get ? StartActor(classOf[MapWorker])
          val actorInfo: ActorInfo = actor.get.asInstanceOf[ActorInfo]
          info("MapWorker-" + i + " has been started remotely at " + actorInfo.hostname + ":" + actorInfo.port)
          remote.actorFor(actorInfo.serviceId, actorInfo.hostname, actorInfo.port)
        }
      }

      // start the worker
      worker.start()
      val result = (worker !! MapperInit(i, conf, startTime, mapCollectWorker, reduceWorkers)).getOrElse({
        error("MapWorker-" + i + " failed to init, TIMEOUT waiting for reply!"); System.exit(-1)
      })
      if (result == "done") {
        mapWorkers(i) = worker
      } else {
        error("MapWorker-" + i + " has not been started!")
        System.exit(-1)
      }

      // initialize its mapJob structure
      this.mapJobs(i) = ListBuffer.empty[RawSplit]
      this.mapreduceJobs(i) = ListBuffer.empty[FileSplit]
    }
  }

  /**
   * Start the map-collect server.
   */
  private def initMapCollector() {

    this.mapCollectWorker = actorOf(new MapCollectorServer(startTime))
    if (distributionMode.distributed) {
      remote.register("MapCollector", mapCollectWorker)
    }

    this.mapCollectWorker.start()
  }

  /**
   *  Definition on how to initialize the reduce-worker.
   */
  private def initReducers() {

    val reducerClass = api match {
      case HadoopMapReduceAPI | HadoopMapReduceStreamingAPI => classOf[HadoopReduceWorker]
      case _ => classOf[ReduceWorker]
    }

    for (i <- 0 until numReduceWorker) {

      val worker: ActorRef = distributionMode match {
        case RawAkka => {
          val hostID: Int = i % hosts.size
          val address: InetSocketAddress = hosts(hostID)
          info("ReduceWorker-%d will be started remotely at %s.", i, address.toString)
          remote.actorOf(reducerClass, address.getHostName, address.getPort)
        }
        case SharedMemory | SharedMemoryOnClientServer => actorOf(reducerClass)
        case ClientServer => {
          val actor = (Worker.workerManager.get ? StartActor(reducerClass)).as[ActorInfo]
          actor match {
            case Some(actorInfo) => {
              info("ReduceWorker-%d has been started remotely at %s.", i, actorInfo.hostname + ":" + actorInfo.port)
              remote.actorFor(actorInfo.serviceId, actorInfo.hostname, actorInfo.port)
            }
            case None => {
              error("ReduceWorker-" + i + " failed to START, timeout waiting for reply!")
              System.exit(-1)// FIXME Error handling
              null
            }
          }
        }
      }

      worker.start()
      val result = (worker !! ReducerInit(i, conf, startTime, reduceCollectWorker)).getOrElse({
        error("ReduceWorker-" + i + " failed to INIT, timeout waiting for reply!"); System.exit(-1)
      })

      if (result == "done") {
        reduceWorkers(i) = worker
      } else {
        error("ReduceWorker-"+i+" failed to init: "+ result)
        System.exit(-1)
      }
    }
  }

  /**
   * Initializes the reduce-collector server.
   */
  private def initReduceCollector() {

    this.reduceCollectWorker = actorOf(new ReduceCollectorServer(conf, reStreamBuffer))

    if (distributionMode.distributed) {
      remote.register("ReduceCollector", reduceCollectWorker)
    }

    this.reduceCollectWorker.start()
  }

  /**
   * Distributes input to map actors.
   */
  private def startSimulation() {

    for (i <- 0 until numMapWorker) {
      api match {
        case HadoopMapReduceAPI | HadoopMapReduceStreamingAPI => {
          mapreduceJobs(i) foreach {
            mapWorkers(i) ! MapFileSplit(_)
          }
        }
        case _ => {
          this.mapJobs(i).foreach {
            job: RawSplit =>
              mapWorkers(i) ! MapInput(job)
          }
        }
      }

    }

    if (conf.getInt("mrstreamer.numIterations", 1) > 1) {
      var mapWorkerId: Int = 0
      var job: (Any, ListBuffer[Any]) = reStreamBuffer.retrieve

      while (job != null) {
        val id: Int  = job._1.asInstanceOf[TaggedKey].getTag
        val key: Any = job._1.asInstanceOf[TaggedKey].getKey

        // send the same data to all mappers
        if (conf.getBoolean("mrstreamer.oneForAll", false)) {

          mapWorkers.foreach(worker => worker ! MapStreamInput(id, conf, key, job._2.asInstanceOf[ListBuffer[Any]].clone()))

          // send data only to one mapper
        } else {

          mapWorkers(mapWorkerId) ! MapStreamInput(id, conf, key, job._2.asInstanceOf[ListBuffer[Any]])
          mapWorkerId = (mapWorkerId + 1) % numMapWorker
        }
        job = reStreamBuffer.retrieve
      }
    }
  }

  /**
   * Sends a "finish" message to all map workers, if no more input is expected.
   */
  private def endSimulation() {

    for (i <- 0 until numMapWorker) {
      mapWorkers(i) ! "finish"
    }
  }

  /**
   * Sends a token to determine, if the algorithm has passed the framework completely.
   */
  private def sendCheckIfFinishedTokens() {

    mapWorkers.foreach {
      worker: ActorRef => {
        worker ! HasFinished(true)
      }
    }
  }
}

/**
 * Holder for the framework's state.
 */
object MRStreamer {

  /**
   * Method to paste the information given by the environment object into a newly created Hadoop JobConf.
   */
  def envToJobConf(input: Array[(Any, Any)]): JobConf = {
    val conf: JobConf = new JobConf
    addEnvToJobConf(conf, input)
  }

  def addEnvToJobConf(conf: JobConf, input: Array[(Any, Any)]): JobConf = {
    //    conf.set("mapred.system.dir", env.get("statsPath"))
    //    conf.setNumMapTasks(env.getInt("numMaps"))
    conf.setUseNewMapper(false)
    HadoopConfGlue.init(conf)

    // set input paths
    val pathFilter: DynamicPathFilter = new DynamicPathFilter(true)
    var directories: Set[String] = Set.empty
    for (k <- 0 until input.length) {
      val path: Path = HadoopConfGlue.fs.makeQualified(new Path(input(k)._1.asInstanceOf[String]))
      pathFilter.add(path.getParent)
      pathFilter.add(path)
      directories += path.getParent.toString
    }

    val dirIter: Iterator[String] = directories.iterator
    var dirs: String = dirIter.next()
    while (dirIter.hasNext) {
      dirs += StringUtils.ESCAPE_CHAR + dirIter.next
    }

    pathFilter.serialize()

    conf.set("mapred.input.dir", dirs)
    conf.setClass("mapred.input.pathFilter.class", pathFilter.getClass, pathFilter.asInstanceOf[PathFilter].getClass)
    /*    try {
      conf.setInputFormat(env.getObject("mapred.input.format.class").getClass.asInstanceOf[java.lang.Class[InputFormat[_, _]]])
    } catch {
      case e: Exception => // ignored
    }
*/
    //
    // write input splits
    // @taken from org.apache.hadoop.mapred.JobClient#submitJobInternal()
    //
    // TODO make this framework support more than one mapjob at a time (jobID != 0)
    val jobID: String = "MRJob"
    val submitJobDir: Path = new Path(HadoopConfGlue.getSystemDir, jobID)
    val submitSplitFile: Path = new Path(submitJobDir, "job.split")
    // this is risky as the mrstreamer.reduceCollectorBufferSize has to be set to same value
    conf.setNumMapTasks(HadoopMethods.writeOldSplits(conf, submitSplitFile))
    conf.set("mapred.job.split.file", submitSplitFile.toString)

    conf
  }
}


sealed trait DistributionMode {
  val distributed = false
  val forceCleanUp = false
}

case object SharedMemory extends DistributionMode {
  override val distributed = false
  override val forceCleanUp = true
}

case object SharedMemoryOnClientServer extends DistributionMode {
  override val distributed = false
}

case object RawAkka extends DistributionMode {
  override val distributed = true
  override val forceCleanUp = true
}

case object ClientServer extends DistributionMode {
  override val distributed = true
}

object DistributionMode {
  def getDistributionMode(conf: Configuration): DistributionMode =
//    if (!conf.getBoolean("mrstreamer.distributed", false)) {
//      if (Worker.workerActor.isDefined)
//        SharedMemoryOnClientServer
//      else
//        SharedMemory
//    } else
//    if (Worker.workerActor.isDefined)
//      ClientServer
//    else
//      RawAkka
    if (Worker.workerActor.isDefined)
      ClientServer
    else
      SharedMemory
}