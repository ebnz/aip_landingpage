/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.olap

import org.apache.hadoop.mapred.JobConf
import streaming.{Collector, MRStreamer}
import eval.{ResultStore, Sample}
import java.io.File
import algorithms.MRClass
import util.{ResultEmitter, ScalaIO, Files}
import collection.mutable.{ListBuffer, ArrayStack}
import org.apache.hadoop.conf.Configuration

class NetflixAVG extends MRClass with ScalaIO {

  
  def map(fileName: Any, inputValue: Any, resultCollector: Collector){
    
   
    var i:Int = 0
    var m:String = ""
    forFileLines(fileName.asInstanceOf[String]){ l =>
      if(l.contains(":")){
        // new movie found        
       if(i>0){
          resultCollector.collect(m, i)
       }
       
       m = l.substring(0, l.length-2)
        
       i = 0
      }else{
        // rating found
        // count number of ratings
        i+=1
      }
    }
    resultCollector.collect(m, i)
    
  }
  
  def reduce(inputKey: Any, values: ListBuffer[Any], redAdapter:Collector){
    values.foreach{ inputValue => redAdapter.collect(inputKey, inputValue) }
  }
  
  override def init(conf:Configuration) {
  }
}

class NetflixAVGCollector extends Collector with ResultStore {
  
	var count:Int = 0
	var ratin:Int = 0
 
	var conf: Configuration = null
 
	override def init(conf: Configuration){
		this.conf = conf
	}
  
	def collect(key: Any, value: Any) {
		var r:Int = value.asInstanceOf[Int]
		count+=1
		ratin+=r
	}

  def thresholdExceeded (progress: Long) {

    // calculate intermediate resultc
    var avg: Double = ratin.asInstanceOf[Double] / count.asInstanceOf[Double]

    // adding intermediate result to result summary
    val rs = new OLAPResultSummary
    rs.set(avg)

    append(progress, rs, count)
  }
  
	def finished(succ:Boolean){
	 
		// calculate intermediate resultc
		var avg:Double = ratin.asInstanceOf[Double] / count.asInstanceOf[Double]
		  
		// add final result
		var rs = new OLAPResultSummary
	  	rs.set(avg)
	  	append(0L, rs, count)
	  
	//  	calcOfflineConversion
	//  	calcOnlineConversion
   
	  calcConservativeIntervals(1.0, 10000.0, 0.99)
	}
 
 def calcOnlineConversion(){
    val (differences, lastIndex) = getDifs(0,-1)
    val (progresses, dummy) = getProgs(lastIndex)
    
    for(row <- 0 to lastIndex-1){
      var (dif, i) = getDifs(row,row+1)
      println(progresses(row)+" "+dif(0))
      ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], dif(0).asInstanceOf[Float])
    }
  }
 
 
 
  def calcOfflineConversion(){   
    val (differences, lastIndex) = getDifs(0, -1)  // get the y-axis - values of metric dif
    val (progresses, dummy) = getProgs(lastIndex) // get the x-axis - progresses for each dif computation

    // writing data to result file defined in the environment
    for (row <- 0 to lastIndex) {
       println(progresses(row)+" " +differences(row))
       ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], differences(row).asInstanceOf[Float])
     }
   }
  
  
  def calcConservativeIntervals(a:Double, b:Double, p:Double){
    
    for(i <- 0 until samples.length){
      
      var s:Sample = samples(i)
      var avg:Double = s.resSummary.asInstanceOf[OLAPResultSummary].avg
      var prog: Long = s.outcomeInBytes
      var n = s.rawResult.asInstanceOf[Int]
      
      println(prog + " " + n)
      
      var e = (b-a)* math.sqrt( 1/(2* n.asInstanceOf[Double]) * math.log(2/(1-p)))
      
      println(prog+" " + e)
      ResultEmitter.emitAnalyzerResult(prog.toDouble, (avg-e), avg, (avg + e))
      
    }   
  }
  
 
}


object NetflixAVGExp{
  
  def main(args: Array[String])  {
    
    val netflix = new NetflixAVG()
    val netflixCol = new NetflixAVGCollector()

    val in = Files.listDir(new File("/home/boese/grand_prize/download/training_set/"), null, false)
    var input2:ArrayStack[(String, Any)] = new ArrayStack[(String, Any)]()
    
    for(file <- new File("/home/boese/grand_prize/download/training_set/").listFiles){
    	var intuple:(String, Any) = (file.getAbsolutePath,"")
    	input2.push(intuple)
    }
    
    val input:Array[(Any, Any)] = input2.toArray.asInstanceOf[Array[(Any, Any)]]
    val conf = new JobConf
    conf.set("mrstreamer.statsLogFile", "olap-stats.log")
    
    val className = netflix.getClass.getCanonicalName
    
    conf.set("mrstreamer.mapAlgorithm", className)
    conf.set("mrstreamer.reduceAlgorithm", className)
    conf.set("mrstreamer.collectorAlgorithm", netflixCol.getClass.getCanonicalName)
    conf.set("mrstreamer.statThresholdStep", "100.0")
    
    conf.set("mrstreamer.mapCollectorBufferSize","10")
    
    val mr = new MRStreamer(conf, input)
    mr.run
    
  }
  
  
}
