/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms;

import streaming.Collector
import collection.mutable.ListBuffer
import org.apache.hadoop.conf.Configuration

/**
 * Interface for implementing a map-reduce streaming algorithm.
 */

trait MRClass {

  /**
   * Method to setup an inner state of the algorithms with usage of the environment parameters.
   *
   * @param env
   */
  def init(conf: Configuration)

  /**
   * Method to execute on each input key-value pair.
   * Results have to be transferred to the collector.
   *
   * @param key
   * @param value
   * @param collector
   */
  def map(key: Any, value: Any, collector: Collector)

  /**
   * Method to execute on the results of the map step.
   * Results have to be transferred to the collector.
   *
   * @param key
   * @param values
   * @param collector
   */
  def reduce(key: Any, values: ListBuffer[Any], collector: Collector)
}
