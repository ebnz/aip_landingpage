/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.nb;

import org.apache.hadoop.mapreduce.MRJobConfig
import org.apache.hadoop.mapred.JobContext
import akka.actor.Actor
import util.ScalaIO
import eval.{ResultStore, ResultSummary}
import algorithms.MRClass
import streaming._
import map.Combiner
import collection.mutable.{ListBuffer, HashMap}
import org.apache.hadoop.conf.Configuration

/**
 * @author Mikael Högqvist
 * @date 14.10.2009 10:12:32
 * @description Implements the training of a Naive Bayes classifier
 *
 * A map take a file with training data as input. This file contains a set
 * of rows, where each row represents a training data entry. The rows are
 * formatted as a comma-separated string, with the class value last. The first
 * row in the file contains the column names (attributes). Example training file:
 *
 * age,student,buys computer
 * 1,0,0
 * 1,1,0
 * 2,1,1
 * 3,1,1
 * 2,0,1
 *
 * Naive Bayes can be implemented by keeping track of the number of
 * occurrences for each unique "label" of an attribute. The model being
 * trained is represented as a set of table (one per attribute). Each
 * table has the attribute labels on the x-axis and the class labels
 * on the y-axis. I.e this is the conditional probabilities
 * P(X_i = y, C_i = c) and the prior probability of the class, P(C_i = c).
 *
 * Using these two tables, we can classify an input vector, V, with the
 * following formula:
 * max_{i=1}^{|C|}(\prod_{k=1}^{|X|}(P(X_k = V_k|C_i)*P(C_i)))
 * That is, the class with the maximum probability.
 * 
 */

case class LabelPair(label:String, value:Int)
case class TestVector(labelPairs:List[LabelPair], spamOrHam:Int)

case class AccuracyReq(testVector:TestVector)
case class AccuracyResp()
case class AddClass(theKey:String, value:Int)
case class AddOccSum(theKey:String, value:Int)
case class AddOccProb(theKey:String, value:Int)

class NBModelWorker extends Actor {
  def receive = {
    case ev =>
  }
}

class NBModel() extends ScalaIO {
  var occProb:HashMap[String, Int] = new HashMap[String, Int]
  var classes:HashMap[String, Int] = new HashMap[String, Int]
  var occSum:HashMap[String, Int] = new HashMap[String, Int]
  var testDataPath:String = ""
  var testVectors = List[TestVector]()
  var classesSum:Int = 0

  def addClass(theKey:String, classValue:Int) {
	 classesSum += classValue
	 classes += theKey -> (classes.getOrElse(theKey, 0) + classValue.asInstanceOf[Int])
  }

  def addOccSum(theKey:String, value:Int) {
	 occSum += theKey -> (occSum.getOrElse(theKey, 0) + value)
  }

  def addOccProb(theKey:String, value:Int) {
	 occProb += theKey -> (occProb.getOrElse(theKey, 0) + value)
  }

  def initTestData(path:String) {
	 forFileLines(path) { line =>
		val tokens:Array[String] = line.trim.split(",")
							  
		val spamOrHam:Int = 
		  try {
			 tokens.last.toInt
		  } catch {
			 case e: Exception => 0
		  }

		// get list of pairs (feature/label, val)
      val labelPairs:List[LabelPair] = tokens.slice(0, tokens.size-1).toList.map { labelPair =>
		  val pair = labelPair.split(":")
		  try {
			 LabelPair(pair(0), pair(1).toInt)
		  } catch {
			 case e: Exception =>
				LabelPair(pair(0), 0)
		  }
		}
      testVectors = TestVector(labelPairs, spamOrHam) :: testVectors
	 }
  }

  def classify(testVector:TestVector):Int = {
	 var maxProb:Double = 0.0
	 var theClass:Int = 0 // intially we are spam

	 if(testVector.labelPairs.size <= 0)
		return theClass

	 for (classLabel <- classes.keys) {
		val classOcc:Int = classes.get(classLabel).get
		// P(C_i = class label)
		val P_class = (classOcc.toDouble/classesSum)

		val probs = testVector.labelPairs.map { labelPair =>
		  val occ:Int = occProb.getOrElse(classLabel + ":" + labelPair.label + ":" + labelPair.value, 0)
		  val sumOfOcc:Int = occSum.getOrElse(classLabel + ":" + labelPair.label, 0)

		  (occ.toDouble/sumOfOcc.toDouble) 
		}
		
		/* create the product of all values and check if this prob.
		 * is bigger than any previous
		 */
		val product = probs.reduceLeft[Double] { (acc, prob) => acc * prob }
		// bayes posterier probability
		val resProb = product * P_class

		if(resProb > maxProb) {
		  theClass = classLabel.toInt
		  maxProb = resProb
		}
	 }

	 theClass
  }

  def accuracy:Double = {
	 var total:Int = 0
	 var correct:Int = 0

	 // go over each test vector and check if the model
    // can classify correctly as spam or ham
	 for(testVector <- testVectors) {
		if(classify(testVector) == testVector.spamOrHam)
		  correct += 1
		total += 1
	 }

	 correct.toDouble/total
  }
}

class NaiveBayesCombiner extends Combiner {

  override def init(conf:Configuration) {}

  override def reduce(key: Any, values: ListBuffer[Any], collector: Collector) {
    var value: Int = 0
    values.foreach { v => value += v.asInstanceOf[Int] }

    collector.collect(key, value)
  }
}

class NaiveBayes extends MRClass with ScalaIO {

  var bufferMap:Map[Any, Int] = Map.empty

  override def init(conf:Configuration) {
  }

  /**
	* Given an input file with training data, outputs a key = (attribute name, label)
	* and value = 1 (for counting occurrences) for all entries of the training data.
	*/
  def map(key: Any, value: Any, resultCollector: Collector) {
	 var attrIndex:Int = 0
//	 var lineCount = 0
	 var byteCount = 0
  
	 println("Start processing file: " + key)

	 // data format for NB compatible files is:
	 // <attribute index>:<token value>,...,<class label>
	 forFileLines(key.asInstanceOf[String]) { line =>
		val tokens:Array[String] = line.trim.split(",")
		val classLabel:String = tokens.last
								 
		//attrIndex = 0
		
		// keys are composed by class label : attribute label : attribute index
		// class keys are class label : _ : _, where _ indicates a null value since 
		// they are not necessary

		byteCount += line.getBytes.length
		
		for (token <- tokens.slice(0, tokens.size-1)) {
		  val entry:Array[String] = token.trim.split(":")
		  val attrIndex:String = entry(0)
		  val tokenVal:String = entry(1)
		  /* occurrences of c_i = class, y = attr. val and attr. index */
		  resultCollector.collect(classLabel + ":" + attrIndex + ":" + tokenVal, 1.asInstanceOf[AnyRef])
		  /* sum of occurrences for c_i = class and attr. index */
		  resultCollector.collect(classLabel + ":" + attrIndex + "\n", 1.asInstanceOf[AnyRef])
		  //attrIndex += 1
		}

		/* occurrences of the class label */
		resultCollector.collect(classLabel + "\t" , 1.asInstanceOf[AnyRef])
		// lineCount += 1
	 }

	 println("Finished processing file: " + key + " with bytes: " + byteCount)
  }

  /**
	* Aggregates the occurrences registered in the map for a specific key.
	* This value is forwarded to the collector which merges the occurrences
	* with into the complete model.
	*/

  def reduce(key:Any, values: ListBuffer[Any], resultCollector: Collector) {
	  values.foreach{ value => resultCollector.collect(key, value) }
  }
}

class NaiveBayesDummyCollector extends Collector with ScalaIO with ResultStore {

  override def init (conf: Configuration) {
  }

  def collect(key:Any, value: Any){
  }

  def thresholdExceeded(prog:Long) {
    val rs = new NaiveBayesResultSummary()
	 rs.set(1.0)
	 println("Dummy: " + prog)

    append(prog, rs, None)
  }

  def finished(success:Boolean) {
  }
}

class NaiveBayesCollector extends Collector with ScalaIO with ResultStore {
  protected val model:NBModel = new NBModel()
  protected var sumCollected:Int = 0
  protected var lines:Int = 1
  var statThresholdStep = 0.1
  var nextStatThreshold = statThresholdStep

  var numReducers = 0
  var reducerProgress:Array[Int] = null
  var THRESHOLD = 1000
  var conf: Configuration = null

  override def init (conf: Configuration) {
	 this.conf = conf
	 this.model.initTestData(conf.get("testPath"))
	 numReducers = conf.getInt(MRJobConfig.NUM_REDUCES, 1)
	 statThresholdStep = conf.getFloat("statThresholdStep", 1000)
	 reducerProgress = new Array[Int](numReducers)
  }

  /**
	* the collect function receives a key representing a label
	* and a count for that label
	*
	*/
  def collect(k:Any, value: Any){
	  val key: String = k.asInstanceOf[String]
    if(key.endsWith("\t")) {
		val theKey = key.trim
		model.addClass(theKey, value.asInstanceOf[Int])
		//model.classes += theKey -> (model.classes.getOrElse(theKey, 0) + value.asInstanceOf[Int])
	 } else if(key.endsWith("\n")) {
		val theKey = key.trim
		model.addOccSum(theKey, value.asInstanceOf[Int])
//		model.occSum += theKey -> (model.occSum.getOrElse(theKey, 0) + value.asInstanceOf[Int])
	 } else {
		model.addOccProb(key, value.asInstanceOf[Int])
//		model.occProb += key -> (model.occProb.getOrElse(key, 0) + value.asInstanceOf[Int])
	 }

	 sumCollected += 1
  }

  /*
	* progress threshold was triggered, store statistics
	*/
  override def thresholdExceeded(prog:Long) {
    val rs = new NaiveBayesResultSummary()
	 rs.set(model.accuracy)
	 println("NB bytes produced: " + prog + ", " + model.accuracy)
    append(prog, rs, None)
  }

  def finished(success:Boolean) {
    val rs = new NaiveBayesResultSummary()
    rs.set(model.accuracy)
    append(0L, rs, None)
	 emitAllResults()
  }
}

class NaiveBayesResultSummary extends ResultSummary {
  protected var accuracy:Double = -1.0

  def set(summaryVal:Any) {
	 accuracy = summaryVal.asInstanceOf[Double]
  }
 
  def dif(summaryA:ResultSummary, summaryB:ResultSummary):Double = {
    val sa:Double = summaryA.asInstanceOf[NaiveBayesResultSummary].accuracy
    val sb:Double = summaryB.asInstanceOf[NaiveBayesResultSummary].accuracy

	 // compare the accuracy of the two models
	 math.abs(sb - sa)
  }

  def getAccuracy:Double = accuracy

  override def toString:String = {
	 accuracy.toString
  }
}
