/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.matrix


import util.{Counter, ScalaIO}
import algorithms.MRClass
import streaming.Collector
import collection.mutable.ListBuffer
import org.apache.hadoop.conf.Configuration

/**
 * @author  Artur Andrzejak
 * @date: 08.10.2009 - 11:41:17
 * @description: Implements multi-threaded matrix sums computation as a building block for
 * @description: Principal Component Analysis (PCA) and Linear Regression algorithm (LinReg)
 * @description: Details: Each line is assumed to have lineLen = dim+1 numbers. The first dim numbers per line
 * @description: define the matrix X, and the last number (column dim+1) creates a vector y (over all lines).
 * @description: Then we compute:
 * @description: the matrix A = (X'*X) (a dim-by-dim matrix) as A_TYPE result, and
 * @description: B = sum of rows of X (a 1-by-dim vector) as B_TYPE result. If scale_Bsum_by_last_column == true,
 * @description: then B = X'*y (i.e. each row of X is weighted by the y-value of this row).
 */



object MatrixSumsMR  {
  val A_TYPE = "A-type"
  val B_TYPE = "B-type"
  val separator = " +"
}

class MatrixSumsMR  extends MRClass with ScalaIO with Counter {
  // val A_TYPE = "A-type";
  // val B_TYPE = "B-type";
  // val separator = " +"; // two(!) spaces for matlab, or " -" for negative numbers

  //===== settings from properties/environment =====
  // configuration + environment
  protected var conf:Configuration = null
  // number of numeric data per line
  protected var lineLen = 5
  // if true, scale each vector added for B_TYPE result by the last column => for linReg
  protected var scale_Bsum_by_last_column = false

  //===== internal working variables =====
  // intermediate reduce result
  protected var reduceResult:MatrixAcc = null
  // for checking, whether each instance has "own" reduce key
  protected var reducerKey:String  = null


  override def init(conf:Configuration) {
		this.conf = conf
    setCounterThreshold( conf.getInt("matrixSumsMR.numComputationsToCollect", 20) )
    lineLen = conf.getInt("matrixSumsMR.lineLen", 5)
    scale_Bsum_by_last_column = conf.getBoolean("matrixSumsMR.scale_Bsum_by_last_column", true)
	}


  def map(fileName: Any,  inputValueObj: Any,  resultCollector: Collector)  {

    printf("\nStarting LinReg or PCA map step for file %s%n", fileName)

    val dim = lineLen-1
    // prepare data structures for computation
    // for matrix A = X'*X
    var accA = new MatrixAccJama()
    accA.reset(dim,dim)
    // for mean values
    var accB = new MatrixAccJama()
    accB.reset(dim, 1)

    val lineData = new Array[Double](lineLen)

    var bytesNum:Int = 1
    forFileLines(fileName.asInstanceOf[String]) { line =>
      parseDoubles(line, lineData, MatrixSumsMR.separator)
      bytesNum += line.getBytes.length
      // a line has dim entries for the x_i and scalar y_i as last entry
      accA.addMatrixFromVec(lineData, dim)

      val bSum_scale:Double = if (scale_Bsum_by_last_column) lineData(dim) else 1.0
      accB.addScaledVec(lineData, dim, bSum_scale)

      if (isCounterThresholdReached) {
          // todo: in collect(.., lineNum), lineNum is dropped - how to pass it to reducer?
          // todo: also pass jobId!
          resultCollector.collect(MatrixSumsMR.A_TYPE, accA)
          resultCollector.collect(MatrixSumsMR.B_TYPE, accB)
          // we have to create new objects because we have sent the references to reducer..
          accA = new MatrixAccJama()
          accA.reset(dim,dim)
          // for mean values
          accB = new MatrixAccJama();
          accB.reset(dim, 1);
      }
    }
  }


  def reduce(key: Any, submatrix: ListBuffer[Any], resultCollector:Collector)  {

    // actually, we just need to add up the matrices (disregarding the type)
    reducerKey = if (reducerKey == null) key.asInstanceOf[String] else reducerKey
    // todo: is there a nices idiom in Scala? How to avoid null? -> try the Some and Any constructs
    require (reducerKey.equals(key))  // check that we got into data with same key as the very first one 

    val value:MatrixAcc  =  submatrix.head.asInstanceOf[MatrixAcc]
    if (reduceResult == null) {
        reduceResult = value
    } else {
        reduceResult.accumulate(value)
    }
    resultCollector.collect(key, reduceResult)
  }
}
