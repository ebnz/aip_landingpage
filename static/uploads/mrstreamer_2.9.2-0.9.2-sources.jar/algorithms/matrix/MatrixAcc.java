/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.matrix;

import Jama.Matrix;

/**
 * @author Artur Andrzejak
 * @date: 11.05.2009 - 15:00:21
 * @description: Provides methods for (MR-style) computations
 * @description: and accumulation of matrices/vectors for linear regression
 */
public interface MatrixAcc {

    /**
     * Resets internal data structure and specifies new dimentions
     * @param numRows num of rows of the internal data structure
     * @param numColumns num of cols of the internal data structure
     */
    void reset(int numRows, int numColumns);


    /** Makes a deep copy of this object */
    public MatrixAccJama copy();


    /** Sets all accumulator values to initValue */
    void setAll(double initValue);

    
    /**
     * Computes a matrix M = v'*v for a row vector v (d elements
     * and adds it to the (internal) matrix
     * @param inVec input vector as an array
     * @param numEntriesToUse num. of first entries of inVec to be used
     */
    void addMatrixFromVec(double[] inVec, int numEntriesToUse);

    /**
     * Scales the inVect
     * @param inVec input vector as an array
     * @param numEntriesToUse num. of first entries of inVec to be used
     * @param factor factor by which the vector is to be multiplied prior to accumulation
     */
    void addScaledVec(double[] inVec, int numEntriesToUse, double factor);

    /** Adds to this accumulator another matrix / vector of same size
     * For the reduce step
     * @param other another matrix / vector to be added to this data
     */
    void accumulate(MatrixAcc other);


    /**
     * Uses this data as A (X'*X) and a parameter for solving the system
     * @param bResult the "right-hand-side", i.e. b= X'y
     * @return beta, the solution of A*b
     */
    double[] solve(MatrixAcc bResult);

    public Matrix getData();

    public int getNumAdditions();

    /** Computes the average of all matrix additions or accumulations
     * by using the internal counter of add / accumulate ops **/
    public void mean();


}