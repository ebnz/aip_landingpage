/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.matrix;

import Jama.Matrix;

/**
 * @author Artur Andrzejak
 * @date: 11.05.2009 - 16:05:05
 * @description:
 * @description:
 */
public class MatrixAccJama implements MatrixAcc {

    protected Matrix data;
    protected int numRows, numColumns;
    // number of performed additions since last reset
    protected int numAdditions = 0;

    public void reset(int numRows, int numColumns) {
        data = new Matrix(numRows, numColumns, 0.0);
        this.numColumns = numColumns;
        this.numRows = numRows;
        numAdditions = 0;
    }

    /** Makes a deep copy of this object */
    public MatrixAccJama copy() {
        MatrixAccJama result = new MatrixAccJama();
        result.data = this.data.copy();
        result.numRows = this.numRows;
        result.numColumns = this.numColumns;
        result.numAdditions = this.numAdditions;

        return result;
    }

    
    /** Sets all accumulator values to initValue */
    public void setAll(double initValue) {
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numColumns; col++) {
                data.set(row, col, initValue);
            }
        }
    }

    public void addMatrixFromVec(double[] inVec, int numEntriesToUse) {
        double summand, previous;
        numAdditions++;
        for (int row = 0; row < numEntriesToUse; row++) {
            double first = inVec[row];
            for (int col = 0; col < numEntriesToUse; col++) {
                summand = first*inVec[col];
                // add to matrix
                previous = data.get(row, col);
                data.set (row, col, previous + summand);
            }
        }
    }

    public void addScaledVec(double[] inVec, int numEntriesToUse, double factor) {
        double previous, summand;
        numAdditions++;
        for (int row = 0; row < numEntriesToUse; row++) {
            previous = data.get(row, 0);
            summand = inVec[row]*factor;
            data.set(row, 0, previous + summand );
        }

    }

    public void accumulate(MatrixAcc other) {
        data = data.plus(other.getData());
        numAdditions += other.getNumAdditions();
    }

    public double[] solve(MatrixAcc bResult) {

        Matrix inverse = data.inverse();
        // multiply
        Matrix result = inverse.times(bResult.getData());
        double[][] res2d = result.getArray();
        int numRows = result.getRowDimension();
        double[] resArray = new double[numRows];
        for (int i = 0; i < numRows; i++) {
            resArray[i] = res2d[i][0];
        }
        return resArray;
    }

    public Matrix getData() {
        return data;
    }

    public int getNumAdditions() {
        return numAdditions;
    }


    public void mean() {
        if (numAdditions > 0) {
            data = data.times(1.0/numAdditions);
            numAdditions = 0;
        }
    }


}