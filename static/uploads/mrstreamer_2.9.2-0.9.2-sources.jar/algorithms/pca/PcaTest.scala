/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.pca

import org.apache.hadoop.mapred.JobConf


import streaming.MRStreamer
import algorithms.matrix.MatrixSumsMR

/**
 * @author  Artur Andrzejak
 * @date: 13.10.2009 - 19:54:52
 * @description: Test object for the PCA algorithm using MatrixSumsMR()
 * @description: 
 */

object PcaTest {
  def main(args: Array[String])  {

    val file1:(Any, Any) = ("testdata/linreg/pcaData-1.txt", "")
    val file2:(Any, Any) = ("testdata/linreg/pcaData-2.txt", "")
    val input = Array(file1, file2)
        val conf = new JobConf
    conf.set("mrstreamer.statsLogFile", "pca-final-result.log")
    conf.set("mrstreamer.resultFile", "pca-Results.log")

    val pca = new MatrixSumsMR()
     // isn't it just "algorithms.matrix.MatrixSumsMR" ?
    val className = pca.getClass.getCanonicalName

    val collectorClassName = "algorithms.pca.PcaCollector"
    conf.set("pca.resultRecomputationInterval", "5")

    // M-R framework settings
    conf.set("mrstreamer.mapAlgorithm", className)
    conf.set("mrstreamer.reduceAlgorithm", className)
    conf.set("mrstreamer.collectorAlgorithm", collectorClassName)
    conf.set("mrstreamer.mapCollectorBufferSize", "10")
    conf.set("mrstreamer.profile", "false")

    // matrixSumsMR settings
    conf.set("matrixSumsMR.lineLen", "5")
    conf.set("matrixSumsMR.numComputationsToCollect", "20")
    conf.set("matrixSumsMR.scale_Bsum_by_last_column", "false")

    // collector settings
    conf.set("statThresholdStep", "0.005")
    // switches off/on printing of results on the screen in collector
    conf.set("printResultsOnScreen", "false") 

   
    val mr = new MRStreamer(conf, input)
    mr.run

  }
}
