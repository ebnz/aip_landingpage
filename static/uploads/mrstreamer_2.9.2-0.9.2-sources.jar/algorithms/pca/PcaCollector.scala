/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.pca

import org.apache.hadoop.conf.Configuration


import eval.{VectorResultSummary, ResultStore}
import streaming.Collector
import util.Counter
import algorithms.matrix.{MatrixSumsMR, MatrixAccJama, MatrixAcc}

/**
 * @author Artur Andrzejak
 * @date: 13.10.2009 - 20:13:33
 * @description: Reducer collector for the PCA algorithm
 * @description:
 * todo : generalize to substitute LinRegCollectorScala as a case of this code
 *
 * From: Jon Shlens, A TUTORIAL ON PRINCIPAL COMPONENT ANALYSIS, 25 March 2003
 * In practice computing PCA of a data set X entails (1) subtracting off the mean of each measurement type
   and (2) computing the eigenvectors of XX'
 **/

class PcaCollector extends Collector with Counter with ResultStore {

  //===== settings from properties/environment =====
  // configuration + environment
  protected var conf: Configuration = null
  protected var printResultsOnScreen: Boolean = false

  //===== internal working variables =====
  protected var lastDataA: MatrixAcc = null
  protected var lastDataB: MatrixAcc = null
  protected var output = new StringBuffer(150)
  protected var totalCountA: Int = 0
  protected var totalCountB: Int = 0
  protected var result: Array[Double] = null

  // for reporting progress to the framework
  protected var progressFraction:Float = 0
  

  override def init(conf: Configuration) {
    this.conf = conf
    setCounterThreshold(conf.getInt("pca.resultRecomputationInterval", 5))
    printResultsOnScreen = conf.getBoolean("printResultsOnScreen", true)
  }

  def finished(success: Boolean) {
    // ============ Using ResultStore trait for off-line "convergence graph"  =========

    /*
        // Just get what ResultStore has ..
        val (progresses, differences) = getProgsAndDiffs()

        // reset output buffer
        output.setLength(0)

        // create "unformatted" ouput and print it
        toStringBuffer(progresses, differences, output)
        print(output)

        // emit the results to Environment
        emitResults(progresses, differences, conf)
    */
    emitAllResults()

  }

  //  def collect (resultKey:String,  resultValue:Object) {
  //    collect(resultKey, resultValue, 0)
  //  }

  /**Optional call to allow the reducer to state the number of inputs which
   *  have contributed to this result
   *  In PCA:
   *   lastDataA is the sum of matrices M_row, each obtained as a (vector) self-multiplication of a row vector v_row
   *   of first dim entries in data line with index row (last entry of data line is skipped), i.e.
   *   M_row = v_row * v_row' (gives dim-by-dim matrix)
   *   lastDataB is simply the sum of row vectors v_row (with only first dim entries in data line)
   */
  def collect(resultKey: Any, resultValue: Any) {

    if (resultKey.equals(MatrixSumsMR.A_TYPE)) {
      lastDataA = resultValue.asInstanceOf[MatrixAcc]
      totalCountA += 1
    } else if (resultKey.equals(MatrixSumsMR.B_TYPE)) {
      lastDataB = resultValue.asInstanceOf[MatrixAcc]
      totalCountB += 1
    }

    if (!isCounterThresholdReached) return
    if (totalCountA == 0 || totalCountB == 0) return

    // ***** Doing the main algorithm work here ******
    // This should compute the eigenvectors + eigenval of the covariance matrix

    // First, get the covariance matrix
    // 1. Divide the sum of matrices by the number matrix summations (rows which went into lastDataA)
    val matrixSum:MatrixAccJama = lastDataA.copy
    matrixSum.mean()

    // 2. Compute mean for each colum - just divide sum of added data vectors by their number
    val vectorSum:MatrixAccJama = lastDataB.copy
    vectorSum.mean()

    // 3. Compute C = mu*mu'
    val mu = vectorSum.getData
    val muTransposed  = mu.transpose
    val C = mu.times(muTransposed)
    // 4. Compute covm = mean(A) - C  // this is the covariance matrix
    val covm = matrixSum.getData.minus(C)


    // Compute the eigenvecs of covm
    val eigenvalDecomp = covm.eig
    // What is the final result? Eigenvecs: too much data, so eigenvals?
    val eigenvectors = eigenvalDecomp.getV
    val eigenvals = eigenvalDecomp.getRealEigenvalues

    result = eigenvals // todo: verify whether this makes sense as a result & and cut to first k

    if (java.lang.Double.isNaN(result(0))) {
      print("NaN in a result - sth went wrong!\n");
    }

    if (printResultsOnScreen) {
      // A "debug" progress info
      output.setLength(0) // reset output buffer
      output.append(", countA= ").append(totalCountA)
      output.append(", countB= ").append(totalCountB).append("; res = ")
      for (aResult <- result) {
        output.append(aResult)
        output.append(' ')
      }
      output.append('\n')
      print(output)
    }

    // ============ Using ResultSummary / ResultStore starts here =========

    // 1. compute progress
    //    val progress = reducerInfo.calcprogress()
    // todo: make progress dependent on min from progress-for-A, progress-for-B
    // val progressFraction = Math.min(totalCountA/maxNumLines, totalCountB/maxNumLines)

    // 2. append progress+result to ResultStore
    //createAndAppend("eval.VectorResultSummary", progress.toFloat, result, null )
  }

  override def thresholdExceeded(prog: Long) {
    createAndAppend("eval.VectorResultSummary", prog, result, null)
  }

}
