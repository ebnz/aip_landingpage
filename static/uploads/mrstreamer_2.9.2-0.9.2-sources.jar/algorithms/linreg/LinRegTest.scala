/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.linreg

import org.apache.hadoop.mapred.JobConf


import org.apache.hadoop.conf.Configuration


import streaming.MRStreamer
import algorithms.matrix.MatrixSumsMR
import akka.actor.Actor._
import org.apache.hadoop.io.UTF8

/**
 * @author  Artur Andrzejak
 * @date: 13.10.2009 - 19:54:52
 * @description: Test object for the LinRegression algorithm using MatrixSumsMR()
 * @description: 
 */

object LinRegTest {
  def main(args: Array[String])  {

    val basePath:String = "testdata/linreg/"
    val file1 = (basePath + "linRegData-1.txt", new UTF8)
    val file2 = (basePath + "linRegData-2.txt", new UTF8)
    val input: Array[(Any,Any)] = Array(file1, file2)
    val conf = new JobConf();
    conf.set("mrstreamer.statsLogFile", "linReg-final-result.log")
    conf.set("mrstreamer.resultFile", "linReg-Results.log")

    val pca = new MatrixSumsMR()
     // isn't it just "algorithms.matrix.MatrixSumsMR" ?
    val className = pca.getClass.getCanonicalName

    val collectorClassName = "algorithms.linreg.LinRegCollectorScala"
    conf.set("resultRecomputationInterval", "1")

    // M-R framework settings
    conf.set("mrstreamer.statsPath", basePath)
    conf.set("mrstreamer.statThresholdStep", "0.005")
    conf.set("mrstreamer.mapAlgorithm", className)
    conf.set("mrstreamer.reduceAlgorithm", className)
    conf.set("mrstreamer.collectorAlgorithm", collectorClassName)
    conf.set("mrstreamer.mapCollectorBufferSize", "10")
    conf.set("mrstreamer.profile", "false")

    // matrixSumsMR settings
    conf.set("matrixSumsMR.lineLen", "5")
    conf.set("matrixSumsMR.numComputationsToCollect", "20")
    conf.set("matrixSumsMR.scale_Bsum_by_last_column", "true")
    
    // switches off/on printing of results on the screen in collector
    conf.set("printResultsOnScreen", "false")

    // distributed calculation
    conf.set("mrstreamer.distributed", "false")

    val mr: MRStreamer = new MRStreamer (conf, input)
    mr.run

    println("all finished!")
  }
}
