/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.wc

import eval.ResultSummary;
import scala.collection.mutable.HashMap

class WordCountResultSummary extends ResultSummary{

  protected var histogram:Map[Any, Int] = Map.empty
  
  def set(resultSummaryValue:Any) {
    // we expect to get a double[] vector as an argument
    histogram = resultSummaryValue.asInstanceOf[Map[Any, Int]]
  }
  
  override def toString:String = {
	 val str = new StringBuffer()
	 histogram.iterator.foreach{elem =>
	 	str.append(elem._1+":"+elem._2+"\n")
	 }
	 str.toString
  }
  
  
  // counts total number of words in the histogram, (seems to be redundant !!!)
  def countotalWords(map:Map[Any, Int]):Int = {
    var r:Int = 0
    map.foreach{ entry:(Any, Int) => {
    	r+=entry._2
     }
    }
    r
  }
  
  
  // relative error for a single word only
  def dif1 (summaryA:ResultSummary, summaryB:ResultSummary):Double = {
    
    val key:String = "name"
    
    val sa:Map[Any, Int] = summaryA.asInstanceOf[WordCountResultSummary].histogram
    val sb:Map[Any, Int] = summaryB.asInstanceOf[WordCountResultSummary].histogram
    
    var error:Double = 0
    var ca = sa.getOrElse(key, 0).asInstanceOf[Double]    
    error =  (ca / countotalWords(sa)) -  (sb.getOrElse(key,0).asInstanceOf[Double] / countotalWords(sb)) 
    
    math.sqrt(math.pow(error,2))
  }
  
  
  
  def dif2 (summaryA:ResultSummary, summaryB:ResultSummary):Double = {
    
    val sa:Map[Any, Int] = summaryA.asInstanceOf[WordCountResultSummary].histogram
    val sb:Map[Any, Int] = summaryB.asInstanceOf[WordCountResultSummary].histogram
  
    var result:Double = 0
    
    var totB =  countotalWords(sb)
    var totA =  countotalWords(sa)
    var esum:Double  = 0
    
    sb.foreach{ entry:(Any, Int) =>
      
      var diff:Double = 0
      
     // check if key exists in smaller map     
     if(sa.contains(entry._1)){
        var countA = sa.get(entry._1)
        var cA = countA.getOrElse(0)
        //countA match{ case Some(ca) => cA = ca }
        diff = cA.asInstanceOf[Double] / totB.asInstanceOf[Double] - entry._2.asInstanceOf[Double] / totB.asInstanceOf[Double]
      }else{
        diff = entry._2.asInstanceOf[Double] / totB.asInstanceOf[Double]
      }
      
      esum = esum + math.pow(diff,2)
      }
    math.sqrt(esum / sb.size)
  
  }
  
  
  
  var sizeA:Int = 0
  var totwA:Int = 0
  
  
  
  // computes the rooted mean square error
  def dif(summaryA:ResultSummary, summaryB:ResultSummary):Double = {
    
    val sa:Map[Any, Int] = summaryA.asInstanceOf[WordCountResultSummary].histogram
    val sb:Map[Any, Int] = summaryB.asInstanceOf[WordCountResultSummary].histogram
    
 //   println("A:"+sa.size+" B:"+sb.size)
    
   if(sizeA > sa.size){
     println("Error: decreasing size of map")
   }else{
     sizeA = sa.size
   }
   
   if(totwA > countotalWords(sa)){
     println("Error: decreasing number of total words")
   }else{
     totwA = countotalWords(sa)
   }
   
     
    // bigger histogram (with more words)
    var bigger:Map[Any, Int] = null
    var smaller:Map[Any, Int] = null
    
    var s_tot:Int = 0
    var b_tot:Int = 0
    
    if (sa.size >= sb.size){
      bigger = sa
      smaller = sb
    }else{
      bigger = sb
      smaller = sa
    }
    
    var tot_big = countotalWords(bigger)
    var tot_sma = countotalWords(smaller)
    
    var result:Double = 0.0f
    var errorsum:Double = 0.0f
    
    bigger.foreach{ entry:(Any, Int) => {
    	var key:String = entry._1.toString
    	var cb:Int = entry._2
     	var differenz:Float = 0
     	var ca = smaller.get(key)
      
    	ca match{
    	  case None => {
    	    // word was does not exist in the smaller histogram
    	     differenz = (cb.asInstanceOf[Float] / tot_big.asInstanceOf[Float])
          //  differenz = cb.asInstanceOf[Float]
    	    }
          case Some(a) => {
    	    // word exists in both histograms 
    	    differenz = (cb.asInstanceOf[Float] / tot_big.asInstanceOf[Float])  - (a.asInstanceOf[Float] / tot_sma.asInstanceOf[Float])
           // differenz = (cb.asInstanceOf[Float])  - (a.asInstanceOf[Float])
            }
    	} // match
        errorsum = errorsum + differenz * differenz 
      }
    } // foreach             
    result = math.sqrt(errorsum / bigger.size)                  
    result
  }

  
}
