/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.wc

import org.apache.hadoop.mapred.JobConf
import streaming.MRStreamer
import java.net.InetSocketAddress
import org.apache.hadoop.mapreduce.MRJobConfig

object RelWCTest {
  
          val conf = new JobConf
    //conf.set("mrstreamer.statsLogFile", "stats.log")
    conf.set("mrstreamer.resultFile", "wc.log")

  
  def main(args: Array[String]){
    runWC()
  }
  
  def runWC(){
    val wc = new RelWC()
    val classN:String = wc.getClass.getCanonicalName

    conf.set("mrstreamer.statsPath", "./testdata/wordcount/")
    conf.set("mrstreamer.statThresholdStep", "" + 512 * 1024)
    conf.set("mrstreamer.throughputMeasurementPeriod", "1000")
    conf.set("mrstreamer.profile","false")
    conf.set("mrstreamer.mapAlgorithm", classN)
    conf.set("mrstreamer.reduceAlgorithm", classN)
    conf.set("mrstreamer.combineAlgorithm", classOf[RelWCCombiner].getCanonicalName)
    conf.set("mrstreamer.collectorAlgorithm", classOf[RelativeWordCountCollector].getCanonicalName)
 
    conf.set("mrstreamer.mapCollectorBufferSize","100")
    conf.set("mrstreamer.reduceCollectorBufferSize","100")
	 
    val input:Array[(Any, Any)] = new Array[(Any, Any)](3)
    input(0) = ("./testdata/wordcount/test/test_data1.txt", "")
    input(1) = ("./testdata/wordcount/test/wc1.txt", "")
    input(2) = ("./testdata/wordcount/test/wc2.txt", "")
    //input(3) = ("./testdata/wordcount/test/wc3.txt", "")
    //input(4) = ("./testdata/wordcount/test/shakespearetest.txt", "")

    // setting the input-types
    conf.set("mrstreamer.map.input.key.class", "org.apache.hadoop.io.UTF8")
    conf.set("mrstreamer.map.input.value.class", "org.apache.hadoop.io.IntWritable")
    conf.set(MRJobConfig.MAP_OUTPUT_KEY_CLASS, "org.apache.hadoop.io.UTF8")
    conf.set(MRJobConfig.MAP_OUTPUT_VALUE_CLASS, "org.apache.hadoop.io.IntWritable")
    conf.set(MRJobConfig.OUTPUT_KEY_CLASS, "org.apache.hadoop.io.UTF8")
    conf.set(MRJobConfig.OUTPUT_VALUE_CLASS, "org.apache.hadoop.io.IntWritable")

    // distributed calculation
    conf.setBoolean("mrstreamer.distributed",true)
    
    conf.setNumMapTasks(4);

	  val mr: MRStreamer = new MRStreamer (conf, input)
    mr.run

    println("\nall finished!")
    System.exit(0)
  }
}
