/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.wc

import streaming._
import org.apache.lucene.analysis.{ SimpleAnalyzer, Token, TokenStream }
import java.io.StringReader
import algorithms.MRClass
import org.apache.hadoop.io.{ IntWritable, UTF8 }
import collection.mutable.ListBuffer
import org.apache.hadoop.conf.Configuration

class RelWC extends MRClass {

  override def init(conf: Configuration) {}

  def map(k: Any, value: Any, resultCollector: Collector) {

    val line: String = value.toString

    // b counts the bytes processed so far
    val b: Long = line.getBytes.length

    val analyzer: SimpleAnalyzer = new SimpleAnalyzer

    var tokenStream: TokenStream = analyzer.tokenStream("", new StringReader(line))
    var tok: Token = tokenStream.next
    while (tok != null) {
      resultCollector.collect(new UTF8(tok.termText), new IntWritable(1))
      tok = tokenStream.next
    }
    tokenStream.end()
    tokenStream.close()
  }

  def reduce(key: Any, values: ListBuffer[Any], resultCollector: Collector) {
    values.foreach { value => resultCollector.collect(key, value) }
  }
}
