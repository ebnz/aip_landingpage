/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.wc

import org.apache.hadoop.conf.Configuration
import streaming.Collector
import eval.ResultStore
import org.apache.hadoop.io.{UTF8, IntWritable}
import util.ResultEmitter

/**
 *  Implementation of  relative word count collector
 * 
 *  the collector maintains a histogram of word frequencies and periodically
 *  copies the histogram as intermediate result. 
 * 
 *  the progress is calculated as the cumulative progress of all reducer workers.
 *  
 *  @author Joos
 * 
 */
class RelativeWordCountCollector extends Collector with ResultStore {

  protected var histogram: Map[Any, Int] = Map.empty
  
  protected var totalwords:Int = 0 

  
  override def init(conf: Configuration){
  }
  
  // collects data received from a reduce worker
  def collect(resultKey: Any, resultValue: Any) {
    
    // check whether the word received already exists in the histogram
    val value: Int = resultValue.asInstanceOf[IntWritable].get
    
    histogram += resultKey -> (histogram.getOrElse(resultKey, 0) + value)

    // keep track of the total number of words counted so far
    totalwords += value
  }
  
  def thresholdExceeded(prog:Long) {
      val rs = new WordCountResultSummary()
      var intHistogram: Map[Any, Int] = histogram
      rs.set(intHistogram)
      append(prog, rs, totalwords)
  }

  // in the word count example the finish method is only used to save the final result
  // and initiate calculations for diagrams
  def finished(success:Boolean){
    
    // add final result
    var intHistogram: Map[Any, Int] = histogram
    val rs = new WordCountResultSummary()
    rs.set(intHistogram)
    append(0L, rs, totalwords)
      
	 emitAllResults()

   // print offline conversion graph
/*	 env.get("graphType") match {
		case "offline" => calcOfflineConversion
		case "online" => calcOnlineConversion
	 } */
  }
  
  
  // prints the RMSE between the final result (100% processed) and every intermediate result 
  def calcOfflineConversion(){   
    val (differences, lastIndex) = getDifs(0, -1)  // get the y-axis - values of metric dif
    val (progresses, dummy) = getProgs(lastIndex) // get the x-axis - progresses for each dif computation

    // writing data to result file defined in the environment
    for (row <- 0 to lastIndex) {
       println(progresses(row)+" " +differences(row))
       ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], differences(row).asInstanceOf[Float])
     }
  }
  
  def calcOnlineConversion(){
    val (differences, lastIndex) = getDifs(0,-1)
    val (progresses, dummy) = getProgs(lastIndex)
    
    for(row <- 0 to lastIndex-1){
      var (dif, i) = getDifs(row,row+1)
      println(progresses(row)+" "+dif(0))
      ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], dif(0).asInstanceOf[Float])
    }
    
  }

}
