/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import org.apache.hadoop.conf.Configuration
import streaming.Collector
import eval.ResultStore
import util.{ResultEmitter, ScalaIO}

class KMeansCollector extends Collector with ResultStore {
    
  // centroids
  @volatile
  private var clusters: Clusters = null

  private var progress: Long = 0L
  
  override def init (conf: Configuration) {
  }

  /**
   * KMeans result is updated.
   */
  def collect(key: Any, value: Any) {

    this.clusters = value.asInstanceOf[Clusters]
  }

  def thresholdExceeded(prog: Long){

    this.progress = prog
    val rs =  new KMeansResultSummary()
    rs.set(clusters)

    append(prog, rs, 0)
  }

  def finished(success:Boolean) {

    val rs = new KMeansResultSummary
    rs.set(clusters)
    append(progress, rs, None)
    emitAllResults()
    emitAllIntermediateResults()
  }

  // debug function to print some results
  def printIResults(){
    val (differences, lastIndex) = getDifs(0, -1)  // get the y-axis - values of metric dif
    val (progresses, dummy) = getProgs(lastIndex)
    for (row <- 0 to lastIndex) {
      println(progresses(row))
    }
  }

  // prints the RMSE between the final result (100% processed) and every intermediate result
  def calcOfflineConversion(){
    val (differences, lastIndex) = getDifs(0, -1)  // get the y-axis - values of metric dif
    val (progresses, dummy) = getProgs(lastIndex) // get the x-axis - progresses for each dif computation

    // writing data to result file defined in the environment
    for (row <- 0 to lastIndex) {
      println(progresses(row)+" " +differences(row))
      ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], differences(row).asInstanceOf[Float])
    }
  }

  def calcOnlineConversion(){
    val (differences, lastIndex) = getDifs(0,-1)
    val (progresses, dummy) = getProgs(lastIndex)

    for(row <- 0 to lastIndex-1){
      var (dif, i) = getDifs(row,row+1)
      println(progresses(row)+" "+dif(0))
      ResultEmitter.emitAnalyzerResult(progresses(row).asInstanceOf[Float], dif(0).asInstanceOf[Float])
    }
  }
}