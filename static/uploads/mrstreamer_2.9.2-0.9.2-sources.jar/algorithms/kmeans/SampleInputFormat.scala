/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import org.apache.hadoop.mapred._
//import org.apache.mahout.matrix.DenseVector
import org.apache.mahout.math.{DenseVector, DenseVectorWritable}
import org.apache.hadoop.io.{Text, LongWritable}

/**
 * Input format to define sample input data used by KMeans for example. It depends on the predefined FileInputFormat
 * of Hadoop.
 *
 * User: flangner
 * Date: 27.08.2010
 * Time: 18:05:03
 */

class SampleInputFormat extends FileInputFormat[Sample, Clusters] {

  override def getRecordReader(split : InputSplit, conf : JobConf, reporter: Reporter): RecordReader[Sample, Clusters] = {

    new SampleRecordReader(conf, split.asInstanceOf[FileSplit])
  }
}

/**
 * RecordReader for samples that bases on the predefined LineRecordReader.
 *
 * User: flangner
 * Date: 27.08.2010
 * Time: 18:05:03
 */

class SampleRecordReader(conf: JobConf, split: FileSplit) extends RecordReader[Sample, Clusters] {

  private var lineRecordReader: LineRecordReader = new LineRecordReader(conf, split)

  private val lineKey: LongWritable = this.lineRecordReader.createKey
  private val lineValue: Text = this.lineRecordReader.createValue

  def next(key: Sample, value: Clusters): Boolean = {

    var success: Boolean = this.lineRecordReader.next(lineKey, lineValue)

    if (success) {
      var elements: List[String] = lineValue.toString.split(' ').toList
      var doubleElements: Array[Double] = new Array[Double](elements.size)

      for (i <- 0 until elements.size) {
        doubleElements(i) = elements(i).toDouble
      }
      key.setVector(new DenseVectorWritable(new DenseVector(doubleElements)))
    }

    success
  }

  def getProgress: Float = {
    this.lineRecordReader.getProgress
  }

  def createValue: Clusters = {
    new Clusters
  }

  def createKey: Sample = {
    new Sample
  }

  def getPos: Long = {
    this.lineRecordReader.getPos
  }

  def close() {
    this.lineRecordReader.close()
  }
}
