/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import java.util.Random
import grizzled.slf4j.Logging

//import org.apache.mahout.matrix.DenseVector
import org.apache.mahout.math.DenseVectorWritable

/**
 * Approximation mechanism, because memory-space is limited and we want all samples to effect the kMeans-results.
 *
 * Idea for partitioning samples already seen:
 * 1. we have a limited amount of memory to cluster the samples already seen. e.g. we can save 1000 aux. cluster
 * 2. we cannot assume that the first 1000 samples are uniform distributed in the sample domain
 *
 * - we first utilize all the available memory. e.g. if we have enough memory
 *   for 1000 partitions/aux clusters, then the first 1000 samples are assigned
 *   to their own partition (cluster with one element)
 * - we memorize the distance of all cluster pairs
 * - for a new sample we calculate the distance to all clusters. If the smallest distance to a clusters is larger than
 *   the larges smallest distance between cluster pairs, then two cluster are merged to create space for a new
 *   cluster. We merge the cluster pair that are closest together.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 17:20:09
 */

class SamplesCache (size: Int) extends Logging {

  // array of auxiliary cluster
  private var auxClusters: Array[AuxCluster] = new Array[AuxCluster](size)

  // distance matrix TODO: we need a more efficient structure here
  private var distMatrix: Array[Array[Double]] = new Array[Array[Double]](size)
  for (i <- 0 until size) {
    distMatrix(i) = new Array[Double](size)
  }

  private var allSlotsOccupied: Boolean = false

  /**
   * Add an additional sample to one of the auxiliary cluster.
   */
  def addSample(sample: DenseVectorWritable){

    var slot: Int = findFreeClusterSlot

    // we have a free slot available
    if(slot > -1) {

      // create an own cluster for the sample
      auxClusters(slot) = new AuxCluster(sample, 1)

      // update distance matrix
      updateDistanceMatrix(auxClusters(slot), slot)
    }else{

      // compute smallest distance to all cluster
      var distId: (Int, Double) = computeSmallestDistance(sample)

      // compare the smallest distance with smallest distance between all pairs
      var sdistC: (Int, Int, Double) = findSmallestDistance

      // distance to nearest cluster of sample is larger than the smallest distance between the closest cluster
      if(distId._2 > sdistC._3){

        // we need merge the two closest cluster and create a new cluster for our sample
        auxClusters(sdistC._1).merge(auxClusters(sdistC._2))

        // sdistC._2 is now the id of the free cluster, we need to free this cluster
        auxClusters(sdistC._2) = new AuxCluster(sample, 1)

        // we need to re-calculate the distance matrix
        updateDistanceMatrix(auxClusters(sdistC._1), sdistC._1)

      }else{

        // add sample to closest cluster
        auxClusters(distId._1).addSample(sample)

        // update distance matrix for aux cluster s was assigned to
        updateDistanceMatrix(auxClusters(distId._1), distId._1)
      }
    }
  }

  /**
   * Reassigns all cached vectors to the given clusters.
   */
  def reAssignAll(clusters: Clusters) {

    // check for clusters that have been unassigned at the last iteration and reset their centroid with one of the
    // auxCluster centers
    for (i <- 0 until clusters.length) {

      if (clusters.get(i).isEmpty) {
        setupNewCluster(i, clusters)
      }
    }

    clusters.reset()

    for (i <- 0 until size) {

      var idDist:(Int, Double) = computeClosestCluster(auxClusters(i), clusters)
      var id: Int = idDist._1
      var distance: Double = idDist._2

      if (id > -1) {

        // this should not happen
        if (clusters.get(id) == null) {

          warn("The clusters list where the auxClusters are to be reassigned is incomplete.")

          // create new cluster
          clusters.set(id, new Cluster(auxClusters(i).getCenter.clone.asInstanceOf[DenseVectorWritable],
                                       auxClusters(i).getCenter.clone.times(
                                         auxClusters(i).getSamplesNumber).asInstanceOf[DenseVectorWritable],
                                       auxClusters(i).getSamplesNumber, 0.0))
        } else {

          // assign aux cluster to centroid
          clusters.get(id).assign(auxClusters(i), distance)
        }
      }
    }
  }

  /**
   * Chooses a new centroid for the cluster identified by id from clusters.
   *
   * @param id
   * @param clusters
   */
  private def setupNewCluster (id: Int, clusters: Clusters) {

    var isUnique: Boolean = true
    var c: Cluster = clusters.get(id)

    do {
      // setup a new cluster centroid
      isUnique = true
      c.reset()
      c.assign(auxClusters(new Random().nextInt(auxClusters.length)), 0.0)
      c.computeNewCentroid()

      // check whether the new cluster has an unique centroid or not
      for (i <- 0 until clusters.length) {
        if (i != id && c.equals(clusters.get(i))) {
          isUnique = false
        }
      }
    } while (!isUnique)
  }

  /**
   * Finds the Id and distance of the closest cluster for the given auxCluster.
   *
   * @param auxCluster
   * @param clusters
   */
  private def computeClosestCluster(auxCluster: AuxCluster, clusters: Clusters): (Int,Double) = {

    var distance: Double = 0.0
    var id: Int = -1

    if (auxCluster != null) {

      distance = Double.MaxValue
      id = 0

      for (i <- 0 until clusters.length) {
        if (clusters.get(i) != null) {
          var dist: Double = auxCluster.distanceTo(clusters.get(i))

          if(distance > dist){
            id = i
            distance = dist
          }
        }
      }
    }
    (id, distance)
  }

  /**
   * Finds a free slot.
   */
  private def findFreeClusterSlot: Int = {

    if (!allSlotsOccupied) {
      for(i <- 0 until size) {
        if(auxClusters(i) == null) {
          return i
        }
      }
      this.allSlotsOccupied = true
    }

    -1
  }

  /**
   * Searches the smallest distance of vector s to any other cluster, returns id of cluster and distance in a binary
   * tuple.
   */
  private def computeSmallestDistance(sample:DenseVectorWritable): (Int, Double) = {

    var smallestDistance: Double = Double.MaxValue
    var centerId: Int = 0

    for (i <- 0 until size) {
      if (auxClusters(i) != null) {
        var distance: Double = auxClusters(i).distanceTo(sample)
        if (distance < smallestDistance) {
          smallestDistance = distance
          centerId = i
        }
      }
    }
    (centerId, smallestDistance)
  }

  /**
   * Updates the distance matrix for a new cluster c added to slot s.
   */
  private def updateDistanceMatrix(cluster: AuxCluster, s: Int){

    for(i <- s until size){
      if(auxClusters(i) != null) {
        distMatrix(s)(i) = cluster.distanceTo(auxClusters(i))
      }
    }
    for(j <- 0 to s){
      if(auxClusters(j) != null){
        distMatrix(j)(s) = cluster.distanceTo(auxClusters(j))
      }
    }
  }

  /**
   * Finds the two cluster that have the smallest distance.
   */
  private def findSmallestDistance: (Int, Int, Double) = {

    var ci:Int = 0
    var cj:Int = 0
    var td: Double = Double.MaxValue

    for(i <- 0 until size){
      for(j <- i until size){
        if(j != i && td > distMatrix(i)(j)) {
         td = distMatrix(i)(j)
         ci = i
         cj = j
        }
      }
    }
    (ci, cj, td)
  }

  override def toString: String = {

    var result: String = "Auxiliary Clusters:\n"
    for(i <- 0 until size) {
      if(auxClusters(i) != null) {
        result += (i + " -> " + auxClusters(i).toString + "\n")
      } else {
        result += (i + " -> cluster is empty\n")
      }
    }

    result += ("\nDistance Matrix:\n")
    for(i <- 0 until size) {
      result += "\n"
      for(j <- 0 until size) {
    	  if(distMatrix(i)(j) > 0.0) {
    		  result += (distMatrix(i)(j).intValue + "   ")
    	  }else{
    	    result += (0.0 + "    ")
    	  }
      }
    }
    result += "\n"

    result
  }
}

/**
 * Auxiliary cluster with clusterCenter that is proxy for numSamples.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 09:29:20
 */
class AuxCluster(clusterCenter: DenseVectorWritable, numSamples: Int){

  private var center: DenseVectorWritable = clusterCenter
  private var number: Int = numSamples

  /**
   * Add a new sample to this auxiliary cluster.
   */
  def addSample(sample:DenseVectorWritable) {

    // create a new temp aux cluster for the sample
    var sc: AuxCluster = new AuxCluster (sample, 1)
    merge(sc)
  }

  /**
   * Computes the Euclidean distance of this clusterCenter to the given auxCluster.
   * @param auxCluster
   */
  def distanceTo(auxCluster: AuxCluster): Double =  {
    distanceTo(auxCluster.center)
  }

  /**
   * Computes the Euclidean distance of this clusterCenter to the given sample.
   * @param sample
   */
  def distanceTo(sample: DenseVectorWritable): Double =  {
    sample.getDistanceSquared(center)
  }

  /**
   * Computes the Euclidean distance of this clusterCenter to the given sample.
   * @param cluster
   */
  def distanceTo(cluster: Cluster): Double =  {
    cluster.distanceTo(center)
  }

  def getCenter: DenseVectorWritable = this.center.clone.asInstanceOf[DenseVectorWritable]

  def getSamplesNumber: Int = this.number

  /**
   * Merges this cluster with the given one.
   * @param auxCluster
   */
  def merge(auxCluster: AuxCluster) {
    computeNewCenter(auxCluster)
    number += auxCluster.number
  }

  /**
   * Computes the new centroid of the merged cluster.
   */
  private def computeNewCenter(auxCluster: AuxCluster) {

    // compute weights
    var wa: Double = number.asInstanceOf[Double] / (number + auxCluster.number).asInstanceOf[Double]
    var wb: Double = auxCluster.number.asInstanceOf[Double] / (number + auxCluster.number).asInstanceOf[Double]

    // apply weights
    auxCluster.center.times(wb)
    this.center.times(wa)

    // sum vectors
    auxCluster.center.addTo(this.center)
  }

  override def toString: String = {
    "Center: " + this.center.toString + " provided by " + this.number + " samples."
  }
}
