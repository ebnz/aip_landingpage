/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import java.util.Random
import java.io.FileWriter

/**
 * Used to generate random test-data for the k-means algorithm.
 *
 * User: flangner
 * Date: 28.08.2010
 * Time: 21:46:27
 */

object TestDataGenerator {

    private val SAMPLES_IN: String = "samples.sa"
    private val CENTROIDS_IN: String = "centriods.ce"
    private val MAX_DIST: Int = 5
    private val MAX_COORD: Int  = 100

    /**
     * @param args
     */
    def main(args: Array[String]) {
    if (args.length != 3){
      usage()
      System.exit(1)
    }

    var r: Random = new Random
    var n: Int = Integer.parseInt(args(0))
    var dim: Int = Integer.parseInt(args(1))
    var k: Int = Integer.parseInt(args(2))

    if (k<5 || k>50) throw new Exception("Illegal k [5,50]: "+k)
    if (n<k) throw new Exception ("n is smaller than k!")

    val out = new FileWriter(SAMPLES_IN)
    var centroidsOut = new FileWriter(CENTROIDS_IN)

    // get the cluster centers
    var centroids: Array[Array[Double]] = Array.ofDim(k)
    var centroid: Array[Double] = Array.ofDim(dim)

    for (i <- 0 until k) {

      for (c <- 0 until dim) {

        centroid(c) = r.nextInt(MAX_COORD) + r.nextDouble
      }

      centroids(i) = centroid

      // write the centers
      write(centroid, centroidsOut)
      centroid = Array.ofDim(dim)
    }

    // get the samples and write them to the output file
    for (i <- 0 until n) {

      var sample: Array[Double] = Array.ofDim(dim);
      centroid = centroids(r.nextInt(centroids.length))
      for (c <- 0 until dim) {
        if (r.nextBoolean) {
          sample(c) = 1
        } else {
          sample(c) = -1
        }
        sample(c) *= r.nextInt(MAX_DIST)
        sample(c) += centroid(c)
      }

//              centroid.addSSE(Math.pow(centroid.getDistance(coords.getCoords()),2.0));
//              centroid.incrementParticipants();

      write(sample, out)
    }


    out.close()
    centroidsOut.close()
    }

  private def write(vector: Array[Double], out: FileWriter) {
    for(elem: Double <- vector) {
      out.write(elem.toString + " ")
    }
    out.write("\n")
  }

    /**
     * Prints the usage information.
     */
    def usage() {
        println("usage: Generator <n> <d> <k>")
    }
}
