/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

//import org.apache.mahout.matrix.DenseVector
import org.apache.mahout.math.DenseVectorWritable
import algorithms.MRClass
import streaming.Collector
import collection.mutable.ListBuffer
import org.apache.hadoop.io.Writable
import org.apache.hadoop.conf.Configuration
import grizzled.slf4j.Logging
import org.apache.mahout.common.distance.EuclideanDistanceMeasure

/**
 * Approximation algorithm to compute K-Means with use of the MRStreamer map-reduce-framework.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 09:29:20
 */

class KMeans extends MRClass with Logging {

  // number of clusters
  private var k: Int = 0

  // number of aux cluster to maintain
  private var cacheSize: Int = 10000

  // cache for already seen samples
  private var cache: SamplesCache = null

  // index of the next centroid to initialize
  private var nextCentroidToInit: Int = 0

  // array of k clusters
  private var clusters: Clusters = null

  // number of samples processed within the job
  private var samplesProcessed: Int = 0

  // difference between the errors of two iterations specify the finishing criterion
  private var epsilon: Float = Float.MaxValue

  override def init(conf: Configuration) {
    this.k = conf.getInt("numCluster", 5)
    this.clusters = new Clusters(k)
    this.cacheSize = conf.getInt("numAuxCluster", 500)
    this.cache = new SamplesCache(cacheSize)
    //if (conf.get("epsilon") != null) {
      this.epsilon = conf.getFloat("epsilon", 100f)
    //}

    info("aux cluster: "+cacheSize+", num cluster(k): "+ k)
  }

  /**
   *  1) the map task holds a set of clusters. For each sample processed, the closest cluster is computed and
   *  the vector sum as well as the number of samples assigned to each vector are updated.
   *  2) after a certain number of samples is assigned to a cluster, the vec sum and # of samples is send to
   *  the reducer
   */
  def map (key: Any, value: Any, resultCollector: Collector) {

    var sample: DenseVectorWritable = key.asInstanceOf[Sample].getVector
    var cs: Clusters = value.asInstanceOf[Clusters].clone

    // we are at phase one and still collecting samples
    if (cs.isEmpty) {

      this.samplesProcessed += 1

      // choose some initially centroids
      if (nextCentroidToInit < k) {
        this.clusters.set(nextCentroidToInit, new Cluster(sample.clone.asInstanceOf[DenseVectorWritable], sample.clone.asInstanceOf[DenseVectorWritable]))
        this.nextCentroidToInit += 1
      }

      // add sample to local partitions
      this.cache.addSample(sample)

    // we got an update for the cluster centroids -> we need to re-calculate the clusters
    } else {

      info("Version of global clusters has changed.")
      this.clusters = cs
      this.clusters.reset()
      this.cache.reAssignAll(clusters)
    }

    if (nextCentroidToInit == k && this.clusters != null) {
      resultCollector.collect(new Sample, this.clusters)
      this.clusters = null
    }
  }

  // value for comparing historical results for specifying some finishing criterion
  private var lastError: Double = Double.MaxValue

  /**
   * Receives a list of different versions of the clusters and calculates a set of new global clusters.
   */
  def reduce(key: Any, values: ListBuffer[Any], resultCollector: Collector) {

    var result: Clusters = values(0).asInstanceOf[Clusters]

    for (i <- 1 until values.length) {
      result.merge(values(i).asInstanceOf[Clusters])
    }

    var error: Double = result.getMSE
    //debug("kmeans error : " + error + " last Error :" + lastError + " epsilon: " + epsilon)

    if (lastError < Double.MaxValue &&
        error <= lastError + epsilon &&
        error >= lastError - epsilon) {
      resultCollector.collect(key, result)
    } else {

      this.lastError = error
      result.computeNewCentroids()
      resultCollector.reStream(key, result)
    }
  }
}

/**
 * Class to serialize one cluster.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 09:29:20
 */
class Cluster (center: DenseVectorWritable, sum: DenseVectorWritable, num: Long, er: Double) extends Writable {

  private var centroid: DenseVectorWritable = center
  private var samplesSum: DenseVectorWritable = sum
  var number: Long = num
  var error: Double = er

  def this(center: DenseVectorWritable, sum: DenseVectorWritable) = this (new DenseVectorWritable(center.clone), new DenseVectorWritable(sum.clone), 1, Double.MaxValue)

  def this() = this (null.asInstanceOf[DenseVectorWritable], null.asInstanceOf[DenseVectorWritable], 0, 0.0)

  /**
   * Computes the Euclidean distance of this clusterCenter to the given sample.
   * @param sample
   */
  //def distanceTo(sample: org.apache.mahout.matrix.Vector): Double = this.centroid.getDistanceSquared(sample)
  def distanceTo(sample: org.apache.mahout.math.Vector): Double = this.centroid.getDistanceSquared(sample)

  /**
   * Computes the Euclidean distance of this clusterCenter to the centroid of the given cluster.
   * @param cluster
   */
  def distanceTo(cluster: Cluster): Double = distanceTo(cluster.centroid)

  /**
   * Computes a new centroid for this cluster, or sets its error to infinity if there are no samples
   * for this cluster.
   */
  def computeNewCentroid() {
    if (!isEmpty) {
      this.centroid = this.samplesSum.times(1.0/number).asInstanceOf[DenseVectorWritable]
    }
  }

  /**
   * Resets the error measured and the number of samples assigned to this cluster centroid.
   */
  def reset() {
    this.samplesSum = null
    this.number = 0L
    this.error = 0.0
  }

  /**
   * Adds distance to the error of this cluster.
   *
   * @param distance
   */
  def increaseError(distance: Double) {
    this.error += distance
  }

  /**
   * Assigns given auxiliary cluster with distance to this cluster.
   *
   * @param distance
   * @param auxCluster
   */
  def assign(auxCluster: AuxCluster, distance: Double) {

    var samplesNumber :Int = auxCluster.getSamplesNumber

    this.error += distance
    this.number += samplesNumber
    var samplesCenter: DenseVectorWritable = auxCluster.getCenter.clone.asInstanceOf[DenseVectorWritable]

    // weight centroid with all samples of aux cluster
    samplesCenter.times(samplesNumber)
    if (samplesSum == null) {
      this.samplesSum = samplesCenter
    } else {
      samplesCenter.addTo(samplesSum)
    }
  }

  /**
   *  Merges a given cluster with this cluster.
   * @param cluster
   */
  def merge(cluster: Cluster) {

    if (cluster != null) {
      this.number += cluster.number
      if (this.error < Double.MaxValue) {
        this.error += cluster.error
      }

      if (this.samplesSum == null) {

        this.samplesSum = cluster.samplesSum
      } else if (cluster.samplesSum != null) {

        cluster.samplesSum.addTo(this.samplesSum)
      }
    }
  }

  /**
   * @return true, if there have been no samples assigned to this cluster. false, otherwise.
   */
  def isEmpty: Boolean = (this.number == 0)

  def write(out: java.io.DataOutput) {
    val hasCentroid: Boolean = (centroid != null)
    out.writeBoolean(hasCentroid)
    if (hasCentroid) {
      centroid.write(out)
    }
    val hasSamplesSum: Boolean = (samplesSum != null)
    out.writeBoolean(hasSamplesSum)
    if (hasSamplesSum) {
      samplesSum.write(out)
    }
    out.writeLong(number)
    out.writeDouble(error)
  }

  def readFields(in: java.io.DataInput) {
    if (in.readBoolean) {
      centroid = new DenseVectorWritable
      centroid.readFields(in)
    }
    if (in.readBoolean) {
      samplesSum = new DenseVectorWritable
      samplesSum.readFields(in)
    }
    number = in.readLong
    error = in.readDouble
  }

  override def clone: Cluster = {
    var cent: DenseVectorWritable = null
    var sum: DenseVectorWritable = null
    if (centroid != null) cent = centroid.clone.asInstanceOf[DenseVectorWritable]
    if (samplesSum != null) sum = samplesSum.clone.asInstanceOf[DenseVectorWritable]

    new Cluster(cent, sum, number, error)
  }

  override def toString: String = {

    var result: StringBuffer = new StringBuffer("")
    result.append("Error: " + this.error)
    result.append(System.getProperty( "line.separator" ))
    result.append("Number of Samples: " + this.number)
    result.append(System.getProperty( "line.separator" ))
    if (centroid != null) {
      result.append("Centroid: ")
      for (i <- 0 until centroid.size) {
        result.append(centroid.getQuick(i))
        result.append(" ")
      }
      result.append(System.getProperty( "line.separator" ))
    }
    if (samplesSum != null) {
      result.append("Samples Sum: ")
      for (i <- 0 until samplesSum.size) {
        result.append(samplesSum.getQuick(i))
        result.append(" ")
      }
    }

    result.toString
  }

  override def equals(obj: Any): Boolean = {
    if (obj == null || !obj.isInstanceOf[Cluster]) return false
    this.centroid.equals(obj.asInstanceOf[Cluster].centroid)
  }
}

/*
 * An array of k clusters serializable to be transmitted from mapper to reducer and vice versa.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 09:29:20
 */
class Clusters (cs: Array[Cluster]) extends Writable {

  // we assume 10 to be the biggest number of clusters which shall be permuted for better results
  val MAX_K_TO_PERMUTE: Int = 10

  private var clusters: Array[Cluster] = cs

  def this(size: Int) = this(new Array[Cluster](size))

  def this() = this(0)

  def get(i: Int): Cluster = this.clusters(i)

  def set(i: Int, c: Cluster) {
    this.clusters(i) = c
  }

  def isEmpty: Boolean = (clusters.size == 0)

  def length: Int = clusters.length

  /**
   * Resets the error measured and the number of samples assigned to any of the clusters.
   */
  def reset() {

    this.clusters.foreach {
      cluster: Cluster => {

        if (cluster != null) cluster.reset()
      }
    }
  }

  /**
   * @return the sum over all errors of this clusters.
   */
  def getMSE: Double = {
    var result: Double = 0.0
    var numSamples: Long = 0
    for (c: Cluster <- clusters) {
      if (c.isEmpty) {
        c.error = Double.MaxValue
      }
      if (c.error < Double.MaxValue && result < Double.MaxValue) {
        result += c.error
      } else {
        result = Double.MaxValue
      }
      numSamples += c.number
    }

    if (result < Double.MaxValue) {
      result /= numSamples.toDouble
      math.sqrt(result)
    }

    result
  }

  /**
   * Merges the given clusters with this clusters.
   */
  def merge(that: Clusters) {

    if (!equals(that) && length <= MAX_K_TO_PERMUTE) {
      that.becomeClosestPermutation(this)
    }

    for (i <- 0 until length) {

      if (this.clusters(i) == null) {

        this.clusters(i) = that.clusters(i)
      } else if (that.clusters(i) != null) {

        this.clusters(i).merge(that.clusters(i))
      }
    }
  }

  /**
   * This method calculates the permutation of clusters for this with the smallest error.
   *
   * @param to - Clusters to measure the distance to as error.
   */
  private def becomeClosestPermutation(to: Clusters) {

    // search for an optimal permutation (with smallest error) of cluster that
    var overallDistance: Double = Double.MaxValue
    var closestPermutation: Array[Cluster] = clusters

    permute(0, () => {
      var dist: Double = getClustersDistance(to)
      if (dist < overallDistance) {
        closestPermutation = clusters.clone()
        overallDistance = dist
      }
    })

    clusters = closestPermutation
  }

  /**
   * Recursive algorithm to calculate all permutations for this cluster and execute the specified method on it.
   * Modified variant of the "University of Exeter algorithm".
   * @see http://www.bearcave.com/random_hacks/permute.html
   *
   * @param start - position to start with.
   * @param method - method to execute on each permutation.
   */
  private def permute(start: Int, method: () => Unit) {
    if (start == length - 1) {
			method()
		} else {
			for (i <- start until length) {
				var tmp: Cluster = clusters(i)

				clusters(i) = clusters(start)
				clusters(start) = tmp
				permute(start + 1, method);
				clusters(start) = clusters(i)
				clusters(i) = tmp
			}
		}
  }

  /**
   * Computes the overall distance between all clusters of this and clusters2 according to their field-positions within.
   *
   * @param clusters2
   * @return the sum of single distances between clusters(i) and clusters2.get(i).
   */
  private def getClustersDistance(clusters2: Clusters): Double = {
    var distance: Double = 0.0

    for (i <- 0 until length) {
      if (clusters(i) != null && clusters2.get(i) != null) {
        distance += clusters(i).distanceTo(clusters2.get(i))
      }
    }

    distance
  }

  /**
   * Computes a new centroid for every cluster within clusters.
   */
  def computeNewCentroids() {

    this.clusters.foreach {
      cluster: Cluster =>
      if (cluster != null) {
        cluster.computeNewCentroid()
      }
    }
  }

  def write(out: java.io.DataOutput) {
    out.writeInt(clusters.length)
    clusters.foreach{
      c: Cluster => {
        var isNull: Boolean = c == null
        out.writeBoolean(isNull)
        if (!isNull) {
          c.write(out)
        }
      }
    }
  }

  def readFields(in: java.io.DataInput) {
    var size: Int = in.readInt
    this.clusters = new Array[Cluster](size)
    for (i <- 0 until size) {
      if (!in.readBoolean) {
        var cluster: Cluster = new Cluster
        cluster.readFields(in)
        this.clusters(i) = cluster
      }
    }
  }

  override def toString: String = {
    var result: StringBuffer = new StringBuffer("")
    for (cluster: Cluster <- this.clusters) {
      if (cluster != null) {
        result.append(cluster.toString)
        result.append(System.getProperty( "line.separator" ))
      }
    }

    result.toString
  }

  override def clone: Clusters = {
    var result: Array[Cluster] = new Array[Cluster](length)

    for (i <- 0 until length) {
      result(i) = clusters(i).clone
    }

    new Clusters(result)
  }

  override def equals(obj: Any): Boolean = {
    if (!obj.isInstanceOf[Clusters]) return false
    val that: Clusters = obj.asInstanceOf[Clusters]
    if (length != that.length) return false
    for (i <- 0 until length) {
      if (!clusters(i).equals(that.get(i))) return false
    }
    true
  }
}

/*
 * This class is used to manipulate the hash value of Samples when they are used as key. It is necessary to do so,
 * because key-value pairs are mapped to mappers and reducers by using random numbers retrieved from the hashCode
 * of their keys.
 *
 * User: flangner
 * Date: 26.08.2010
 * Time: 09:29:20
 */
class Sample(s: DenseVectorWritable, hashC: Int) extends Writable {

  private var sample: DenseVectorWritable = s
  private var hash: Int = hashC

  def this() = this(null, -1)

  def getVector: DenseVectorWritable = this.sample

  def setVector(vector: DenseVectorWritable) {
    this.sample = vector
  }

  override def hashCode: Int = this.hash

  def write(out: java.io.DataOutput) {
    out.writeInt(this.hash)
    var isNull: Boolean = (sample == null)
    out.writeBoolean(isNull)
    if (!isNull) {
      this.sample.write(out)
    }
  }

  def readFields(in: java.io.DataInput) {
    this.hash = in.readInt
    if (!in.readBoolean) {
      var s: DenseVectorWritable = new DenseVectorWritable
      s.readFields(in)
      this.sample = s
    }
  }

  override def equals(obj: Any): Boolean = {
    if (!obj.isInstanceOf[Sample]) return false
    hashCode == obj.asInstanceOf[Sample].hashCode
  }
}
