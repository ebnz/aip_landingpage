/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import streaming._
import org.apache.hadoop.mapred.JobConf
import org.apache.hadoop.mapreduce.MRJobConfig

object KmeansTest {

  private val conf = new JobConf
  conf.set("mrstreamer.statsLogFile", "stats.log")
  conf.set("mrstreamer.resultFile", "kmeans.log")

  def main(args: Array[String]) {
    runCensusData()
    // runSyntheticData
  }

  def runCensusData() {
    val input: Array[(Any, Any)] = new Array[(Any, Any)](1)
      input(0) = ("./testdata/kmeans/samples", null)
//    val input: Array[(Any, Any)] = new Array[(Any, Any)](4)
//    input(0) = ("./testdata/kmeans/t2/xaa", null)
//    input(1) = ("./testdata/kmeans/t2/xab", null)
//    input(2) = ("./testdata/kmeans/t2/xac", null)
//    input(3) = ("./testdata/kmeans/t2/xad", null)
    //input(0) = ("./testdata/kmeans/xaa",null)
    //input(1) = ("./testdata/kmeans/xab",null)
    //	input(2) = Tuple2("./testdata/kmeans/xac",null)
    //	input(3) = Tuple2("./testdata/kmeans/xad",null)
    //	input(4) = Tuple2("./testdata/kmeans/census/xae",null)
    //	input(5) = Tuple2("./testdata/kmeans/census/xaf",null)
    //	input(6) = Tuple2("./testdata/kmeans/census/xag",null)
    //	input(7) = Tuple2("./testdata/kmeans/census/xah",null)
    //	input(8) = Tuple2("./testdata/kmeans/census/xai",null)
    //	input(9) = Tuple2("./testdata/kmeans/census/xaj",null)

    conf.set("mrstreamer.statsPath", "./testdata/kmeans/")
    conf.set("mrstreamer.mapAlgorithm", "algorithms.kmeans.KMeans")
    conf.set("mrstreamer.reduceAlgorithm", "algorithms.kmeans.KMeans")
    conf.set("mrstreamer.collectorAlgorithm", "algorithms.kmeans.KMeansCollector")

    conf.set("mrstreamer.oneForAll", "true")
    conf.set("mrstreamer.numIterations", "2")

    conf.set("mrstreamer.statThresholdStep", "0")
    conf.set("mrstreamer.mapCollectorBufferSize", "0")

    // has to be 1 to ensure the algorithm producing valid results
    conf.setNumReduceTasks(1)

    // the reduce collector bufferSize has to be equal the number of mappers available!
    conf.setNumMapTasks(4)
    conf.set("mrstreamer.reduceCollectorBufferSize", "4")

    conf.set("numCluster", "5")
    conf.set("numAuxCluster", "500")
    // for small data sets
    // conf.set("numAuxCluster", "10")

    conf.set("mrstreamer.map.input.key.class", "algorithms.kmeans.Sample")
    conf.set("mrstreamer.map.input.value.class", "algorithms.kmeans.Clusters")

    conf.set(MRJobConfig.MAP_OUTPUT_KEY_CLASS, "algorithms.kmeans.Sample")
    conf.set(MRJobConfig.MAP_OUTPUT_VALUE_CLASS, "algorithms.kmeans.Clusters")
    conf.set(MRJobConfig.OUTPUT_KEY_CLASS, "algorithms.kmeans.Sample")
    conf.set(MRJobConfig.OUTPUT_VALUE_CLASS, "algorithms.kmeans.Clusters")

    conf.set("mapred.input.format.class", "algorithms.kmeans.SampleInputFormat")

    val mr: MRStreamer = new MRStreamer(conf, input)
    val time: Long = System.currentTimeMillis
    mr.run
    print("\nDuration of the execution of K-Means: " + (System.currentTimeMillis - time) + " ms")

    println("\nall finished!")
    System.exit(0)
  }

  /*
  def runSyntheticData(){

    val kmeans = new KMeans()
    val classN:String = kmeans.getClass().getCanonicalName();

	conf.setProperty("mapAlgorithm", classN);
	conf.setProperty("reduceAlgorithm", classN);
	conf.setProperty("collectorAlgorithm", new KMeansCollector().getClass().getCanonicalName());
	conf.setProperty("numMappers", "2");

	// note, numReducers defines the number of reduce worker
	conf.setProperty("numReducers", "1");
	conf.setProperty("mapCollectorBufferSize","10")

	conf.setProperty("numCluster", "5")

	// init global cluster
	conf.sharedObject = initClusterSynthetic

	val input:Array[(Any,Any)] = new Array[(Any, Any)](2)
	input(0) = Tuple2("./testdata/kmeans/xaa",null)
	input(1) = Tuple2("./testdata/kmeans/xab",null)

	val mr:MRStreamer = new MRStreamer(conf, input)
	mr.run

  }



  /** assigns initial cluster, need to find a better way to initialize the cluster!?  */
  def initClusterSynthetic() : Array[Cluster] = {
    var res = new Array[Cluster](5)
    var is_list:List[DenseVectorWritable] = Nil

    forFileLines("./testdata/kmeans/synthetic_control.data") { line =>
	  var elements: List[String] = line.split(' ').toList
	  var doubleElements:Array[Double] = new Array[Double](60)
	  var i:Int = 0

	  for(e <- elements){
	    doubleElements(i) = e.toDouble
		i=i+1
	  }
      var vector:DenseVectorWritable = new DenseVectorWritable(new DenseVector(doubleElements))
      is_list = vector :: is_list
	}

	res.asInstanceOf[Array[Cluster]](0) =  new Cluster(is_list.apply(50),null,0,0.0,0)
    res.asInstanceOf[Array[Cluster]](1) =  new Cluster(is_list.apply(100),null,0,0.0,0)
	res.asInstanceOf[Array[Cluster]](2) =  new Cluster(is_list.apply(250),null,0,0.0,0)
	res.asInstanceOf[Array[Cluster]](3) =  new Cluster(is_list.apply(350),null,0,0.0,0)
	res.asInstanceOf[Array[Cluster]](4) =  new Cluster(is_list.apply(550),null,0,0.0,0)

	return res
  }
*/

}
