/*
 * Copyright 2011
 * Parallel and Distributed Systems Group (PVS)
 * Institute of Computer Science (IFI)
 * Heidelberg University
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package algorithms.kmeans

import eval.ResultSummary

class KMeansResultSummary extends ResultSummary {

  private var clusters: Clusters = null
  private var mse: Double = Double.MaxValue

  def set(resultSummaryValue: Any) {
    this.clusters = resultSummaryValue.asInstanceOf[Clusters]
    this.mse = clusters.getMSE
  }
  
  def dif (summaryA: ResultSummary, summaryB: ResultSummary): Double = {
    math.abs(summaryA.asInstanceOf[KMeansResultSummary].computeMSError -
                    summaryB.asInstanceOf[KMeansResultSummary].computeMSError)
  }
  
   /**
    * Computes the MSE of the current global cluster.
    */
  def computeMSError: Double = this.mse
  
  // alternatively return the centroid vectors
  override def toString: String = {
    
    if(clusters != null){
      return "MSE: " + mse + "\n" + clusters.toString
    }
    ""
  }
}